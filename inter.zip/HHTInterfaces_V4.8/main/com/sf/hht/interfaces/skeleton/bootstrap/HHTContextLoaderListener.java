package com.sf.hht.interfaces.skeleton.bootstrap;

import javax.servlet.ServletContextEvent;

import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.ContextLoaderListener;

import com.sf.hht.interfaces.skeleton.core.TaskCenter;

public class HHTContextLoaderListener extends ContextLoaderListener {

	private static final String TASK_CENTER_ID = "taskCenterId";
	
	@Override
	public void contextDestroyed(ServletContextEvent event) {
		try {
			ContextLoader contextLoader = getContextLoader();
			if (contextLoader != null) {
				TaskCenter taskCenter = (TaskCenter) ContextLoader.getCurrentWebApplicationContext().getBean(
						event.getServletContext().getInitParameter(TASK_CENTER_ID));
				
				taskCenter.terminate();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		super.contextDestroyed(event);
	}

}