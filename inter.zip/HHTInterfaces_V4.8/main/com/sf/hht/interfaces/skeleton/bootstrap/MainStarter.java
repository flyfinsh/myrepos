package com.sf.hht.interfaces.skeleton.bootstrap;

import java.util.TimerTask;

import com.sf.hht.interfaces.skeleton.core.TaskCenter;

public class MainStarter extends TimerTask {

	private TaskCenter taskCenter;
	
	public void setTaskCenter(TaskCenter taskCenter) {
		this.taskCenter = taskCenter;
	}

	@Override
	public void run() {
		taskCenter.run();
	}
}