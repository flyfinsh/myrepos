package com.sf.hht.interfaces.skeleton.cache;

public class Employee {
	// 员工工号
	private String empId;
	
	// 网点代码
	private String deptId;

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}
	
}
