package com.sf.hht.interfaces.skeleton.cache;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Parameter {
	//private final static String PARAMETER_FILE_NAME = "com/sf/hht/interfaces/skeleton/META-INF/hhtinterface";
	//private static ResourceBundle paramsBundle = null;
	
	/*public static void initialize() {
		paramsBundle = PropertyResourceBundle.getBundle(PARAMETER_FILE_NAME);
	}
	
	public static String getValue(String key){
		try {
			if (paramsBundle == null) {
				initialize();
			}
			
			String value = paramsBundle.getString(key);
			if (value != null) {
				return value.trim();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}*/
	
	private final static String PARAMETER_FILE_NAME = "hhtinterface.properties";
	private static Properties properties = null;

	public static void initialize() {
		String confPath = System.getenv().get("CONF_PATH");
		InputStream in;
		try {
			in = new FileInputStream(new File(confPath + File.separator + PARAMETER_FILE_NAME));
			properties = new Properties();
			properties.load(in);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static String getValue(String key){
		try {
			if (properties == null) {
				initialize();
			}

			String value = properties.getProperty(key);
			if (value != null) {
				return value.trim();
			}



		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}
	
	// webservice 默认超时时间（毫秒）
	public static String WS_TIME_OUT = getValue("ws_time_out");
}
