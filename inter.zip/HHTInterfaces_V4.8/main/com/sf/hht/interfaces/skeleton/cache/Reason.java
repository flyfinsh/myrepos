package com.sf.hht.interfaces.skeleton.cache;

public class Reason {

	private String code;
	private String content;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
}
