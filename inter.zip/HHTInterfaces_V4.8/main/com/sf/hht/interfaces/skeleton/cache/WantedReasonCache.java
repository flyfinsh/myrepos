package com.sf.hht.interfaces.skeleton.cache;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class WantedReasonCache {
	
	private static Map<String, String> cache = new ConcurrentHashMap<String, String>();
	
	private static Map<String, List<Employee>> empCache = new ConcurrentHashMap<String, List<Employee>>();

	public static void setCache(List<Reason> list) {
		if (list != null) {
			cache.clear();

			for (Reason reason : list) {
				cache.put(reason.getCode(), reason.getContent());
			}
		}
	}
	
	public static String getContent(String code) {
		return code == null ? "" : cache.get(code);
	}
	
	public static void setEmpCache(List<Employee> list){
		if (list != null) {
			empCache.clear();
			
			for (Employee employee : list) {
				List<Employee> empList = empCache.get(employee.getDeptId());
				
				if (empList == null) {
					empList = new ArrayList<Employee>();
					empCache.put(employee.getDeptId(), empList);
				}
				
				empList.add(employee);
			}
		}
	}
	
	public static List<Employee> getEmployees(String deptCode){
		return deptCode == null ? null : empCache.get(deptCode);
	}
}