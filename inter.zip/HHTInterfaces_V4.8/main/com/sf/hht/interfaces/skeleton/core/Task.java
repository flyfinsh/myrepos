package com.sf.hht.interfaces.skeleton.core;

public class Task {

	private String name;//任务中文名称
	private String from;//源系统代码
	private String to;//目标系统代码
	private int recordSize;//每次加载的数据量
	private long period;//线程休眠周期

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public int getRecordSize() {
		return recordSize;
	}
	public void setRecordSize(int recordSize) {
		this.recordSize = recordSize;
	}
	public long getPeriod() {
		return period;
	}
	public void setPeriod(long period) {
		this.period = period;
	}
}