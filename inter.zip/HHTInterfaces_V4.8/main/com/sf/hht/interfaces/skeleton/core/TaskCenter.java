package com.sf.hht.interfaces.skeleton.core;

import java.util.List;

public interface TaskCenter {

	public void loadTask(TaskTracker taskTracker);
	public List<TaskTracker> getTaskTrackers(); 
	public void run();
	public void terminate();
}
