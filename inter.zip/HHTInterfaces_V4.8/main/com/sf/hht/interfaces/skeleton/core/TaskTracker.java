package com.sf.hht.interfaces.skeleton.core;

import java.util.List;

public interface TaskTracker {
	
	public String getTrackerId();
	public void run();
	public void stop();
	public List<TaskWorker> getWorkers();
	public TaskWorker createWorker();
	public boolean isBootup();
}
