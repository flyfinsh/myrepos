package com.sf.hht.interfaces.skeleton.core;

public abstract class TaskWorker extends Thread {

	protected Task task;
	protected boolean running;
	
	private Object event = new Object();
	
	public Task getTask() {
		return task;
	}

	public void setTask(Task task) {
		this.task = task;
	}
	
	public void setRunning(boolean running) {
		this.running = running;
	}

	public void run() {
		execute();
	}
	
	public void makeWait(long timeout) {
		synchronized (event) {
			try {
				event.wait(timeout);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void makeNotify() {
		synchronized (event) {
			try {
				event.notify();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public abstract void preprocess();
	protected abstract void execute();
}