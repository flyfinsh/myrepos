package com.sf.hht.interfaces.skeleton.core.support;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.sf.hht.interfaces.skeleton.core.TaskCenter;
import com.sf.hht.interfaces.skeleton.core.TaskTracker;

public class TaskCenterSupport implements TaskCenter {

	private List<TaskTracker> taskTrackers;
	
	public List<TaskTracker> getTaskTrackers() {
		return taskTrackers;
	}

	public void loadTask(TaskTracker taskTracker) {
		if (taskTrackers == null) {
			taskTrackers = new ArrayList<TaskTracker>();
		}
		
		taskTrackers.add(taskTracker);
	}
	
	public void run() {
		Collections.sort(taskTrackers, new Comparator<TaskTracker>(){
			public int compare(TaskTracker o1, TaskTracker o2) {
				int i = ((Boolean)o1.isBootup()).compareTo((Boolean)o2.isBootup());
				
				return i;
			}
		});
		
		for (TaskTracker taskTracker : taskTrackers) {
			if (taskTracker.isBootup()) {
				taskTracker.run();
			}
		}
	}
	
	public void terminate() {
		for (TaskTracker taskTracker : taskTrackers) {
			taskTracker.stop();
		}
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}