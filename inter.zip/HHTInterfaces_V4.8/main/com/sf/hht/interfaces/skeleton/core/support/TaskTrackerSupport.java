package com.sf.hht.interfaces.skeleton.core.support;

import java.util.ArrayList;
import java.util.List;

import com.sf.hht.interfaces.skeleton.core.TaskCenter;
import com.sf.hht.interfaces.skeleton.core.TaskTracker;
import com.sf.hht.interfaces.skeleton.core.TaskWorker;

public abstract class TaskTrackerSupport implements TaskTracker {

	private String trackerId;
	private int workerNum;
	private TaskCenter taskCenter;
	private List<TaskWorker> workers = new ArrayList<TaskWorker>();
	private boolean bootup = true;

	public String getTrackerId() {
		return trackerId;
	}
	public void setTrackerId(String trackerId) {
		this.trackerId = trackerId;
	}
	public int getWorkerNum() {
		return workerNum;
	}
	public void setWorkerNum(int workerNum) {
		this.workerNum = workerNum;
	}
	public void setTaskCenter(TaskCenter taskCenter) {
		this.taskCenter = taskCenter;
		this.taskCenter.loadTask(this);
	}
	
	public boolean isBootup() {
		return bootup;
	}
	
	public void setBootup(boolean bootup) {
		this.bootup = bootup;
	}
	
	public void run() {
		TaskWorker initWorker = createWorker();
		//only preprocess once
		initWorker.preprocess();
		initWorker = null;
		
		for (int i = 0; i < workerNum; i++) {
			TaskWorker worker = createWorker();
			worker.setRunning(true);
			worker.start();
			
			workers.add(worker);
		}
	}

	public void stop() {
		for (TaskWorker worker : workers) {
			worker.setRunning(false);
			worker.makeNotify();
		}
		
		workers.clear();
	}

	public List<TaskWorker> getWorkers() {
		return workers;
	}

	public abstract TaskWorker createWorker();
}