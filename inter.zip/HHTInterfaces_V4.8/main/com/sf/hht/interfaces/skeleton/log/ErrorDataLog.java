package com.sf.hht.interfaces.skeleton.log;

import org.apache.log4j.Logger;

public class ErrorDataLog {

	private static final Logger logger = Logger.getLogger(ErrorDataLog.class);
	
	public static void error(Object message) {
		logger.error(message);
	}
}