package com.sf.hht.interfaces.skeleton.resource;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;

public class MQManager {

	private ConnectionFactory connectionFactory;

	public void setConnectionFactory(ConnectionFactory connectionFactory) {
		this.connectionFactory = connectionFactory;
	}
	
	public Connection getConnection() throws JMSException {
		return connectionFactory.createConnection();
	}
	
	public void close(MessageProducer producer) {
		try {
			if(producer != null){
				producer.close();
				producer = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void close(MessageConsumer consumer) {
		try {
			if(consumer != null){
				consumer.close();
				consumer = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void close(Session session) {
		try {
			if(session != null){
				session.close();
				session = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void close(Connection connection) {
		try {
			if(connection != null){
				connection.close();
				connection = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}