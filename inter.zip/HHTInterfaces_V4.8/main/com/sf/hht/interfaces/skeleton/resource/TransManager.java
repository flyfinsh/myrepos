package com.sf.hht.interfaces.skeleton.resource;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.transaction.UserTransaction;

public class TransManager {

	private static final ThreadLocal<UserTransaction> utLocal = 
		new ThreadLocal<UserTransaction>();
	
	private Context context;
	private String jndiName;

	public void setJndiName(String jndiName) {
		this.jndiName = jndiName;
	}
	
	public UserTransaction getUserTransaction() throws NamingException {
		UserTransaction ut = utLocal.get();
		if (ut == null) {
			if (context == null) {
				context = new InitialContext();
			}
			ut = (UserTransaction) context.lookup(jndiName);
			utLocal.set(ut);
		}

		return ut;
	}
}