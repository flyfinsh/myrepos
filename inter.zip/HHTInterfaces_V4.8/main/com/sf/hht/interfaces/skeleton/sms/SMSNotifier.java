package com.sf.hht.interfaces.skeleton.sms;

import com.sf.hht.interfaces.skeleton.sms.ws.ProcSMSProxy;
import com.sf.hht.interfaces.skeleton.sms.ws.SMS;

public class SMSNotifier {

	private String webService;
	private String phoneList;
	
	public void setWebService(String webService) {
		this.webService = webService;
	}
	
	public void setPhoneList(String phones) {
		this.phoneList = phones;
	}

	public void sendMessage(String msg) {
		ProcSMSProxy proxy = new ProcSMSProxy(webService);
		
		SMS sms = new SMS();
		sms.setCheckword("");
		sms.setMsg(msg);
		sms.setMsgtype("HHTMON");
		sms.setResno("SF");
		
		String[] phoneArray = phoneList.split(",");
		for (String phone : phoneArray) {
			sms.setMobileno(phone);
			try {
				proxy.sendSMS(sms);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}