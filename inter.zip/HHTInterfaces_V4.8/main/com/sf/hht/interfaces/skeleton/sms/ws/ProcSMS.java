/**
 * ProcSMS.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.skeleton.sms.ws;

public interface ProcSMS extends java.rmi.Remote {
    public java.lang.String sendSMS(com.sf.hht.interfaces.skeleton.sms.ws.SMS sms) throws java.rmi.RemoteException;
    public java.lang.String sendSMSEX(com.sf.hht.interfaces.skeleton.sms.ws.SMSEX sms) throws java.rmi.RemoteException;
}
