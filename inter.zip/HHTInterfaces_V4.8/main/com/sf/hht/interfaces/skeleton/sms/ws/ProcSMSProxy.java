package com.sf.hht.interfaces.skeleton.sms.ws;

public class ProcSMSProxy implements com.sf.hht.interfaces.skeleton.sms.ws.ProcSMS {
  private String _endpoint = null;
  private com.sf.hht.interfaces.skeleton.sms.ws.ProcSMS procSMS = null;
  private String procSMS_addr = null;
  
  public void setProcSMS_addr(String procSMS_addr) {
	  this.procSMS_addr = procSMS_addr;
  }

  public ProcSMSProxy(String procSMS_addr) {
	  setProcSMS_addr(procSMS_addr);
	  
	  _initProcSMSProxy(procSMS_addr);
  }
  
  private void _initProcSMSProxy(String procSMS_addr) {
    try {
      procSMS = (new com.sf.hht.interfaces.skeleton.sms.ws.ProcSMSServiceLocator(procSMS_addr)).getprocSMS();
      if (procSMS != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)procSMS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)procSMS)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (procSMS != null)
      ((javax.xml.rpc.Stub)procSMS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.sf.hht.interfaces.skeleton.sms.ws.ProcSMS getProcSMS() {
    if (procSMS == null)
      _initProcSMSProxy(procSMS_addr);
    return procSMS;
  }
  
  public java.lang.String sendSMS(com.sf.hht.interfaces.skeleton.sms.ws.SMS sms) throws java.rmi.RemoteException{
    if (procSMS == null)
      _initProcSMSProxy(procSMS_addr);
    return procSMS.sendSMS(sms);
  }
  
  public java.lang.String sendSMSEX(com.sf.hht.interfaces.skeleton.sms.ws.SMSEX sms) throws java.rmi.RemoteException{
    if (procSMS == null)
      _initProcSMSProxy(procSMS_addr);
    return procSMS.sendSMSEX(sms);
  }
  
}