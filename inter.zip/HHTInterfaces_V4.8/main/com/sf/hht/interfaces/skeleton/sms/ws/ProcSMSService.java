/**
 * ProcSMSService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.skeleton.sms.ws;

public interface ProcSMSService extends javax.xml.rpc.Service {
    public java.lang.String getprocSMSAddress();
 
    public com.sf.hht.interfaces.skeleton.sms.ws.ProcSMS getprocSMS() throws javax.xml.rpc.ServiceException;

    public com.sf.hht.interfaces.skeleton.sms.ws.ProcSMS getprocSMS(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
