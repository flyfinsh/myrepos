/**
 * ProcSMSServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.skeleton.sms.ws;

@SuppressWarnings("unchecked")
public class ProcSMSServiceLocator extends org.apache.axis.client.Service implements com.sf.hht.interfaces.skeleton.sms.ws.ProcSMSService {

    private static final long serialVersionUID = 1L;
	// Use to get a proxy class for procSMS
    private String procSMS_address = "";

    public java.lang.String getprocSMSAddress() {
        return procSMS_address;
    }
    public ProcSMSServiceLocator(String procSMS_addr)
    {
    	procSMS_address = procSMS_addr;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String procSMSWSDDServiceName = "procSMS";

    public java.lang.String getprocSMSWSDDServiceName() {
        return procSMSWSDDServiceName;
    }

    public void setprocSMSWSDDServiceName(java.lang.String name) {
        procSMSWSDDServiceName = name;
    }

    public com.sf.hht.interfaces.skeleton.sms.ws.ProcSMS getprocSMS() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(procSMS_address);
        }
        catch (java.net.MalformedURLException e) {
            return null; // unlikely as URL was validated in WSDL2Java
        }
        return getprocSMS(endpoint);
    }
 
    public com.sf.hht.interfaces.skeleton.sms.ws.ProcSMS getprocSMS(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.sf.hht.interfaces.skeleton.sms.ws.ProcSMSSoapBindingStub _stub = new com.sf.hht.interfaces.skeleton.sms.ws.ProcSMSSoapBindingStub(portAddress, this);
            _stub.setPortName(getprocSMSWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
	public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.sf.hht.interfaces.skeleton.sms.ws.ProcSMS.class.isAssignableFrom(serviceEndpointInterface)) {
                com.sf.hht.interfaces.skeleton.sms.ws.ProcSMSSoapBindingStub _stub = new com.sf.hht.interfaces.skeleton.sms.ws.ProcSMSSoapBindingStub(new java.net.URL(procSMS_address), this);
                _stub.setPortName(getprocSMSWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        java.rmi.Remote _stub = getPort(serviceEndpointInterface);
        ((org.apache.axis.client.Stub) _stub).setPortName(portName);
        return _stub;
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://comm.sms.sf", "procSMSService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("procSMS"));
        }
        return ports.iterator();
    }

}
