/**
 * SMS.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.skeleton.sms.ws;

@SuppressWarnings("unchecked")
public class SMS  implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
	private java.lang.String checkword;
    private java.lang.String mobileno;
    private java.lang.String msg;
    private java.lang.String msgtype;
    private java.lang.String resno;

    public SMS() {
    }

    public java.lang.String getCheckword() {
        return checkword;
    }

    public void setCheckword(java.lang.String checkword) {
        this.checkword = checkword;
    }

    public java.lang.String getMobileno() {
        return mobileno;
    }

    public void setMobileno(java.lang.String mobileno) {
        this.mobileno = mobileno;
    }

    public java.lang.String getMsg() {
        return msg;
    }

    public void setMsg(java.lang.String msg) {
    	char oldChar=0x1f;
    	char newChar=0x0a;//���з�
    	if (msg!=null){
    		msg=msg.replace(oldChar, newChar);
    	}
    	else{
    		msg="";
    	}
       
        this.msg = msg;
    }

    public java.lang.String getMsgtype() {
        return msgtype;
    }

    public void setMsgtype(java.lang.String msgtype) {
        this.msgtype = msgtype;
    }

    public java.lang.String getResno() {
        return resno;
    }

    public void setResno(java.lang.String resno) {
        this.resno = resno;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SMS)) return false;
        SMS other = (SMS) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((checkword==null && other.getCheckword()==null) || 
             (checkword!=null &&
              checkword.equals(other.getCheckword()))) &&
            ((mobileno==null && other.getMobileno()==null) || 
             (mobileno!=null &&
              mobileno.equals(other.getMobileno()))) &&
            ((msg==null && other.getMsg()==null) || 
             (msg!=null &&
              msg.equals(other.getMsg()))) &&
            ((msgtype==null && other.getMsgtype()==null) || 
             (msgtype!=null &&
              msgtype.equals(other.getMsgtype()))) &&
            ((resno==null && other.getResno()==null) || 
             (resno!=null &&
              resno.equals(other.getResno())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCheckword() != null) {
            _hashCode += getCheckword().hashCode();
        }
        if (getMobileno() != null) {
            _hashCode += getMobileno().hashCode();
        }
        if (getMsg() != null) {
            _hashCode += getMsg().hashCode();
        }
        if (getMsgtype() != null) {
            _hashCode += getMsgtype().hashCode();
        }
        if (getResno() != null) {
            _hashCode += getResno().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SMS.class);

    static {
        org.apache.axis.description.FieldDesc field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("checkword");
        field.setXmlName(new javax.xml.namespace.QName("", "checkword"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("mobileno");
        field.setXmlName(new javax.xml.namespace.QName("", "mobileno"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("msg");
        field.setXmlName(new javax.xml.namespace.QName("", "msg"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("msgtype");
        field.setXmlName(new javax.xml.namespace.QName("", "msgtype"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("resno");
        field.setXmlName(new javax.xml.namespace.QName("", "resno"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
    };

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
	public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
	public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
