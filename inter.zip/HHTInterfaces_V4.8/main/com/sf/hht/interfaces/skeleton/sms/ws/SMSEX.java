/**
 * SMSEX.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.skeleton.sms.ws;

@SuppressWarnings("unchecked")
public class SMSEX  implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
	private java.lang.String SP;
    private java.lang.String checkword;
    private java.lang.String mobileno;
    private java.lang.String msg;
    private java.lang.String msgId;
    private java.lang.String msgtype;
    private java.lang.String resno;
    private java.lang.String systemId;

    public SMSEX() {
    }

    public java.lang.String getSP() {
        return SP;
    }

    public void setSP(java.lang.String SP) {
        this.SP = SP;
    }

    public java.lang.String getCheckword() {
        return checkword;
    }

    public void setCheckword(java.lang.String checkword) {
        this.checkword = checkword;
    }

    public java.lang.String getMobileno() {
        return mobileno;
    }

    public void setMobileno(java.lang.String mobileno) {
        this.mobileno = mobileno;
    }

    public java.lang.String getMsg() {
        return msg;
    }

    public void setMsg(java.lang.String msg) {
    	char oldChar=0x1f;
    	char newChar=0x0a;//���з�
    	if (msg!=null){
    		msg=msg.replace(oldChar, newChar);
    	}
    	else{
    		msg="";
    	}
       
        this.msg = msg;
    }

    public java.lang.String getMsgId() {
        return msgId;
    }

    public void setMsgId(java.lang.String msgId) {
        this.msgId = msgId;
    }

    public java.lang.String getMsgtype() {
        return msgtype;
    }

    public void setMsgtype(java.lang.String msgtype) {
        this.msgtype = msgtype;
    }

    public java.lang.String getResno() {
        return resno;
    }

    public void setResno(java.lang.String resno) {
        this.resno = resno;
    }

    public java.lang.String getSystemId() {
        return systemId;
    }

    public void setSystemId(java.lang.String systemId) {
        this.systemId = systemId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SMSEX)) return false;
        SMSEX other = (SMSEX) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((SP==null && other.getSP()==null) || 
             (SP!=null &&
              SP.equals(other.getSP()))) &&
            ((checkword==null && other.getCheckword()==null) || 
             (checkword!=null &&
              checkword.equals(other.getCheckword()))) &&
            ((mobileno==null && other.getMobileno()==null) || 
             (mobileno!=null &&
              mobileno.equals(other.getMobileno()))) &&
            ((msg==null && other.getMsg()==null) || 
             (msg!=null &&
              msg.equals(other.getMsg()))) &&
            ((msgId==null && other.getMsgId()==null) || 
             (msgId!=null &&
              msgId.equals(other.getMsgId()))) &&
            ((msgtype==null && other.getMsgtype()==null) || 
             (msgtype!=null &&
              msgtype.equals(other.getMsgtype()))) &&
            ((resno==null && other.getResno()==null) || 
             (resno!=null &&
              resno.equals(other.getResno()))) &&
            ((systemId==null && other.getSystemId()==null) || 
             (systemId!=null &&
              systemId.equals(other.getSystemId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSP() != null) {
            _hashCode += getSP().hashCode();
        }
        if (getCheckword() != null) {
            _hashCode += getCheckword().hashCode();
        }
        if (getMobileno() != null) {
            _hashCode += getMobileno().hashCode();
        }
        if (getMsg() != null) {
            _hashCode += getMsg().hashCode();
        }
        if (getMsgId() != null) {
            _hashCode += getMsgId().hashCode();
        }
        if (getMsgtype() != null) {
            _hashCode += getMsgtype().hashCode();
        }
        if (getResno() != null) {
            _hashCode += getResno().hashCode();
        }
        if (getSystemId() != null) {
            _hashCode += getSystemId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SMSEX.class);

    static {
        org.apache.axis.description.FieldDesc field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("SP");
        field.setXmlName(new javax.xml.namespace.QName("", "SP"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("checkword");
        field.setXmlName(new javax.xml.namespace.QName("", "checkword"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("mobileno");
        field.setXmlName(new javax.xml.namespace.QName("", "mobileno"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("msg");
        field.setXmlName(new javax.xml.namespace.QName("", "msg"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("msgId");
        field.setXmlName(new javax.xml.namespace.QName("", "msgId"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("msgtype");
        field.setXmlName(new javax.xml.namespace.QName("", "msgtype"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("resno");
        field.setXmlName(new javax.xml.namespace.QName("", "resno"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("systemId");
        field.setXmlName(new javax.xml.namespace.QName("", "systemId"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(field);
    };

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
	public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
	public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
