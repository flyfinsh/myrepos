package com.sf.hht.interfaces.skeleton.util;

/**
 * 通用工具类：
 * 1)获取SERVERID
 *
 */


import java.lang.management.ManagementFactory;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Set;

import javax.management.MBeanServer;
import javax.management.MBeanServerFactory;
import javax.management.ObjectInstance;
import javax.management.ObjectName;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CommonHelper {

	private static Log log = LogFactory.getLog(CommonHelper.class);

	private static final String SERVER_ID = InitialServerID.getServerId();

	
	
	private static class InitialServerID {
		private static String getServerId() {
			String serverid = null;
			// ServerConfig locator=ServerConfigLocator.locate();

			try {
				serverid = getTomcatServerHttpServerid();
			} catch (Exception ex) {
				log.error("CommonHelper get serverid exception", ex);
			}
			log.info("CommonHelper get serverid=" + serverid);
			return serverid;
		}
	}

	// 获取Serverid+port的字符串,JBOSS
	public static String getServerId() {
		return SERVER_ID;
	}

		

	static final String TOMCAT_OBJECTNAME = "jboss.web:type=Connector,*";
	static final String TOMCAT_HTTP_PROTOCOL = "HTTP/1.1";

	@SuppressWarnings("unchecked")
	public static String getTomcatServerHttpServerid() throws Exception {

		MBeanServer server = null;
		List<MBeanServer> mbeanServers = MBeanServerFactory
				.findMBeanServer(null);
		for (MBeanServer _mbs : mbeanServers) {
			if ("jboss".equals(_mbs.getDefaultDomain())) {
				server = _mbs;
				break;
			}
		}
		
		if (server == null) {
			server = ManagementFactory.getPlatformMBeanServer();
		}
		
		if (server == null)
			throw new Exception("CommonHelper can not found jboss");

		Set<ObjectInstance> instances = server.queryMBeans(ObjectName
				.getInstance(TOMCAT_OBJECTNAME), null);

		for (ObjectInstance _ins : instances)
			System.out
					.println(_ins.getObjectName() + " " + _ins.getClassName());

		Set<ObjectName> names = server.queryNames(ObjectName
				.getInstance(TOMCAT_OBJECTNAME), null);
		for (ObjectName name : names) {
			String protocol = (String) server.getAttribute(name, "protocol");
			if (TOMCAT_HTTP_PROTOCOL.equals(protocol)) {
				Object o = server.getAttribute(name, "address");
				String ip = o.toString().substring(1);
				int port = (Integer)server.getAttribute(name, "port");
				return ip+port;
			}

		}

		throw new Exception("CommonHelper get http port error");
	}

}
