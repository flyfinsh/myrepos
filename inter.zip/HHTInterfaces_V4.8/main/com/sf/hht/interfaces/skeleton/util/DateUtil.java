/***********************************************************************
 * Copyright sf.
 * All rights reserved. 
 *
 * HISTORY
 ***********************************************************************
 *  ID      DATE                PERSON            REASON
 *  1      2008-06-04            魏嘉盛              创建
 
 ************************************************************************
 */
package com.sf.hht.interfaces.skeleton.util;

import java.text.FieldPosition;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 日期工具类
 */

public class DateUtil {

	/**
	 * 日志处理类
	 */
	private static final Log log = LogFactory.getLog(DateUtil.class);

	/**
	 * 默认的日期转化格式
	 */

	public static final String DEAULT_DATE_FORMAT = "yyyy-MM-dd";

	/**
	 * 将日期类型转化为简单日期类型
	 * 
	 * @param calendar
	 * @return Date
	 */
	public static Date getSimpleDate(Date calendar) {
		Date resultDate = null;
		SimpleDateFormat sdf = new SimpleDateFormat(DEAULT_DATE_FORMAT);
		StringBuffer result = new StringBuffer();
		sdf.format(calendar, result, new FieldPosition(0));
		try {
			resultDate = sdf.parse(result.toString());
		} catch (ParseException e) {
			log.error(" date format error: " + e);
		}
		return resultDate;
	}

	/**
	 * 与系统当前的时差 ：N 天
	 * 
	 * @param SysDate
	 * @param BarScanDate
	 * @return
	 */
	public static int getDayDiff(Date BarCompareDate) {
		// 与当前系统时间差
		long lDayDiff = Math.abs(System.currentTimeMillis() - BarCompareDate.getTime()) ;
		lDayDiff = lDayDiff / 1000 / 60 / 60 / 24;
//		int nDayDiff = new Long(lDayDiff).intValue();
		int nDayDiff = Long.valueOf(lDayDiff).intValue();
		return nDayDiff;

	}

	/**
	 * 
	 * 2个时间日期互换成新的时间日期 如 Dt1：2008-01-01 01：02：03 Dt2：2007-01-02 03：02：01 用Dt1的日期
	 * + Dt2的时间 New：2008-01-01 03：02：01
	 * 
	 * @param Dt1
	 * @param Dt2
	 * @return
	 */
	public static long trangeDayAndTimeBak(Date Dt1, Date Dt2) {

		// 计算日期的 某天0点的毫秒数
		long DayMinsec = DateUtil.getSimpleDate(Dt1).getTime();

		// 计算时间毫秒数
		Calendar cal = Calendar.getInstance();
		cal.setTime(Dt2);
		int Hour = cal.get(Calendar.HOUR);
		int Min = cal.get(Calendar.MINUTE);
		int Sec = cal.get(Calendar.SECOND);
		// 时分秒 的 毫秒数
		long timeMinsec = Hour * 60 * 60 * 1000 + Min * 60 * 1000 + Sec * 1000;
		// 新的时间毫秒数
		long newDaysec = DayMinsec + timeMinsec;

		/*
		 * // test output SimpleDateFormat bartDateFormat = new
		 * SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		 * System.out.println("Test DateUtil.trangeDayAndTimeBak " +
		 * bartDateFormat.format(newDaysec));
		 */
		return newDaysec;

	}

	/**
	 * 
	 * 2个时间日期互换成新的时间日期 如 Dt1：2008-01-01 01：02：03 Dt2：2007-01-02 03：02：01 用Dt1的日期
	 * +Dt2的时间 New：2008-01-01 03：02：01
	 * 
	 * @param type
	 *            : 1 : 表示要互换 否则 就用dt1的时间
	 * @param Dt1
	 * @param Dt2
	 * @return
	 */
	public static Date trangeDayAndTime(boolean type, Date dt1, Date dt2) {

		Date result = null;
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String s = (new SimpleDateFormat("yyyy-MM-dd")).format(dt1) + " "
				+ (new SimpleDateFormat("HH:mm:ss")).format(dt2);
		try {
			if (type)
				result = sf.parse(s);
			else
				result = dt1;
			// System.out.println("Test DateUtil.trangeDayAndTime " + result);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return result;
	}
}
