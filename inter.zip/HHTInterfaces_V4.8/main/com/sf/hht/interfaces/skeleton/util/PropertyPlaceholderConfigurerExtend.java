package com.sf.hht.interfaces.skeleton.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

public class PropertyPlaceholderConfigurerExtend extends PropertyPlaceholderConfigurer{

	public void setFileName(String fileName) {
		
		Resource resource = new FileSystemResource(System.getenv("CONF_PATH") + File.separator + fileName);
		super.setLocation(resource);
	}
	
	public void setFileNames(String [] fileNames) {
		
		List<Resource> resources = new ArrayList<Resource>();
		for (String fileName : fileNames) {
			Resource resource = new FileSystemResource(System.getenv("CONF_PATH") + File.separator + fileName);
			resources.add(resource);
		}
		
		super.setLocations(resources.toArray(new Resource[resources.size()]));
	}
}
