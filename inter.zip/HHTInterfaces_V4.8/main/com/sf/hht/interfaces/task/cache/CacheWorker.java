package com.sf.hht.interfaces.task.cache;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.sf.hht.interfaces.skeleton.cache.Employee;
import com.sf.hht.interfaces.skeleton.cache.Reason;
import com.sf.hht.interfaces.skeleton.cache.WantedReasonCache;
import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.resource.DBManager;

public class CacheWorker extends TaskWorker {

	private static final Logger logger = Logger.getLogger(CacheWorker.class);

	private static final String sql_load_wantedResaon = "select code,content from reasoncode where reasontype=3";
	private static final String SQL_LOAD_EMPLOYEE = "select empid, deptid from employee where deptid is not null";

	private DBManager dbManager;

	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}
	
	@Override
	public void preprocess() {
		//do nothing
	}
	
	@Override
	protected void execute() {
		logger.info("CacheWorker start");
		
		while (running) {
			try {
				loadWantedReason();
				
				loadEmployee();
			
				makeWait(task.getPeriod());
			} catch (Exception e) {
				logger.error("Exception Occured", e);
			}
		}
		
		logger.info("CacheWorker end");
	}
	
	private void loadWantedReason() {
		List<Reason> records = new ArrayList<Reason>();
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			conn = dbManager.getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql_load_wantedResaon);
			
			Reason reason;
			while (rs.next()) {
				reason = new Reason();
				
				reason.setCode(rs.getString("code"));
				reason.setContent(rs.getString("content"));
				
				logger.info("Wanted reason: " + reason.getCode() + "--" + reason.getContent());
				
				records.add(reason);
			}
			
			WantedReasonCache.setCache(records);
			
		} catch (Exception e) {
			logger.error("Exception Occured when loading wanted reason", e);
		} finally {
			dbManager.close(rs);
			dbManager.close(stmt);
			dbManager.close(conn);
		}
	}
	
	private void loadEmployee(){
		List<Employee> list = new ArrayList<Employee>();
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			conn = dbManager.getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(SQL_LOAD_EMPLOYEE);
			
			Employee employee = null;
			
			while (rs.next()) {
				employee = new Employee();
				
				employee.setDeptId(rs.getString("deptid"));
				employee.setEmpId(rs.getString("empid"));
				
				list.add(employee);
			}
			
			WantedReasonCache.setEmpCache(list);
			
		} catch (Exception e) {
			logger.error("Exception Occured when loading dept info", e);
		}finally{
			dbManager.close(rs);
			dbManager.close(stmt);
			dbManager.close(conn);
		}
	}

}