package com.sf.hht.interfaces.task.carrybill;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;

import com.sf.framework.integration.ISGConverter;
import com.sf.framework.integration.SGConverterException;
import com.sf.framework.integration.dto.SGTransferObject;
import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.log.ErrorDataLog;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.resource.MQManager;
import com.sf.hht.interfaces.skeleton.util.CommonHelper;
import com.sf.integration.hht.dto.CarrybillTO;

public class CarrybillWorker extends TaskWorker {

	private static final Logger logger = Logger.getLogger(CarrybillWorker.class);

	private static final String sql_before_load = "update carrybill_tmp set server_id = ?, send_thread = ?, send_status = 1, send_tm = sysdate where send_status = 0 and rownum <= ?";
	private static final String sql_load_record = "select cast(rowid as varchar2(36)) as id,bno,orderid,worktime,workdate from carrybill_tmp where server_id = ? and send_thread = ? and send_status = 1 and rownum <= ?";
	private static final String sql_after_delete = "delete from carrybill_tmp where rowid = ?";
	// 数据接管
	private static final String SQL_RESET_STATUS = "update carrybill_tmp set send_status = 0 where send_status = 1 and send_tm < (sysdate - 10 / (24 * 60))";
	
	// 下次执行接口表状态复位时间
	private long nextResetTime = 0;

	private DBManager dbManager;
	private MQManager mqManager;
	private Destination queue;
	private ISGConverter sgConverter;
	
	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}
	public void setMqManager(MQManager mqManager) {
		this.mqManager = mqManager;
	}
	public void setQueue(Destination queue) {
		this.queue = queue;
	}
	public void setSgConverter(ISGConverter sgConverter) {
		this.sgConverter = sgConverter;
	}

	@Override
	public void preprocess() {
	}
	
	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("CarrybillWorker[").append(Thread.currentThread().getId()).append("]");
		
		logger.info(logPrefix.toString() + " start");
		
		while (running) {
			try {
				int handleRows = handleRecords(logPrefix.toString());
				
				if (System.currentTimeMillis() > nextResetTime) {
					// 更新处理失败数据状态
					int count = resetStatus();
					
					logger.info("CarrybillWorker reset record status count->"+count);
					
					// 设置下次执行复位操作的时间为：10分钟之后
					nextResetTime = System.currentTimeMillis() + (10 * 60 * 1000);
				}
			
				if (handleRows < task.getRecordSize()) {
					makeWait(task.getPeriod());
				}
			} catch (Exception e) {
				logger.error("Exception Occured", e);
			}
		}
		
		logger.info(logPrefix + " end");
	}
	
	
	private int handleRecords(String logPrefix) {
		List<CarrybillTO> records = new ArrayList<CarrybillTO>();
		
		javax.jms.Connection mqConn = null;
		Session session = null;
		MessageProducer producer = null;
		
		java.sql.Connection dbConn = null;
		
		try {
			//update send_statua
			beforeLoadRecords();
			
			dbConn = dbManager.getConnection();
			
			dbConn.setAutoCommit(false);
			
			loadRecords(dbConn, records);
			
			int loadSize = records.size();
			
			if (loadSize > 0) {
				
				mqConn = mqManager.getConnection();
				session = mqConn.createSession(false, Session.AUTO_ACKNOWLEDGE);
				producer = session.createProducer(queue);
				producer.setDeliveryMode(DeliveryMode.PERSISTENT);
				TextMessage textMessage = session.createTextMessage();
				
				for (CarrybillTO to : records) {
					//获得事务ID号，并将TO对象中的事务ID号清空
					String id = to.getMemo();
					to.setMemo("");

					try {
						sendToMQ(producer, textMessage, to);
					} catch (SGConverterException ce) {
						//数据异常单独记录日志文件,然后删除数据库记录
						ErrorDataLog.error("Carrybill[" + to.getBno() + " " + to.getOrderId() + " " + to.getWorkDate() + " " + to.getWorkTime() + "]");
					} catch (Exception e) {
						//其它异常则不删除数据库记录,等待下次继续发送
						logger.error("Failed to send Carrybill to MQ!", e);
						
						continue;
					}
					
					if (logger.isDebugEnabled()) {
						logger.debug("Sended Carrybill to MQ successfully! bno--" + to.getBno());
					}

					deleteRecords(dbConn, id);
				}
				
				logger.info(logPrefix + "--Handled " + loadSize + " record(s)");
			}
			
			dbConn.commit();
			dbConn.setAutoCommit(true);
			
			return loadSize;
		} catch (Exception e) {
			logger.error("Exception Occured when sending Carrybill", e);

			try {
				if (dbConn != null) {
					dbConn.rollback();
				}
			} catch (SQLException e1) {
				logger.error(e1);
			}
		} finally {
			mqManager.close(producer);
			mqManager.close(session);
			mqManager.close(mqConn);
			
			dbManager.close(dbConn);
		}
		
		return -1;
	}
	
	private int beforeLoadRecords() throws SQLException {
		int affectRecordCount = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		
		try {
			conn = dbManager.getConnection();
			
			pstmt = conn.prepareStatement(sql_before_load);
			pstmt.setString(1, CommonHelper.getServerId());
			pstmt.setLong(2, Thread.currentThread().getId());
			pstmt.setLong(3, task.getRecordSize());
			
			affectRecordCount = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			
			throw new RuntimeException(e);
		}finally{
			dbManager.close(pstmt);
			dbManager.close(conn);
		}
		
		return affectRecordCount;
	}
	
	private void loadRecords(java.sql.Connection conn, List<CarrybillTO> records) 
			throws SQLException {

		PreparedStatement pstmt = conn.prepareStatement(sql_load_record);
		pstmt.setString(1, CommonHelper.getServerId());
		pstmt.setLong(2, Thread.currentThread().getId());
		pstmt.setLong(3, task.getRecordSize());
		ResultSet rs = pstmt.executeQuery();
		
		CarrybillTO to;
		while (rs.next()) {
			to = new CarrybillTO();
			
			to.setBno(rs.getString("bno"));
			to.setOrderId(rs.getString("orderid"));
			to.setWorkTime(rs.getString("worktime"));
			to.setWorkDate(rs.getString("workdate"));

			// 暂时缓存，用于后续的转移数据和删除数据，在发送MQ消息时，要清空
			to.setMemo(rs.getString("id"));

			records.add(to);
		}
		
		dbManager.close(rs);
		dbManager.close(pstmt);
	}
	
	private void sendToMQ(MessageProducer producer, TextMessage msg, SGTransferObject to) 
			throws SGConverterException, JMSException {
		String xml = sgConverter.toXML(to);
		
		msg.clearBody();
		msg.setText(xml);
		
		producer.send(msg);
	}
	
	private void deleteRecords(java.sql.Connection conn, String id) 
			throws SQLException {
		PreparedStatement pstmt = null;
		
		//删除数据
		pstmt = conn.prepareStatement(sql_after_delete);
		pstmt.setString(1, id);
		pstmt.executeUpdate();
		
		dbManager.close(pstmt);
	}
	
	
	/**
	 * 重置发送失败数据状态
	 * Aug 12, 2013
	 * @return
	 */
	private int resetStatus(){
		int count = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = dbManager.getConnection();
			
			pstmt = conn.prepareStatement(SQL_RESET_STATUS);
			count = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			dbManager.close(pstmt);
			dbManager.close(conn);
		}
		
		return count;
	}
	
}