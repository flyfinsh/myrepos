package com.sf.hht.interfaces.task.ccustinfo;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.rpc.ServiceException;

import org.apache.log4j.Logger;

import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.task.ccustinfo.ws.DistRms;
import com.sf.hht.interfaces.task.ccustinfo.ws.IDistRmsServiceServiceLocator;

public class CCustInfoWorkder extends TaskWorker {
	
	private static final Logger LOG = Logger.getLogger(CCustInfoWorkder.class);
	private static final SimpleDateFormat SDF_HMD_HMS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	private static final String SQL_INSERT_C_CUST_INFO = "insert into hht_int_c_cust_info_sss(id, sync_id, waybill_no, emp_code, dept_code, info, create_tm_stamp, create_date) values(SEQ_HHT_INT_C_CUST_INFO_SSS.nextval,?,?,?,?,?,?,?)";
	private static final String SQL_QUERY_MAX_SEQ_ID = "select max(sync_id) from hht_int_c_cust_info_sss";
	
	private DBManager dbManager;
	// WebService 地址
	private String wsUrl;
	
	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}

	public void setWsUrl(String wsUrl) {
		this.wsUrl = wsUrl;
	}
	
	@Override
	public void preprocess() {}

	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("CCustInfoWorkder[").append(Thread.currentThread().getId()).append("]");
		
		LOG.info(logPrefix.toString() + " start");
		
		while(running){
			try {
				receive();
				
				Thread.sleep(task.getPeriod());
			} catch (Exception e) {
				e.printStackTrace();
				LOG.error("CCustInfoWorkder sync data exception ", e);
			}
		}
		
		LOG.info(logPrefix + " end");
	}
	
	/**
	 * 接收同步过来的数据并且保存
	 * Nov 7, 2013
	 */
	private void receive(){
		Connection conn = null;
		
		try {
			conn = dbManager.getConnection();
			
			// 同步数据开始ID
			Long beginSeqId = queryMaxSeqId(conn);
			
			// 调用webservice获取数据
			DistRms[] distRms = loadRecords(beginSeqId, task.getRecordSize());
			
			if (distRms != null && distRms.length > 0) {
				// 保存数据
				save(conn, distRms);
				
				LOG.info("CCustInfoWorkder sync count :　" + distRms.length);
			}else {
				LOG.info("CCustInfoWorkder sync count :　" + 0);
			}
			
			LOG.info("CCustInfoWorkder save data successfully");
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error("CCustInfoWorkder receive data exception ", e);
		}finally{
			dbManager.close(conn);
		}
	}
	
	/**
	 * webservice加载数据
	 * Nov 7, 2013
	 * @param beginNum
	 * @param count
	 * @return
	 */
	private DistRms[] loadRecords(long beginNum, int count){
		
		try {
			LOG.info("CCustInfoWorkder WebService call start time : " + SDF_HMD_HMS.format(new Date()));
			
			IDistRmsServiceServiceLocator locator = new IDistRmsServiceServiceLocator();
			DistRms[] result = locator.getIDistRmsServicePort(new URL(wsUrl)).getDistRms(beginNum, count);

			LOG.info("CCustInfoWorkder WebService call end time : " + SDF_HMD_HMS.format(new Date()));
			
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error("CCustInfoWorkder WebService call failure, Exception", e);
		}
		
		return null;
	}
	
	/**
	 * 保存C类客户信息
	 * Nov 7, 2013
	 * @param distRms
	 * @throws SQLException 
	 */
	private void save(Connection conn, DistRms[] distRms) throws SQLException{
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(SQL_INSERT_C_CUST_INFO);
			
			for (DistRms distRm : distRms) {
				pstmt.setLong(1, distRm.getSeqId());
				pstmt.setString(2, distRm.getWaybillNo());
				pstmt.setString(3, distRm.getEmpCode());
				pstmt.setString(4, distRm.getDeptCode());
				pstmt.setString(5, distRm.getInfo());
				pstmt.setLong(6, distRm.getCreateTime());
				
				try{
					pstmt.setString(7, SDF_HMD_HMS.format(new java.sql.Date(distRm.getCreateTime())));
				}catch (Exception e) {
					LOG.error("CCustInfoWorkder create time change failure, Exception", e);
					e.printStackTrace();
				}
				
				pstmt.addBatch();
			}
			
			pstmt.executeBatch();
		} finally{
			dbManager.close(pstmt);
		}
	}
	
	/**
	 * 查询最大同步ID
	 * Nov 7, 2013
	 * @param conn
	 * @return
	 * @throws SQLException
	 */
	private Long queryMaxSeqId(Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		Long seqId = 0L;
		
		try {
			pstmt = conn.prepareStatement(SQL_QUERY_MAX_SEQ_ID);
			rs = pstmt.executeQuery();
			
			if (rs != null && rs.next()) {
				seqId = rs.getLong(1);
			}
		}finally {
			dbManager.close(rs);
			dbManager.close(pstmt);
		}
		
		return seqId;
	}
	
	public static void main(String[] args) throws RemoteException, MalformedURLException, ServiceException {
//		BigDecimal curVer = new BigDecimal("12.7");
//		BigDecimal bdLastVer = new BigDecimal("12.6");
//		System.out.println(curVer.subtract(bdLastVer).abs());
//		System.out.println(Math.abs(0 - 18.3));
		
//		IDistRmsServiceServiceLocator locator = new IDistRmsServiceServiceLocator();
//		DistRms[] result = locator.getIDistRmsServicePort(new URL("http://10.0.10.42:8080/addr_ident_dc_web/ws/distRmsService")).getDistRms(0, 1000);
//		
//		System.out.println(result.length);
		
		
//		System.out.println(new Date(32132123121313L));
		
		System.out.println(SDF_HMD_HMS.format(new java.sql.Date(11332123121313L)));
	}
}
