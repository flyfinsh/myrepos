/**
 * IDistRmsService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.task.ccustinfo.ws;

public interface IDistRmsService extends java.rmi.Remote {
    public com.sf.hht.interfaces.task.ccustinfo.ws.DistRms[] getDistRms(long beginNum, int count) throws java.rmi.RemoteException;
}
