/**
 * IDistRmsServiceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.task.ccustinfo.ws;

public interface IDistRmsServiceService extends javax.xml.rpc.Service {
    public java.lang.String getIDistRmsServicePortAddress();

    public com.sf.hht.interfaces.task.ccustinfo.ws.IDistRmsService getIDistRmsServicePort() throws javax.xml.rpc.ServiceException;

    public com.sf.hht.interfaces.task.ccustinfo.ws.IDistRmsService getIDistRmsServicePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
