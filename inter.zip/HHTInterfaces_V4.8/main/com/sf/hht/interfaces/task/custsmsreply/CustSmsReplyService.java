package com.sf.hht.interfaces.task.custsmsreply;

import java.util.List;

import javax.jws.WebService;

@WebService
public interface CustSmsReplyService {
	
	/**
	 * 将推送的客户回复内容更新到表cust_sms_reply客户回复字段，更新条件：推送ID与表ID相同
	 * Nov 3, 2014
	 * @param custSmsReplyList
	 * @return
	 */
	public String pushCustSmsReply(List<CustSmsReplyTo> custSmsReplyList);
}
