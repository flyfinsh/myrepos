package com.sf.hht.interfaces.task.custsmsreply;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

import com.sf.hht.interfaces.skeleton.resource.DBManager;

public class CustSmsReplyServiceImpl implements CustSmsReplyService {
	
	// 成功
	private static final String SUCCESS = "1000";
	// 失败
	private static final String SYSERR = "1001";
	// 数据不合法
	private static final String DATA_NOT_AVAILABLE = "1002";
	
	private DBManager dbManager;
	
	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}

	@Override
	public String pushCustSmsReply(List<CustSmsReplyTo> custSmsReplyList) {
		if (!valid(custSmsReplyList)) {
			System.out.println("Webservice CustSmsReplyService request parameter not available");
			return DATA_NOT_AVAILABLE;
		}
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try{
			String sql = "update sms_research set cust_reply = ?, cust_reply_update_tm = sysdate where id = ?";
			
			conn = dbManager.getConnection();
			pstmt = conn.prepareStatement(sql);
			conn.setAutoCommit(false);
			
			for (CustSmsReplyTo to : custSmsReplyList) {
				pstmt.setString(1, to.getCustSmsReply());
				pstmt.setLong(2, to.getId());
				pstmt.addBatch();
			}
			
			pstmt.executeBatch();
			conn.commit();
			
			System.out.println("Webservice CustSmsReplyService handle successfully, size->"+custSmsReplyList.size());
			
			return SUCCESS;
		}catch (Exception e) {
			System.out.println("Webservice CustSmsReplyService system error");
			e.printStackTrace();
			
			try {
				if(conn != null){
					conn.rollback();
				}
			} catch (Exception sqle) {
				sqle.printStackTrace();
			}
			
			return SYSERR;
		}finally{
			dbManager.close(pstmt);
	        dbManager.close(conn);
		}
	}
	
	private boolean valid(List<CustSmsReplyTo> custSmsReplyList){
		if (custSmsReplyList == null) {
			System.out.println("Webservice CustSmsReplyService request parameter not available");
			return false;
		}
		
		for(CustSmsReplyTo to : custSmsReplyList){
			if (to == null) {
				return false;
			}
			
			if (to.getId() == null) {
				return false;
			}
			
			if (to.getCustSmsReply() == null || to.getCustSmsReply().trim().length() == 0) {
				return false;
			}
		}
		
		return true;
	}

	/**
	 * description
	 * Nov 3, 2014
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
