package com.sf.hht.interfaces.task.custsmsreply;

public class CustSmsReplyTo {
	
	private Long id;
	
	private String custSmsReply;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCustSmsReply() {
		return custSmsReply;
	}

	public void setCustSmsReply(String custSmsReply) {
		this.custSmsReply = custSmsReply;
	}
	
}
