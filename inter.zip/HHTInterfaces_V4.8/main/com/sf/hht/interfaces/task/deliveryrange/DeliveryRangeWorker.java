package com.sf.hht.interfaces.task.deliveryrange;

import java.io.ByteArrayInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.task.deliveryrange.to.DeliveryRangeTO;
import com.sf.hht.interfaces.task.deliveryrange.ws.Hhtservice_ServiceLocator;

public class DeliveryRangeWorker extends TaskWorker {
	
	private static final Logger LOG = Logger.getLogger(DeliveryRangeWorker.class);
	
	private static final SimpleDateFormat SDF_HMD_HMS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	private static final String SQL_INSERT_DELIVERY_RANGE = "insert into pd_delivery_range(id, goods_type_code, goods_type_name, city_code, city_name, create_tm) values(SEQ_PD_ID.NEXTVAL,?,?,?,?,sysdate)";
	private static final String SQL_DELETE_DELIVERY_RANGE = "delete from pd_delivery_range";
	
	private DBManager dbManager;
	// WebService 地址
	private String wsUrl;
	// 每天同步开始时间
	private int syncHour;
	
	@Override
	public void preprocess() {
	}

	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("DeliveryRangeWorker[").append(Thread.currentThread().getId()).append("]");
		
		LOG.info(logPrefix.toString() + " start");
		
		boolean isComplete = false;
		
		while (running) {
			try{
				if (!runTask()) {
					isComplete = false;
					makeWait(task.getPeriod());
					continue;
				}else {
					if (isComplete) {
						makeWait(task.getPeriod());
						continue;
					}
				}
				
				receive();
				isComplete = true;
			}catch (Exception e) {
				LOG.error("DeliveryRangeWorker sync data exception ", e);
			}
		}

		LOG.info(logPrefix + " end");
	}
	
	/**
	 * 接收兵器保存数据 
	 * Apr 26, 2013
	 */
	private void receive(){
		Connection conn = null;
		
		// 调用WebService接口获取怕送范围xml
		String xml = loadRecords();
		
		// 解析xml成对象
		List<DeliveryRangeTO> list = parseXmlToObj(xml);
		
		try {
			conn = dbManager.getConnection();
			conn.setAutoCommit(false);
			
			if (list != null && list.size() > 0) {
				// 删除所有派送范围数据
				deleteDeliveryRange(conn);
				// 保存最新派送范围数据
				insertDeliveryRange(conn, list);
			}else {
				LOG.info("DeliveryRangeWorker call webservice response null");
			}
			
			conn.commit();
			
			LOG.info("DeliveryRangeWorker save delivery range successfully");
		} catch (Exception e) {
			try {
				// 数据回滚
				conn.rollback();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			
			e.printStackTrace();
			LOG.error("DeliveryRangeWorker receive data exception ", e);
		}finally{
			try {
				if (conn != null) {
					conn.setAutoCommit(true);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			dbManager.close(conn);
		}
	}

	private String loadRecords(){
		String xml = null;
		
		try {
			LOG.info("DeliveryRangeWorker WebService call start time : " + SDF_HMD_HMS.format(new Date()));
			
			Hhtservice_ServiceLocator locator = new Hhtservice_ServiceLocator();
			xml = locator.gethhtserviceSOAP(new URL(wsUrl)).goodsScope("HHT");
			
			LOG.info("DeliveryRangeWorker WebService call end time : " + SDF_HMD_HMS.format(new Date()));
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error("DeliveryRangeWorker WebService call failure, Exception", e);
		}
		
		return xml;
	}
	
	/**
	 * xml转换成对象
	 * Apr 25, 2013
	 * @param xml
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private List<DeliveryRangeTO> parseXmlToObj(String xml){
		List<DeliveryRangeTO> list = new ArrayList<DeliveryRangeTO>();
		
		try {
//			System.out.println(xml);
//			ByteArrayInputStream is = new ByteArrayInputStream(xml.getBytes());
//			org.dom4j.io.SAXReader reader = new SAXReader();
//			reader.setEncoding("gbk");
//			Document doc = reader.read(is);
			
			Document doc = DocumentHelper.parseText(xml);
			
			List eleList = doc.selectNodes("/list/item");
			
			if (eleList != null) {
				for (int i = 0; i < eleList.size(); i++) {
					Element element = (Element) eleList.get(i);
					
					String goodsTypeCode = null;
					String goodsTypeName = null;
					String cityCode = null;
					String cityName = null;
					
					for(Iterator iterotor = element.elementIterator(); iterotor.hasNext();){
						Element e = (Element) iterotor.next();
						String nodeName = e.getName() != null ? e.getName().toLowerCase() : "";
						
						if ("class".equals(nodeName)) {
							goodsTypeCode = e.attributeValue("code");
							goodsTypeName = e.getText();
						}
						
						if ("city_list".equals(nodeName)) {
							for (Iterator it = e.elementIterator(); it.hasNext();) {
								Element subEle = (Element) it.next();
								cityCode = subEle.attributeValue("code");
								cityName = subEle.getText();
								
								DeliveryRangeTO to = new DeliveryRangeTO();
								to.setGoodsTypeCode(goodsTypeCode);
								to.setGoodsTypeName(goodsTypeName);
								to.setCityCode(cityCode);
								to.setCityName(cityName);
								list.add(to);
							}
						}
					}
				}
			}
		} catch (Exception e) {
			LOG.error("DeliveryRangeWorker parse xml failure, Exception", e);
			e.printStackTrace();
		}
		
		return list;
	}
	
	/**
	 * 保存派送范围数据
	 * Apr 25, 2013
	 * @param conn
	 * @param list
	 * @throws SQLException
	 */
	private void insertDeliveryRange(Connection conn, List<DeliveryRangeTO> list) throws SQLException{
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(SQL_INSERT_DELIVERY_RANGE);
			
			if (list != null) {
				for (DeliveryRangeTO to : list) {
					pstmt.setString(1, to.getGoodsTypeCode());
					pstmt.setString(2, to.getGoodsTypeName());
					pstmt.setString(3, to.getCityCode());
					pstmt.setString(4, to.getCityName());
					pstmt.addBatch();
				}
				
				pstmt.executeBatch();
			}
		} finally {
			dbManager.close(pstmt);
		}
	}
	
	/**
	 * 删除所有派送范围数据
	 * Apr 25, 2013
	 * @param conn
	 * @throws SQLException 
	 */
	private void deleteDeliveryRange(Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(SQL_DELETE_DELIVERY_RANGE);
			pstmt.executeUpdate();
		} finally {
			dbManager.close(pstmt);
		}
	}
	
	/**
	 * 判断任务是否运行
	 * Apr 26, 2013
	 * @return
	 */
	private boolean runTask(){
		Calendar curDate = Calendar.getInstance();
		
		int hour = curDate.get(Calendar.HOUR_OF_DAY);
		
		if(hour == syncHour){
			return true;
		}
		
		return false;
	}
	
	
	/**************get/set方法******************/
	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}

	public void setWsUrl(String wsUrl) {
		this.wsUrl = wsUrl;
	}

	public void setSyncHour(int syncHour) {
		this.syncHour = syncHour;
	}
	
	public static void main(String[] args) {
		StringBuffer xml = new StringBuffer();
//		xml.append("<list>");
//		xml.append("  <item>");
//		xml.append("  	<class code=\"111\">茶叶</class>");
//		xml.append("  	<city_list>");
//		xml.append("  		<city code=\"010\">北京</city>");
//		xml.append("  		<city code=\"020\">广州</city>");
//		xml.append("  	</city_list>");
//		xml.append("  </item>");
//		xml.append(" </list>");
		
		xml.append("<list><item><class code=\"5\">春茶配送范围模板</class><city_list><city code=\"010\">北京市</city><city code=\"020\">广州市</city><city code=\"755\">深圳市</city></city_list></item></list>");
		
		DeliveryRangeWorker worker = new DeliveryRangeWorker();
		List<DeliveryRangeTO> list = worker.parseXmlToObj(xml.toString());
		System.out.println(list.get(0).getCityName());
	}
}
