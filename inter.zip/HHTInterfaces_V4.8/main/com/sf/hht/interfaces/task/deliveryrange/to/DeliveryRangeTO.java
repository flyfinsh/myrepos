package com.sf.hht.interfaces.task.deliveryrange.to;

public class DeliveryRangeTO {
	// 商品分类代码
	private String goodsTypeCode;
	
	// 商品分类名称
	private String goodsTypeName;
	
	// 城市代码
	private String cityCode;
	
	// 城市名称
	private String cityName;

	

	public String getGoodsTypeCode() {
		return goodsTypeCode;
	}

	public void setGoodsTypeCode(String goodsTypeCode) {
		this.goodsTypeCode = goodsTypeCode;
	}

	public String getGoodsTypeName() {
		return goodsTypeName;
	}

	public void setGoodsTypeName(String goodsTypeName) {
		this.goodsTypeName = goodsTypeName;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
}
