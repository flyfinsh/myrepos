/**
 * Hhtservice_Port.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.task.deliveryrange.ws;

public interface Hhtservice_Port extends java.rmi.Remote {
    public boolean addOrder(java.lang.String phone, java.lang.String no, java.lang.String addTime, java.lang.String cardNum, java.lang.String code) throws java.rmi.RemoteException;
    public java.lang.String goodsScope(java.lang.String sys) throws java.rmi.RemoteException;
}
