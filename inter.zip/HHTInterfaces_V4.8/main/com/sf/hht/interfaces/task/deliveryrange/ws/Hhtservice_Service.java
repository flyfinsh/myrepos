/**
 * Hhtservice_Service.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.task.deliveryrange.ws;

public interface Hhtservice_Service extends javax.xml.rpc.Service {
    public java.lang.String gethhtserviceSOAPAddress();

    public com.sf.hht.interfaces.task.deliveryrange.ws.Hhtservice_Port gethhtserviceSOAP() throws javax.xml.rpc.ServiceException;

    public com.sf.hht.interfaces.task.deliveryrange.ws.Hhtservice_Port gethhtserviceSOAP(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
