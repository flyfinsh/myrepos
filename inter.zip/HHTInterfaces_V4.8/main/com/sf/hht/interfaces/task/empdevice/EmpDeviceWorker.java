package com.sf.hht.interfaces.task.empdevice;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;

import com.sf.framework.integration.ISGConverter;
import com.sf.framework.integration.SGConverterException;
import com.sf.framework.integration.converter.JiBXConverter;
import com.sf.framework.integration.dto.SGTransferObject;
import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.log.ErrorDataLog;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.resource.MQManager;

public class EmpDeviceWorker extends TaskWorker{
	
	private static final Logger LOG = Logger.getLogger(EmpDeviceWorker.class);
	
	// 重试次数
	private static final int RETRY_LIMIT = 3;
	// 重试时间间隔
	private static final int RETRY_PERIOD = 5000;
	
//	private static final String SQL_LOAD_RECORDS = "select e3.empid, e1.imsi, e2.lastdate, e3.deptid, e3.emptel"
//			+ " from hht.empdevice e1,"
//            + " (select t.empid, max(nvl(t.modifydate, t.createdate)) lastdate"
//            + " from hht.empdevice t"
//            + " group by t.empid) e2,"
//            + " hht.employee e3"
//            + " where e1.empid = e2.empid"
//            + " and nvl(e1.modifydate, e1.createdate) = e2.lastdate"
//            + " and e3.empid = e2.empid"
//            + " and e2.lastdate >= to_char(add_months(trunc(sysdate), -1)+1, 'yyyy-mm-dd')"
//            + " and e2.lastdate < to_char(trunc(sysdate), 'yyyy-mm-dd')"
//            + " and rownum > ?"
//            + " and rownum <= ?";
	
	private static final StringBuffer SQL_LOAD_RECORDS = new StringBuffer();
	static{
		SQL_LOAD_RECORDS.append("		select *");
		SQL_LOAD_RECORDS.append("		  from (select e3.empid,");
		SQL_LOAD_RECORDS.append("		               e1.imsi,");
		SQL_LOAD_RECORDS.append("		               e2.lastdate,");
		SQL_LOAD_RECORDS.append("		               e3.deptid,");
		SQL_LOAD_RECORDS.append("		               e3.emptel,");
		SQL_LOAD_RECORDS.append("		               rownum rno");
		SQL_LOAD_RECORDS.append("		          from hht.empdevice e1,");
		SQL_LOAD_RECORDS.append("		               (select t.empid, max(nvl(t.modifydate, t.createdate)) lastdate");
		SQL_LOAD_RECORDS.append("		                  from hht.empdevice t");
		SQL_LOAD_RECORDS.append("		                 group by t.empid) e2,");
		SQL_LOAD_RECORDS.append("		               hht.employee e3");
		SQL_LOAD_RECORDS.append("		         where e1.empid = e2.empid");
		SQL_LOAD_RECORDS.append("		           and nvl(e1.modifydate, e1.createdate) = e2.lastdate");
		SQL_LOAD_RECORDS.append("		           and e3.empid = e2.empid");
		SQL_LOAD_RECORDS.append("		           and e2.lastdate >=");
		SQL_LOAD_RECORDS.append("		               to_char(add_months(trunc(sysdate), -1) + 1, 'yyyy-mm-dd')");
		SQL_LOAD_RECORDS.append("		           and e2.lastdate <= to_char(trunc(sysdate), 'yyyy-mm-dd')");
		SQL_LOAD_RECORDS.append("		           and rownum <= ?)");
		SQL_LOAD_RECORDS.append("		 where rno > ?");
	}
	
	// 数据库连接管理
	private DBManager dbManager;
	// 队列管理器
	private MQManager mqManager;
	// ADCM目标队列
	private Destination queueADCM;
	// 转换器
	private ISGConverter sgConverter;
	
	// 同步日期，默认是每月20日
	private int syncDay;
	// 同步时间，默认是18点
	private int syncHour;

	@Override
	public void preprocess() {
		
	}
	
	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("EmpdeviceWorker[").append(Thread.currentThread().getId()).append("]");
		LOG.info(logPrefix.toString() + " start");
		
		int startRowNum = 0;
		int endRowNum = 0;
		boolean isComplete = false;
		
		while(running){
			
			// 定时执行该任务，默认是每个月20日18:00以后
			if(!runTask()){
				// 重置参数
				isComplete = false;
				startRowNum = 0;
				endRowNum = 0;
				
				makeWait(task.getPeriod());
				continue;
			}else{
				if (isComplete) {
					makeWait(task.getPeriod());
					continue;
				}
			}
			
			int retryNum = 0;
			
			try{
				endRowNum = startRowNum + task.getRecordSize();
				int handleRows = handleRecords(logPrefix.toString(), startRowNum, endRowNum);
				startRowNum = endRowNum;
				
				if (handleRows < task.getRecordSize()) {
					isComplete = true;	// 数据发送完成，当天不再发送数据
				}
				
			}catch(Exception e){
				if(retryNum < RETRY_LIMIT){
					makeWait(RETRY_PERIOD);
					LOG.error("Database or MQ exception, retry number : "+ retryNum + ", exception : " + e.toString());
				}else{
					LOG.error("EmpdeviceWorker will be break");
					break;
				}
			}
		}
		
		LOG.info(logPrefix.toString() + " end");
	}
	
	/**
	 * 加载数据并且将数据发送到队列
	 * Jun 28, 2012
	 * @param logPrefix
	 */
	private int handleRecords(String logPrefix, int startRowNum, int endRowNum) throws Exception {
		// 查询结果记录集
		List<EmpDeviceTO> records = new ArrayList<EmpDeviceTO>();
		
		javax.jms.Connection mqConn = null;
		Session session = null;
		MessageProducer producerADCM = null;
		
		java.sql.Connection dbConn = null;
		
		try{
			// 获取数据库连接
			dbConn = dbManager.getConnection();
			
			// 加载数据到集合
			loadRecords(dbConn, records, startRowNum, endRowNum);
			int loadSize = records.size();
			
			if(loadSize > 0){
				// 获取队列管理器连接
				mqConn = mqManager.getConnection();
				// 创建MQ Session
				session = mqConn.createSession(false, Session.AUTO_ACKNOWLEDGE);
				
				if(queueADCM != null){
					// 创建消息生产者
					producerADCM = session.createProducer(queueADCM);
					// 消息持久化
					producerADCM.setDeliveryMode(DeliveryMode.PERSISTENT);
					
					// 创建文本消息对象
					TextMessage textMessage = session.createTextMessage();
					for(EmpDeviceTO to : records){
						String empId = to.getEmpId();
						
						try{
							// 发送消息到指定队列
							sendToMQ(producerADCM, textMessage, to);
							
							if(LOG.isDebugEnabled()){
								LOG.debug("Send empdevice to MQ successfully! id--"+empId);
							}
						}catch(SGConverterException ce){
							//数据异常单独记录日志文件
							ErrorDataLog.error("Convert Object:empdevice to XML Exception, empId->[" + empId + "]");
							ce.printStackTrace();
						}catch(Exception e){
							LOG.error("Failed to send empdevice to MQ!", e);
							e.printStackTrace();
						}
					}
				}
			}
			
			return loadSize;
		}catch(Exception e){
			LOG.error("Exception Occured when sending empdevice", e);
			e.printStackTrace();
			throw e;
		}finally{
			mqManager.close(producerADCM);
			
			mqManager.close(session);
			mqManager.close(mqConn);
			
			dbManager.close(dbConn);
		}
		
	}
	
	/**
	 * 分批加载数据放入到集合
	 * Jun 28, 2012
	 * @param conn
	 * @param records
	 * @throws SQLException
	 */
	private void loadRecords(java.sql.Connection conn, List<EmpDeviceTO> records, int startRowNum, int endRowNum) throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try{
			pstmt = conn.prepareStatement(SQL_LOAD_RECORDS.toString());
			pstmt.setLong(1, endRowNum);
			pstmt.setLong(2, startRowNum);
			
			rs = pstmt.executeQuery();
			
			EmpDeviceTO to = null;
			while(rs.next()){
				to = new EmpDeviceTO();
				to.setEmpId(rs.getString("empId"));		// 员工工号
				to.setDeptId(rs.getString("deptId"));	// 所属网点
				to.setMobile(rs.getString("emptel"));	// 手机号码
				to.setImsi(rs.getString("imsi"));		// SIM卡串号
				to.setModifyDate(rs.getString("lastdate"));	// 最后使用时间
				records.add(to);
			}
		}finally{
			dbManager.close(rs);
			dbManager.close(pstmt);
		}
	}
	
	/**
	 * 发送消息到指定队列
	 * Jun 28, 2012
	 * @param messageProducer
	 * @param msg
	 * @param to
	 * @throws JMSException
	 */
	private void sendToMQ(MessageProducer producer, TextMessage msg, SGTransferObject to) throws JMSException{
		String xml = sgConverter.toXML(to);
		System.out.println(xml);
		msg.clearBody();
		msg.setText(xml);
		producer.send(msg);
	}
	
	/**
	 * 验证任务是否要执行
	 * Jun 29, 2012
	 * @return
	 */
	private boolean runTask(){
		Calendar curDate = Calendar.getInstance();
		
		int day = curDate.get(Calendar.DAY_OF_MONTH);
		int hour = curDate.get(Calendar.HOUR_OF_DAY);
		if(day == syncDay && hour >= syncHour){
			return true;
		}
		
		return false;
	}
	
	/*************** get/set 方法 **************/
	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}
	
	public void setMqManager(MQManager mqManager) {
		this.mqManager = mqManager;
	}

	public void setQueueADCM(Destination queueADCM) {
		this.queueADCM = queueADCM;
	}

	public void setSgConverter(ISGConverter sgConverter) {
		this.sgConverter = sgConverter;
	}
	
	public void setSyncDay(int syncDay) {
		this.syncDay = syncDay;
	}

	public void setSyncHour(int syncHour) {
		this.syncHour = syncHour;
	}

}
