package com.sf.hht.interfaces.task.emplogin;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;

import com.sf.framework.integration.ISGConverter;
import com.sf.framework.integration.SGConverterException;
import com.sf.framework.integration.dto.SGTransferObject;
import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.log.ErrorDataLog;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.resource.MQManager;


public class EmpLoginWorker extends TaskWorker {

	private static final Logger LOG = Logger.getLogger(EmpLoginWorker.class);

	// 更新发送状态sql
	private static final String SQL_UPDATE_SEND_STATUS = "update emplogin t set t.sendstatus=1 where t.empid=?";

	private static final String SQL_LOAD_RECORDS = "select e2.empid, e1.sn, e3.deptid "
			+ "from hht.empdevice e1, "
			+ "(select t.empid, max(nvl(t.modifydate, t.createdate)) lastdate "
			+ "from hht.empdevice t "
			+ "group by t.empid) e2, hht.emplogin e3 "
			+ "where e1.empid = e2.empid "
			+ "and nvl(e1.modifydate, e1.createdate) = e2.lastdate "
			+ "and e3.empid = e2.empid "
			+ "and e3.sendstatus = 0"
			+ "and  rownum <= ?";

	// 数据库连接管理
	private DBManager dbManager;
	// 队列管理器
	private MQManager mqManager;
	// EAM目标队列
	private Destination queueEam;
	// PAY目标队列
	private Destination queuePay;
	// 转换器
	private ISGConverter sgConverter;

	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}

	public void setMqManager(MQManager mqManager) {
		this.mqManager = mqManager;
	}
	
	public void setQueueEam(Destination queueEam) {
		this.queueEam = queueEam;
	}

	public void setQueuePay(Destination queuePay) {
		this.queuePay = queuePay;
	}

	public void setSgConverter(ISGConverter sgConverter) {
		this.sgConverter = sgConverter;
	}

	@Override
	public void preprocess() {

	}

	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("EmpLoginWorker[").append(Thread.currentThread().getId()).append("]");
		LOG.info(logPrefix.toString() + " start");
		
		while(running){
			try{
				int handleRows = handleRecords(logPrefix.toString());
				if(handleRows < task.getRecordSize()){
					makeWait(task.getPeriod());
				}
			}catch(Exception e){
				LOG.error("Exception Occured", e);
			}
		}
		
		LOG.info(logPrefix.toString() + " end");
	}
	
	/**
	 * 加载数据并且将数据发送到队列
	 * Oct 31, 2011
	 * @param logPrefix
	 * @return
	 */
	private int handleRecords(String logPrefix){
		// 查询结果记录集
		List<EmpLoginTO> records = new ArrayList<EmpLoginTO>();
		
		javax.jms.Connection mqConn = null;
		Session session = null;
		MessageProducer producerEam = null;
		MessageProducer producerPay = null;
		
		java.sql.Connection dbConn = null;
		
		try {
			// 获取数据库连接
			dbConn = dbManager.getConnection();
			dbConn.setAutoCommit(true);
			
			// 加载数据到集合
			loadRecords(dbConn, records);
			int loadSize = records.size();
			
			if(loadSize > 0){
				// 获取队列管理器连接
				mqConn = mqManager.getConnection();
				// 创建MQ Session
				session = mqConn.createSession(false, Session.AUTO_ACKNOWLEDGE);
				
				// 消息生产者集合
				List<MessageProducer> producerList = new ArrayList<MessageProducer>();
				if(queueEam != null){
					// 创建Eam队列生产者对象
					producerEam = session.createProducer(queueEam);
					// 消息持久化
					producerEam.setDeliveryMode(DeliveryMode.PERSISTENT);
					producerList.add(producerEam);
				}
				
				if(queuePay != null){
					// 创建Pay队列生产者对象
					producerPay = session.createProducer(queuePay);
					// 消息持久化
					producerPay.setDeliveryMode(DeliveryMode.PERSISTENT);
					producerList.add(producerPay);
				}
				
				// 创建文本消息对象
				TextMessage textMessage = session.createTextMessage();
				for(EmpLoginTO to : records){
					String empId = to.getEmpId();
					
					try{
						// 发送消息到指定队列
						sendToMQ(producerList, textMessage, to);
						
						// 更新记录发送状态，由0->1
						updateSendStatus(dbConn, empId);
					}catch(SGConverterException ce){
						//数据异常单独记录日志文件
						ErrorDataLog.error("Convert Object:EmpLogin to XML Exception, empId->[" + empId + "]");
						ce.printStackTrace();
					}catch(Exception e){
						LOG.error("Failed to send EmpLogin to MQ!", e);
						e.printStackTrace();
						continue;
					}
					
					if(LOG.isDebugEnabled()){
						LOG.debug("Send EmpLogin to MQ successfully! id--"+empId);
					}
				}
				
				LOG.info(logPrefix + "--Handled "+ loadSize + " record(s)");
			}
			
			return loadSize;
		}catch (Exception e) {
			LOG.error("Exception Occured when sending emplogin", e);
			e.printStackTrace();
		}finally{
			mqManager.close(producerEam);
			mqManager.close(producerPay);
			
			mqManager.close(session);
			mqManager.close(mqConn);
			
			dbManager.close(dbConn);
		}
		return -1;
	}

	/**
	 * 更新发送状态值（0->1） Oct 27, 2011
	 * 
	 * @param conn
	 * @param empId
	 * @throws SQLException
	 */
	private void updateSendStatus(java.sql.Connection conn, String empId)
			throws SQLException {
		
		PreparedStatement pstmt = null;
		
		try{
			pstmt = conn.prepareStatement(SQL_UPDATE_SEND_STATUS);
			pstmt.setString(1, empId);
			
			pstmt.executeUpdate();
		}finally{
			dbManager.close(pstmt);
		}
	}

	/**
	 * 分批加载数据放入到集合
	 * Oct 31, 2011
	 * @param conn
	 * @param records
	 * @throws SQLException
	 */
	private void loadRecords(java.sql.Connection conn, List<EmpLoginTO> records)
			throws SQLException {
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try{
			pstmt = conn.prepareStatement(SQL_LOAD_RECORDS);
			pstmt.setLong(1, task.getRecordSize());
			
			rs = pstmt.executeQuery();
			
			EmpLoginTO to = null;
			while(rs.next()){
				to = new EmpLoginTO();
				to.setEmpId(rs.getString("empid"));	// 员工工号
				to.setSn(rs.getString("sn"));	// sn 号
				to.setDeptId(rs.getString("deptid"));	// 所属分点部
				records.add(to);
			}
		}finally{
			dbManager.close(rs);
			dbManager.close(pstmt);		
		}
	}
	
	/**
	 * 发送消息到指定队列
	 * Apr 11, 2012
	 * @param producerList
	 * @param msg
	 * @param to
	 * @throws JMSException
	 */
	private void sendToMQ(List<MessageProducer> producerList, TextMessage msg, SGTransferObject to) throws JMSException{
		// 对象转换成xml
		String xml = sgConverter.toXML(to);
		msg.clearBody();
		msg.setText(xml);
		if(null != producerList && producerList.size() > 0){
			Iterator<MessageProducer> it = producerList.iterator();
			MessageProducer producer = null;
			while(it.hasNext()){
				producer = it.next();
				producer.send(msg);
			}
		}
		
	}
}
