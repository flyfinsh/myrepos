package com.sf.hht.interfaces.task.exchange;

import java.util.ArrayList;
import java.util.List;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;

import com.sf.framework.integration.ISGConverter;
import com.sf.framework.integration.SGConverterException;
import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.log.ErrorDataLog;
import com.sf.hht.interfaces.skeleton.resource.MQManager;
import com.sf.hht.interfaces.skeleton.resource.TransManager;
import com.sf.hht.interfaces.task.exchange.biz.ICurrencyBiz;
import com.sf.hht.interfaces.task.exchange.biz.IExchangeRateBiz;
import com.sf.integration.basedata.dto.BaseTO;
import com.sf.integration.basedata.dto.CurrencyPreTO;
import com.sf.integration.basedata.dto.CurrencyTO;
import com.sf.integration.basedata.dto.ExchangeRateTO;

public class ExchangeWorker extends TaskWorker {

	private static final Logger logger = Logger.getLogger(ExchangeWorker.class);

	private ICurrencyBiz currencyBiz;
	private IExchangeRateBiz exchangeRateBiz;
	private MQManager mqManager;
	private Destination queue;
	private ISGConverter sgConverter;
	private long receiveTimeout;
	private TransManager transManager;
	
	public void setCurrencyBiz(ICurrencyBiz currencyBiz) {
		this.currencyBiz = currencyBiz;
	}
	public void setExchangeRateBiz(IExchangeRateBiz exchangeRateBiz) {
		this.exchangeRateBiz = exchangeRateBiz;
	}
	public void setMqManager(MQManager mqManager) {
		this.mqManager = mqManager;
	}
	public void setQueue(Destination queue) {
		this.queue = queue;
	}
	public void setSgConverter(ISGConverter sgConverter) {
		this.sgConverter = sgConverter;
	}
	public void setReceiveTimeout(long receiveTimeout) {
		this.receiveTimeout = receiveTimeout;
	}
	public void setTransManager(TransManager transManager) {
		this.transManager = transManager;
	}

	@Override
	public void preprocess() {
		//do nothing
	}
	
	@Override
	protected void execute() {
		logger.info("ExchangeWorker start");

		while (running) {
			try {
				receive();
			
				makeWait(task.getPeriod());
			} catch (Exception e) {
				logger.error("Exception Occured", e);
			}
		}
		
		logger.info("ExchangeWorker end");
	}

	private void receive() {
		logger.info("ExchangeWorker: sync data start");
		
		List<CurrencyTO> currencyCurList = new ArrayList<CurrencyTO>();
		List<CurrencyPreTO> currencyPreList = new ArrayList<CurrencyPreTO>();
		List<ExchangeRateTO> exchangeRates = new ArrayList<ExchangeRateTO>();
		
		javax.jms.Connection mqConn = null;
		Session session = null;
		MessageConsumer consumer = null;
		
		try {
			UserTransaction ut = transManager.getUserTransaction();
			ut.begin();
			
			mqConn = mqManager.getConnection();
			mqConn.start();
			
			session = mqConn.createSession(true, Session.AUTO_ACKNOWLEDGE);
			consumer = session.createConsumer(queue);
			
			try {
				String message = receive(consumer);
				
				while (message != null) {
					if (logger.isDebugEnabled()) {
						logger.debug("Received Exchange:" + message);
					}
					
					BaseTO to = null;
					try {
						to = (BaseTO)sgConverter.fromXML(message, BaseTO.class);
					} catch (SGConverterException ce) {
						//数据异常单独记录日志文件
						ErrorDataLog.error("Exchange[" + message + "]");
						throw ce;
					}
					
					if (to instanceof CurrencyTO) {
						currencyCurList.add((CurrencyTO) to);
					} else if (to instanceof ExchangeRateTO) {
						exchangeRates.add((ExchangeRateTO) to);
					} else if(to instanceof CurrencyPreTO){
						currencyPreList.add((CurrencyPreTO)to);
					}
					
					message = receive(consumer);
				}
				
				// 保存币种生效数据
				currencyBiz.saveCurrency(currencyCurList);
				// 保存币种预生效数据
				currencyBiz.saveCurrencyPre(currencyPreList);
				// 保存汇率
				exchangeRateBiz.saveExchangeRate(exchangeRates);
				
				ut.commit();
			} catch (Exception e) {
				logger.error("Exception Occured when receiving Exchange Rate", e);
				
				ut.rollback();
			}
		} catch (Exception e) {
			logger.error("Exception Occured when receiving Exchange Rate", e);
		} finally {
			mqManager.close(consumer);
			mqManager.close(session);
			mqManager.close(mqConn);
		}
		
		logger.info("ExchangeWorker: sync data end");
	}
	
	private String receive(MessageConsumer consumer) throws JMSException {
		Message message = consumer.receive(receiveTimeout);
		
		if (message instanceof TextMessage) {
			return ((TextMessage) message).getText();
		} else {
			return null;
		}
	}

}