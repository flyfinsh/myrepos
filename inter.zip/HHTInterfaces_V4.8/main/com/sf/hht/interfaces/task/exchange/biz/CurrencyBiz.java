package com.sf.hht.interfaces.task.exchange.biz;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.sf.framework.integration.dto.OpTypeEnum;
import com.sf.hht.interfaces.task.exchange.dao.ICurrencyDao;
import com.sf.hht.interfaces.task.exchange.domain.Currency;
import com.sf.integration.basedata.dto.CurrencyPreTO;
import com.sf.integration.basedata.dto.CurrencyTO;

/**
 * <pre>
 * *********************************************
 * Copyright sf-express.
 * All rights reserved. 
 * Description: 币种接口业务实现
 * HISTORY
 * *********************************************
 *  ID   DATE           PERSON          REASON
 *  1    2009-7-6	    钟志君           创建 
 * *********************************************
 * </pre>
 */
public class CurrencyBiz implements ICurrencyBiz {
	
	private static final SimpleDateFormat SDF_YMS = new SimpleDateFormat("yyyyMMdd");

	private ICurrencyDao currencyDao;

	public void saveCurrency(List<CurrencyTO> currencys) {
		for (CurrencyTO currency : currencys) {
			save(currency);
		}
	}

	private void save(CurrencyTO currency) {
		boolean isValid = (currency.getValidFlg() != null) && currency.getValidFlg();
		if (OpTypeEnum.OP_TYPE_DELETE.equals(currency.getOpType()) || (!isValid)) {
			currencyDao.deleteById(String.valueOf(currency.getCurrencyId()));
		} else {
			currencyDao.save(toCurrency(currency));
		}
	}

	public void setCurrencyDao(ICurrencyDao currencyDao) {
		this.currencyDao = currencyDao;
	}

	private Currency toCurrency(CurrencyTO to) {
		Currency currency = new Currency();
		currency.setRange("CN");
		currency.setCreatedempcode(to.getCreatedEmpCode());
		currency.setCreatedtm(to.getCreatedTm());
		currency.setCurrencycode(to.getCurrencyCode());
		currency.setCurrencyId(String.valueOf(to.getCurrencyId()));
		currency.setCurrencyname(to.getCurrencyName());
		currency.setModifiedempcode(to.getModifiedEmpCode());
		currency.setModifiedtm(to.getModifiedTm());
		currency.setStandardcode(to.getStandardCode());
		currency.setPriceRoundType(to.getPriceRoundType());
		currency.setNumberParam(to.getNumberParam());
		currency.setPreDate(SDF_YMS.format(new Date()));
		return currency;
	}
	
	public void saveCurrencyPre(List<CurrencyPreTO> currencys) {
		for (CurrencyPreTO currency : currencys) {
			save(currency);
		}
	}

	private void save(CurrencyPreTO currency) {
		if (OpTypeEnum.OP_TYPE_DELETE.equals(currency.getOpType())) {
			currencyDao.deleteById(String.valueOf(currency.getCurrencyId()));
		} else {
			currencyDao.save(toCurrency(currency));
		}
	}

	private Currency toCurrency(CurrencyPreTO to) {
		Currency currency = new Currency();
		currency.setRange("CN");
		currency.setCreatedempcode(to.getCreatedEmpCode());
		currency.setCreatedtm(to.getCreatedTm());
		currency.setCurrencycode(to.getCurrencyCode());
		currency.setCurrencyId(String.valueOf(to.getCurrencyId()));
		currency.setCurrencyname(to.getCurrencyName());
		currency.setModifiedempcode(to.getModifiedEmpCode());
		currency.setModifiedtm(to.getModifiedTm());
		currency.setStandardcode(to.getStandardCode());
		currency.setPriceRoundType(to.getPriceRoundType());
		currency.setNumberParam(to.getNumberParam());
		
		if(to.getPreTm() != null){
			currency.setPreDate(SDF_YMS.format(to.getPreTm()));
		}
		return currency;
	}
}
