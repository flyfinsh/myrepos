package com.sf.hht.interfaces.task.exchange.biz;

import java.util.List;

import com.sf.framework.integration.dto.OpTypeEnum;
import com.sf.hht.interfaces.task.exchange.dao.IExchangeRateDao;
import com.sf.hht.interfaces.task.exchange.domain.ExchangeRate;
import com.sf.integration.basedata.dto.ExchangeRateTO;

/**
 * <pre>
 * *********************************************
 * Copyright sf-express.
 * All rights reserved. 
 * Description: 汇率接口业务实现
 * HISTORY
 * *********************************************
 *  ID   DATE           PERSON          REASON
 *  1    2009-7-6	    钟志君           创建 
 * *********************************************
 * </pre>
 */
public class ExchangeRateBiz implements IExchangeRateBiz {

	private IExchangeRateDao exchangeRateDao;

	public void setExchangeRateDao(IExchangeRateDao exchangeRateDao) {
		this.exchangeRateDao = exchangeRateDao;
	}

	public void saveExchangeRate(List<ExchangeRateTO> exchangeRates) {
		if (exchangeRates.size() > 0) {
			Double maxVersion = exchangeRateDao.getMaxVersion();
			// 保存从asura同步过来的汇率
			for (ExchangeRateTO exchangeRate : exchangeRates) {
				save(exchangeRate);
			}

			// 更改HHT的汇率版本
			exchangeRateDao.resetVersion(maxVersion);
			System.out.println("update exchange rate version: " + maxVersion);
		}
	}

	private void save(ExchangeRateTO exchangeRate) {
		if (OpTypeEnum.OP_TYPE_DELETE.equals(exchangeRate.getOpType())) {
			exchangeRateDao.deleteById(String.valueOf(exchangeRate.getExchRateId()));
		} else {
			exchangeRateDao.save(toExchangeRate(exchangeRate));
		}
	}

	private ExchangeRate toExchangeRate(ExchangeRateTO to) {
		ExchangeRate rate = new ExchangeRate();
		rate.setId(String.valueOf(to.getExchRateId()));
		rate.setBasic(to.getSourceCurrencyCode());
		rate.setTarget(to.getDestCurrencyCode());
		rate.setCount(to.getRate());
		rate.setInsure(to.getValidTm());
		rate.setAbate(to.getInvalidTm());
		rate.setVercount(to.getVersionQty());
		rate.setC2version(to.getVersionNo());
		rate.setCreatedbyid(to.getCreatedEmpCode());
		rate.setCreatedtime(to.getCreatedTm());
		rate.setModifiedbyid(to.getModifiedEmpCode());
		rate.setModifiedtime(to.getModifiedTm());
		return rate;
	}
}
