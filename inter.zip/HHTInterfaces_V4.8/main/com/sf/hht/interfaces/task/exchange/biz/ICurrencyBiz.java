package com.sf.hht.interfaces.task.exchange.biz;

import java.util.List;

import com.sf.integration.basedata.dto.CurrencyPreTO;
import com.sf.integration.basedata.dto.CurrencyTO;

public interface ICurrencyBiz {

	public void saveCurrency(List<CurrencyTO> currencys);

	public void saveCurrencyPre(List<CurrencyPreTO> currencys);
}
