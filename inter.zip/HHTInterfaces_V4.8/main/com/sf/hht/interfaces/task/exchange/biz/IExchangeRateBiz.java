package com.sf.hht.interfaces.task.exchange.biz;

import java.util.List;

import com.sf.integration.basedata.dto.ExchangeRateTO;

public interface IExchangeRateBiz {

	public void saveExchangeRate(List<ExchangeRateTO> exchangeRates);

}
