package com.sf.hht.interfaces.task.exchange.dao;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.sf.hht.interfaces.task.exchange.domain.Currency;

public class CurrencyDao extends HibernateDaoSupport implements ICurrencyDao {

	public void save(Currency currency) {
		Currency oldCurrency = (Currency) this.getHibernateTemplate().get(Currency.class, currency.getCurrencyId());
		if (oldCurrency != null) {
			// 如果已经存在的记录的修改时间比当前记录的修改时间早，则删除旧数据
			if (oldCurrency.getModifiedtm().before(currency.getModifiedtm())) {
				this.getHibernateTemplate().merge(currency);
				getHibernateTemplate().flush();
			} else {
				System.out.println("ignored Currency(" + currency.getStandardcode() + ")");
			}
		} else {
			this.getHibernateTemplate().save(currency);
			getHibernateTemplate().flush();
		}
	}

	public void deleteById(String currencyId) {
		String sql = "delete from com.sf.hht.interfaces.task.exchange.domain.Currency where currencyId = ?";
		getHibernateTemplate().bulkUpdate(sql, currencyId);
		getHibernateTemplate().flush();
	}
}
