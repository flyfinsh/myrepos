package com.sf.hht.interfaces.task.exchange.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.sf.hht.interfaces.task.exchange.domain.ExchangeRate;

public class ExchangeRateDao extends HibernateDaoSupport implements IExchangeRateDao {

	public void save(ExchangeRate exchangeRate) {
		ExchangeRate oldRate = (ExchangeRate) this.getHibernateTemplate().get(ExchangeRate.class, exchangeRate.getId());
		if (oldRate != null) {
			if (oldRate.getC2version() <= exchangeRate.getC2version()) {
				this.getHibernateTemplate().merge(exchangeRate);
				getHibernateTemplate().flush();
			} else {
				System.out.println("ignored ExchangeRate(" + exchangeRate.getBasic() + " -> "
						+ exchangeRate.getTarget() + ")");
			}
		} else {
			//同组汇率取最大序列+1 
			Long maxserial= getMaxSerial(exchangeRate.getBasic(),exchangeRate.getTarget());
			exchangeRate.setSerial(maxserial+1);
			this.getHibernateTemplate().save(exchangeRate);
			getHibernateTemplate().flush();
		}
	}

	public void deleteById(String exchangeRateId) {
		String sql = "delete from com.sf.hht.interfaces.task.exchange.domain.ExchangeRate where id = ?";
		getHibernateTemplate().bulkUpdate(sql, exchangeRateId);
		getHibernateTemplate().flush();
	}

	/**
	 * 设置HHT使用的版本号ver
	 */
	public void resetVersion(Double maxVersion) {
		// update version = null
		String sql = "update com.sf.hht.interfaces.task.exchange.domain.ExchangeRate set ver = null where insure > sysdate";
		getHibernateTemplate().bulkUpdate(sql);
		// update version = max version
		sql = "update com.sf.hht.interfaces.task.exchange.domain.ExchangeRate set ver = " + maxVersion + " where insure <= sysdate";
		getHibernateTemplate().bulkUpdate(sql);
		getHibernateTemplate().flush();
	}

	public Double getMaxVersion() {
		String sql = "select nvl(max(ver) + 0.1, 1.0) from com.sf.hht.interfaces.task.exchange.domain.ExchangeRate";
		List<?> result = getHibernateTemplate().find(sql);
		return (Double) result.get(0);
	}
	
	//获取同组汇率最大序列值
	public Long getMaxSerial(String baisc ,String target) {
		StringBuffer sql =new StringBuffer();
        sql.append("select nvl(max(serial), 0) from com.sf.hht.interfaces.task.exchange.domain.ExchangeRate where basic=")
		.append("'")
		.append(baisc)
		.append("'")
		.append(" and target=")
		.append("'")
		.append(target)
		.append("'");
		List<?> result = getHibernateTemplate().find(sql.toString());
         
		return  (Long) result.get(0);
		
	}
	
}
