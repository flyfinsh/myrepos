package com.sf.hht.interfaces.task.exchange.dao;

import com.sf.hht.interfaces.task.exchange.domain.Currency;

public interface ICurrencyDao {

	public void save(Currency currency);

	public void deleteById(String currencyId);
}
