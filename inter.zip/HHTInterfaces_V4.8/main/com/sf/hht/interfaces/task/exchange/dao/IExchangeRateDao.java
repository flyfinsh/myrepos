package com.sf.hht.interfaces.task.exchange.dao;

import com.sf.hht.interfaces.task.exchange.domain.ExchangeRate;

public interface IExchangeRateDao {

	public void save(ExchangeRate exchangeRate);

	public void deleteById(String exchangeRateId);

	// 设置HHT使用的版本号ver
	public void resetVersion(Double maxVersion);

	// 取得系统的最大版本号
	public Double getMaxVersion();

}
