package com.sf.hht.interfaces.task.exchange.domain;

import java.util.Date;

public class Currency {

	// ID
	private String currencyId;
	// 货币名称
	private String currencyname;
	// 货币编号
	private String currencycode;
	// 货币代码使用范围
	private String range;
	// 标准代码
	private String standardcode;
	// 创建人
	private String createdempcode;
	// 创建时间
	private Date createdtm;
	// 修改人
	private String modifiedempcode;
	// 修改时间
	private Date modifiedtm;
	// 到付运费舍入方式；有三个值：1代表四舍五入。2代表向上进位。3代表向下舍掉。这里要注意的是只针对到付
	private Long priceRoundType;
	// 小数点舍入位数：0代码精确到整数，1代表精确到小数点后一位，2代表到小数点后两位，-1代表到小数点前一位（即十位），-2代表到百位，依此类推。
	private Long numberParam;
	// 预设生效日期
	private String preDate;

	public String getCurrencyId() {
		return currencyId;
	}

	public void setCurrencyId(String currencyId) {
		this.currencyId = currencyId;
	}

	public String getCurrencyname() {
		return currencyname;
	}

	public void setCurrencyname(String currencyname) {
		this.currencyname = currencyname;
	}

	public String getCurrencycode() {
		return currencycode;
	}

	public void setCurrencycode(String currencycode) {
		this.currencycode = currencycode;
	}

	public String getRange() {
		return range;
	}

	public void setRange(String range) {
		this.range = range;
	}

	public String getStandardcode() {
		return standardcode;
	}

	public void setStandardcode(String standardcode) {
		this.standardcode = standardcode;
	}

	public String getCreatedempcode() {
		return createdempcode;
	}

	public void setCreatedempcode(String createdempcode) {
		this.createdempcode = createdempcode;
	}

	public Date getCreatedtm() {
		return createdtm;
	}

	public void setCreatedtm(Date createdtm) {
		this.createdtm = createdtm;
	}

	public String getModifiedempcode() {
		return modifiedempcode;
	}

	public void setModifiedempcode(String modifiedempcode) {
		this.modifiedempcode = modifiedempcode;
	}

	public Date getModifiedtm() {
		return modifiedtm;
	}

	public void setModifiedtm(Date modifiedtm) {
		this.modifiedtm = modifiedtm;
	}

	public Long getPriceRoundType() {
		return priceRoundType;
	}

	public void setPriceRoundType(Long priceRoundType) {
		this.priceRoundType = priceRoundType;
	}

	public Long getNumberParam() {
		return numberParam;
	}

	public void setNumberParam(Long numberParam) {
		this.numberParam = numberParam;
	}

	public String getPreDate() {
		return preDate;
	}

	public void setPreDate(String preDate) {
		this.preDate = preDate;
	}
	
}
