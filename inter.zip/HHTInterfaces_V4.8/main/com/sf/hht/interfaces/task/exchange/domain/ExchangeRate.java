package com.sf.hht.interfaces.task.exchange.domain;

import java.util.Date;

public class ExchangeRate {

	// 汇率ID
	private String id;
	// 基础货币
	private String basic;
	// 目标货币
	private String target;
	// 汇率
	private Double count;
	// 生效时间
	private Date insure;
	// 失效时间
	private Date abate;
	// 流水号
	private Long serial;
	// 汇率版本
	private Double ver;
	// 版本数
	private Long vercount;
	// 是否删除
	private Byte isdelete;
	// 插入时间
	private Date insertime;
	// 从Exp5获取的版本号
	private Long c2version;
	// 创建人
	private String createdbyid;
	// 创建时间
	private Date createdtime;
	// 修改人
	private String modifiedbyid;
	// 修改时间
	private Date modifiedtime;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBasic() {
		return basic;
	}

	public void setBasic(String basic) {
		this.basic = basic;
	}

	public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}

	public Double getCount() {
		return count;
	}

	public void setCount(Double count) {
		this.count = count;
	}

	public Date getInsure() {
		return insure;
	}

	public void setInsure(Date insure) {
		this.insure = insure;
	}

	public Date getAbate() {
		return abate;
	}

	public void setAbate(Date abate) {
		this.abate = abate;
	}

	public Long getSerial() {
		return serial;
	}

	public void setSerial(Long serial) {
		this.serial = serial;
	}

	public Double getVer() {
		return ver;
	}

	public void setVer(Double ver) {
		this.ver = ver;
	}

	public Long getVercount() {
		return vercount;
	}

	public void setVercount(Long vercount) {
		this.vercount = vercount;
	}

	public Byte getIsdelete() {
		return isdelete;
	}

	public void setIsdelete(Byte isdelete) {
		this.isdelete = isdelete;
	}

	public Date getInsertime() {
		return insertime;
	}

	public void setInsertime(Date insertime) {
		this.insertime = insertime;
	}

	public Long getC2version() {
		return c2version;
	}

	public void setC2version(Long c2version) {
		this.c2version = c2version;
	}

	public String getCreatedbyid() {
		return createdbyid;
	}

	public void setCreatedbyid(String createdbyid) {
		this.createdbyid = createdbyid;
	}

	public Date getCreatedtime() {
		return createdtime;
	}

	public void setCreatedtime(Date createdtime) {
		this.createdtime = createdtime;
	}

	public String getModifiedbyid() {
		return modifiedbyid;
	}

	public void setModifiedbyid(String modifiedbyid) {
		this.modifiedbyid = modifiedbyid;
	}

	public Date getModifiedtime() {
		return modifiedtime;
	}

	public void setModifiedtime(Date modifiedtime) {
		this.modifiedtime = modifiedtime;
	}
}
