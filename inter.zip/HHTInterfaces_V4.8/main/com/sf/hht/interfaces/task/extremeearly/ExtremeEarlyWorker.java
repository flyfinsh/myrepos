package com.sf.hht.interfaces.task.extremeearly;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;

import com.sf.framework.integration.ISGConverter;
import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.resource.MQManager;
import com.sf.integration.basedata.dto.ExtremeEarlyTO;

public class ExtremeEarlyWorker extends TaskWorker {

	private static final Logger LOG = Logger.getLogger(ExtremeEarlyWorker.class);
	private static final SimpleDateFormat SDF_YMDHMS = new SimpleDateFormat("yyyyMMddHHmmss");

	private static final StringBuffer SQL_INSER_EXTREME_EARLY = new StringBuffer();
	private static final StringBuffer SQL_UPDATE_EXTREME_EARLY = new StringBuffer();
	private static final StringBuffer SQL_CHECK_EXIST_EXTREME_EARLY = new StringBuffer();
	
	static{
		// INSERT
		SQL_INSER_EXTREME_EARLY.append(" insert into PD_SUPER_EARLY_EXPRESS");
		SQL_INSER_EXTREME_EARLY.append("(ID,");
		SQL_INSER_EXTREME_EARLY.append("   SRC_AREA_CODE,");
		SQL_INSER_EXTREME_EARLY.append("   SRC_DIST_CODE,");
		SQL_INSER_EXTREME_EARLY.append("   SRC_DEPT_CODE,");
		SQL_INSER_EXTREME_EARLY.append("   PICKUP_BATCH_CODE,");
		SQL_INSER_EXTREME_EARLY.append("   ORDER_BEGIN_TIME,");
		SQL_INSER_EXTREME_EARLY.append("   ORDER_END_TIME,");
		SQL_INSER_EXTREME_EARLY.append("   PICKUP_BEGIN_TIME,");
		SQL_INSER_EXTREME_EARLY.append("   PICKUP_END_TIME,");
		SQL_INSER_EXTREME_EARLY.append("   STOCK_LAST_TIME,");
		SQL_INSER_EXTREME_EARLY.append("   COLLECT_BATCH_CODE,");
		SQL_INSER_EXTREME_EARLY.append("   DEST_DIST_CODE,");
		SQL_INSER_EXTREME_EARLY.append("   DISTRIBUTE_BATCH_CODE,");
		SQL_INSER_EXTREME_EARLY.append("   WORK_DAY,");
		SQL_INSER_EXTREME_EARLY.append("   VALID_DT,");
		SQL_INSER_EXTREME_EARLY.append("   VALID_FLG,");
		SQL_INSER_EXTREME_EARLY.append("   INVALID_DT,");
		SQL_INSER_EXTREME_EARLY.append("   CREATE_TM,");
		SQL_INSER_EXTREME_EARLY.append("   MODIFY_TM)");
		SQL_INSER_EXTREME_EARLY.append(" values");
		SQL_INSER_EXTREME_EARLY.append("(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, SYSDATE, SYSDATE)");
		
		// UPDATE
		SQL_UPDATE_EXTREME_EARLY.append(" update PD_SUPER_EARLY_EXPRESS");
		SQL_UPDATE_EXTREME_EARLY.append("   set SRC_AREA_CODE         = ?,");
		SQL_UPDATE_EXTREME_EARLY.append("       SRC_DIST_CODE         = ?,");
		SQL_UPDATE_EXTREME_EARLY.append("       SRC_DEPT_CODE         = ?,");
		SQL_UPDATE_EXTREME_EARLY.append("       PICKUP_BATCH_CODE     = ?,");
		SQL_UPDATE_EXTREME_EARLY.append("       ORDER_BEGIN_TIME      = ?,");
		SQL_UPDATE_EXTREME_EARLY.append("       ORDER_END_TIME        = ?,");
		SQL_UPDATE_EXTREME_EARLY.append("       PICKUP_BEGIN_TIME     = ?,");
		SQL_UPDATE_EXTREME_EARLY.append("       PICKUP_END_TIME       = ?,");
		SQL_UPDATE_EXTREME_EARLY.append("       STOCK_LAST_TIME       = ?,");
		SQL_UPDATE_EXTREME_EARLY.append("       COLLECT_BATCH_CODE    = ?,");
		SQL_UPDATE_EXTREME_EARLY.append("       DEST_DIST_CODE        = ?,");
		SQL_UPDATE_EXTREME_EARLY.append("       DISTRIBUTE_BATCH_CODE = ?,");
		SQL_UPDATE_EXTREME_EARLY.append("       WORK_DAY              = ?,");
		SQL_UPDATE_EXTREME_EARLY.append("       VALID_DT              = ?,");
		SQL_UPDATE_EXTREME_EARLY.append("       VALID_FLG             = ?,");
		SQL_UPDATE_EXTREME_EARLY.append("       INVALID_DT            = ?,");
		SQL_UPDATE_EXTREME_EARLY.append("       MODIFY_TM         = SYSDATE");
		SQL_UPDATE_EXTREME_EARLY.append("  where ID = ?");
		
		// DELETE
		SQL_CHECK_EXIST_EXTREME_EARLY.append("select count(1) from PD_SUPER_EARLY_EXPRESS where ID = ?");
	}

	private DBManager dbManager;
	// 队列管理器
	private MQManager mqManager;
	// 目标队列
	private Destination queue;
	// 转换器
	private ISGConverter sgConverter;
	// 接收超时上限
	private long receiveTimeout;

	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("ExtremeEarlyWorker[").append(Thread.currentThread().getId()).append("]");
		
		LOG.info(logPrefix.toString() + " start");
		
		while (running) {
			try {
				receive(logPrefix.toString());
				
				makeWait(task.getPeriod());
			} catch (Exception e) {
				LOG.error("ExtremeEarlyWorker Exception Occured", e);
			}
		}
		
		LOG.info(logPrefix + " end");
	}

	@Override
	public void preprocess() {
	}
	
	/**
	 * 从MQ读取数据并且处理这些数据
	 * 
	 * Feb 22, 2013
	 * @param logPrefix
	 * @return
	 */
	private void receive(String logPrefix){
		LOG.info("ExtremeEarlyWorker: sync data start");
		
		// MQ连接
		javax.jms.Connection mqConn = null;
		// 会话
		Session session = null;
		// 消息消费者
		MessageConsumer consumer = null;
		// 数据库连接
		Connection conn = null;
		
		try {
			mqConn = mqManager.getConnection();
			mqConn.start();
			
			session = mqConn.createSession(true, Session.AUTO_ACKNOWLEDGE);
			consumer = session.createConsumer(queue);
			
			// 接收消息
			String message = receive(consumer);
			
			while (message != null) {
				try {
					conn = dbManager.getConnection();
					
					ExtremeEarlyTO extremeEarlyTO = (ExtremeEarlyTO) sgConverter.fromXML(message, ExtremeEarlyTO.class);
					
					boolean isExist = checkExtremeEarlyExist(extremeEarlyTO.getId(), conn);
					
					// 如果存在，则更新；否则新增
					if (isExist) {
						updateExtremeEarly(extremeEarlyTO, conn);
					}else {
						insertExtremeEarly(extremeEarlyTO, conn);
					}
					
					LOG.info("Receive extreme early data successfully --> " + extremeEarlyTO.getId());
				} catch (Exception e) {
					e.printStackTrace();
					LOG.error("Exception Occured receiving extreme early data : " + message);
				}finally{
					dbManager.close(conn);
				}
				
				// 接收消息
				message = receive(consumer);
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error("Exception Occured before connect extreme early queue");
		}finally{
			mqManager.close(consumer);
			mqManager.close(session);
			mqManager.close(mqConn);
		}
	}
	
	/**
	 * 从MQ读取消息
	 * 
	 * Feb 22, 2013
	 * @param consumer
	 * @return
	 * @throws JMSException
	 */
	private String receive(MessageConsumer consumer) throws JMSException{
		Message message = consumer.receive(receiveTimeout);
		
		if(message instanceof TextMessage) {
			return ((TextMessage)message).getText();
		}else{
			return null;
		}
	}
	
	/**
	 * 插入特早件配置数据
	 * 
	 * Feb 22, 2013
	 * @param extremeEarlyTO
	 * @param conn
	 * @throws SQLException
	 */
	private void insertExtremeEarly(ExtremeEarlyTO extremeEarlyTO, Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		
		try{
			pstmt = conn.prepareStatement(SQL_INSER_EXTREME_EARLY.toString());
			
			pstmt.setLong(1, extremeEarlyTO.getId());
			pstmt.setString(2, extremeEarlyTO.getSrcAreaCode());
			pstmt.setString(3, extremeEarlyTO.getSrcDistCode());
			pstmt.setString(4, extremeEarlyTO.getSrcDeptCode());
			pstmt.setString(5, extremeEarlyTO.getPickupBatchCode());
			pstmt.setString(6, extremeEarlyTO.getOrderBeginTime());
			pstmt.setString(7, extremeEarlyTO.getOrderEndTime());
			pstmt.setString(8, extremeEarlyTO.getPickupBeginTime());
			pstmt.setString(9, extremeEarlyTO.getPickupEndTime());
			pstmt.setString(10, extremeEarlyTO.getStockLastTime());
			pstmt.setString(11, extremeEarlyTO.getCollectBatchCode());
			pstmt.setString(12, extremeEarlyTO.getDestDistCode());
			pstmt.setString(13, extremeEarlyTO.getDistributeBatchCode());
			pstmt.setString(14, extremeEarlyTO.getWorkDay());
			
			// 生效日期
			if (extremeEarlyTO.getValidDt() != null) {
				pstmt.setString(15, SDF_YMDHMS.format(extremeEarlyTO.getValidDt()));
			}else {
				pstmt.setString(15, null);
			}
			
			pstmt.setString(16, extremeEarlyTO.getValidFlg());
			
			if (extremeEarlyTO.getInvalidDt() != null) {
				pstmt.setString(17, SDF_YMDHMS.format(extremeEarlyTO.getInvalidDt()));
			}else {
				pstmt.setString(17, null);
			}
			
			pstmt.executeUpdate();
		}finally{
			dbManager.close(pstmt);
		}
	}
	
	/**
	 * 更新特早件配置数据
	 * 
	 * Feb 22, 2013
	 * @param extremeEarlyTO
	 * @param conn
	 * @throws SQLException 
	 */
	private void updateExtremeEarly(ExtremeEarlyTO extremeEarlyTO, Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(SQL_UPDATE_EXTREME_EARLY.toString());
			
			pstmt.setString(1, extremeEarlyTO.getSrcAreaCode());
			pstmt.setString(2, extremeEarlyTO.getSrcDistCode());
			pstmt.setString(3, extremeEarlyTO.getSrcDeptCode());
			pstmt.setString(4, extremeEarlyTO.getPickupBatchCode());
			pstmt.setString(5, extremeEarlyTO.getOrderBeginTime());
			pstmt.setString(6, extremeEarlyTO.getOrderEndTime());
			pstmt.setString(7, extremeEarlyTO.getPickupBeginTime());
			pstmt.setString(8, extremeEarlyTO.getPickupEndTime());
			pstmt.setString(9, extremeEarlyTO.getStockLastTime());
			pstmt.setString(10, extremeEarlyTO.getCollectBatchCode());
			pstmt.setString(11, extremeEarlyTO.getDestDistCode());
			pstmt.setString(12, extremeEarlyTO.getDistributeBatchCode());
			pstmt.setString(13, extremeEarlyTO.getWorkDay());
			
			// 生效日期
			if (extremeEarlyTO.getValidDt() != null) {
				pstmt.setString(14, SDF_YMDHMS.format(extremeEarlyTO.getValidDt()));
			}else {
				pstmt.setString(14, null);
			}
			
			pstmt.setString(15, extremeEarlyTO.getValidFlg());
			
			if (extremeEarlyTO.getInvalidDt() != null) {
				pstmt.setString(16, SDF_YMDHMS.format(extremeEarlyTO.getInvalidDt()));
			}else {
				pstmt.setString(16, null);
			}
			
			pstmt.setLong(17, extremeEarlyTO.getId());
			
			pstmt.executeUpdate();
		} finally {
			dbManager.close(pstmt);
		}
	}
	
	/**
	 * 查询特早件配置是否存在
	 * 
	 * Feb 22, 2013
	 * @param id
	 * @param conn
	 * @return
	 * @throws SQLException 
	 */
	private boolean checkExtremeEarlyExist(Long id, Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(SQL_CHECK_EXIST_EXTREME_EARLY.toString());
			
			pstmt.setLong(1, id);
			rs = pstmt.executeQuery();
			
			long count = 0;
			if (rs.next()) {
				count = rs.getLong(1);
			}
			
			if (count > 0) {
				return true;
			}
		} finally {
			
		}
		
		return false;
	}

	/** ************** get/set *************** */
	public DBManager getDbManager() {
		return dbManager;
	}

	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}

	public MQManager getMqManager() {
		return mqManager;
	}

	public void setMqManager(MQManager mqManager) {
		this.mqManager = mqManager;
	}

	public Destination getQueue() {
		return queue;
	}

	public void setQueue(Destination queue) {
		this.queue = queue;
	}

	public ISGConverter getSgConverter() {
		return sgConverter;
	}

	public void setSgConverter(ISGConverter sgConverter) {
		this.sgConverter = sgConverter;
	}

	public void setReceiveTimeout(long receiveTimeout) {
		this.receiveTimeout = receiveTimeout;
	}
}
