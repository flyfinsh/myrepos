package com.sf.hht.interfaces.task.facetimeout;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.xml.rpc.ServiceException;

import org.apache.log4j.Logger;

import com.sf.hht.interfaces.skeleton.core.Task;
import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.util.CommonHelper;
import com.sf.hht.interfaces.task.facetimeout.dto.OvertimeFreePackDto;
import com.sf.hht.interfaces.task.facetimeout.security.EncryptDecryptUtil;
import com.sf.hht.interfaces.task.facetimeout.ws.FaceTimeOut4HHTDto;
import com.sf.hht.interfaces.task.facetimeout.ws.IFaceTimeOutQueryService;
import com.sf.hht.interfaces.task.facetimeout.ws.IFaceTimeOutQueryServiceServiceLocator;

public class FaceTimeoutWorker extends TaskWorker {
	
	private static final Logger LOG = Logger.getLogger(FaceTimeoutWorker.class);
	
	// 加载需要处理的数据
	private static final String SQL_LOAD_RECORDS = "select id, new_bno, overtime_bno from overtime_free_pack where send_thread = ? and server_id = ? and send_status = 1 and rownum < ?";
	// 记录与线程绑定
	private static final String SQL_BEFORE_LOAD = "update overtime_free_pack set server_id = ?, send_thread = ?, send_status = 1, send_tm = sysdate where send_status = 0 and rownum < ?";
	// 返回结果更新到对应记录
	private static final String SQL_AFTER_UPDATE = "update overtime_free_pack set send_status = 2, reply_result = ? where id = ?";
	// 数据接管
	private static final String SQL_RESET_STATUS = "update overtime_free_pack set send_status = 0 where send_status = 1 and send_tm < (sysdate - 10 / (24 * 60))";
	
	// 下次执行接口表状态复位时间
	private long nextResetTime = 0;
	
	// 数据库连接管理
	private DBManager dbManager;
	
	// 散单逾限查询(asura webservice url)
	private String wsUrl;

	// 加密工具类
	private EncryptDecryptUtil encryptDecryptUtil;
	
	public void setEncryptDecryptUtil(EncryptDecryptUtil encryptDecryptUtil) {
		this.encryptDecryptUtil = encryptDecryptUtil;
	}

	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}

	public void setWsUrl(String wsUrl) {
		this.wsUrl = wsUrl;
	}

	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("FaceTimeoutWorker[").append(Thread.currentThread().getId()).append("]");
		
		LOG.info(logPrefix.toString() + " start");
		
		while(running){
			try{
				int handleRows = handleRecords(logPrefix.toString());
				
				if (System.currentTimeMillis() > nextResetTime) {
					// 更新处理失败数据状态
					int count = resetStatus();
					
					LOG.info("FaceTimeoutWorker reset record status count->"+count);
					
					// 设置下次执行复位操作的时间为：10分钟之后
					nextResetTime = System.currentTimeMillis() + (10 * 60 * 1000);
				}
				
				if(handleRows < task.getRecordSize()){
					makeWait(task.getPeriod());
				}
			}catch(Exception e){
				LOG.error("Exception Occured", e);
			}
		}
		
		LOG.error(logPrefix + " end");
	}

	@Override
	public void preprocess() {
//		clearDirtyRecords();
	}
	
	/**
	 * 处理散单逾限数据
	 * Nov 22, 2011
	 * @param logPrefix
	 * @return
	 */
	private int handleRecords(String logPrefix){
		List<OvertimeFreePackDto> records = new ArrayList<OvertimeFreePackDto>();
		
		Connection conn = null;
		try{
			// 更新发送状态
			beforeLoadRecords();
			
			conn = dbManager.getConnection();
			conn.setAutoCommit(false);
			
			// 加载需要验证的逾限运单
			loadRecords(conn, records);
			
			int loadSize = records.size();
			
			if(loadSize > 0){
				for(OvertimeFreePackDto to : records){
					Long id = to.getId();
					// 向ASURA发送验证
					FaceTimeOut4HHTDto faceTimeOut4HHTDto = null;
					try {
						if(null == to.getOvertimeBno()){
							to.setOvertimeBno("");
						}
						if(null == to.getNewBno()){
							to.setNewBno("");
						}
						faceTimeOut4HHTDto = queryWayBillNoHasUsed(to);
						if (LOG.isDebugEnabled()) {
							LOG.debug("Call asura query facetimeout webservice successful! id--" + id);
						}
					}catch(Exception e){
						LOG.error("Exception Occured when call asura query webservice in facetimeout", e);
						e.printStackTrace();
					}
//					} catch (IllegalBlockSizeException e) {
//						LOG.error("Exception Occured when encrypt bno in facetimeout", e);
//						e.printStackTrace();
//					} 
//					catch (BadPaddingException e) {
//						LOG.error("Exception Occured when encrypt bno in facetimeout", e);
//						e.printStackTrace();
//					} catch (RemoteException e) {
//						LOG.error("Exception Occured when call query bno webservice in facetimeout", e);
//						e.printStackTrace();
//					}
					
					if(null != faceTimeOut4HHTDto){
						// 运单状态（0:有效、1:已补寄、2:已过期、3:重复、4:不退费、5:逾限单号不存在、6:新单号重复、7:参数错误）
						String status = String.valueOf(faceTimeOut4HHTDto.getStatus());
						// 更新数据发送状态和运单状态
						updateStatus(conn, to.getId(), status);
					}
				}
				
				LOG.info(logPrefix + "--Handled " + loadSize + " record(s)");
			}
			
			conn.commit();
			conn.setAutoCommit(true);
			
			return loadSize;
		}catch(Exception e){
			LOG.error("Exception Occured when sending facetimeout", e);

			try {
				if (conn != null) {
					conn.rollback();
				}
			} catch (SQLException e1) {
				LOG.error(e1);
			}
		}finally{
			// 关闭数据库连接
			dbManager.close(conn);
		}
		return -1;
	}
	
	/**
	 * 加载需要处理的数据
	 * Nov 23, 2011
	 * @param conn
	 * @param records
	 * @throws SQLException 
	 */
	private void loadRecords(Connection conn, List<OvertimeFreePackDto> records) throws SQLException{
		PreparedStatement pstmt = conn.prepareStatement(SQL_LOAD_RECORDS);
		pstmt.setLong(1, Thread.currentThread().getId());
		pstmt.setString(2, CommonHelper.getServerId());
		pstmt.setLong(3, task.getRecordSize());
		
		ResultSet rs = pstmt.executeQuery();
		
		OvertimeFreePackDto to;
		while(rs.next()){
			to = new OvertimeFreePackDto();
			to.setId(rs.getLong("id"));
			to.setNewBno(rs.getString("new_bno"));
			to.setOvertimeBno(rs.getString("overtime_bno"));
			records.add(to);
		}
		
		dbManager.close(rs);
		dbManager.close(pstmt);
	}
	
	/**
	 * 更新数据发送状态和运单状态
	 * Nov 23, 2011
	 * @param conn
	 * @param id
	 * @param replyResult
	 * @throws SQLException
	 */
	private void updateStatus(Connection conn, Long id, String replyResult) throws SQLException {
		PreparedStatement pstmt = conn.prepareStatement(SQL_AFTER_UPDATE);
		pstmt.setString(1, replyResult);
		pstmt.setLong(2, id);
		pstmt.executeUpdate();
		
		dbManager.close(pstmt);
	}
	
	/**
	 * 根据逾限单号及补寄单号查询运单信息
	 * Nov 23, 2011
	 * @param newWaybillNo
	 * @param oldWaybillNo
	 * @return
	 * @throws BadPaddingException 
	 * @throws IllegalBlockSizeException 
	 * @throws BadPaddingException 
	 * @throws ServiceException 
	 * @throws MalformedURLException 
	 * @throws RemoteException 
	 */
	private FaceTimeOut4HHTDto queryWayBillNoHasUsed(OvertimeFreePackDto to) throws IllegalBlockSizeException, BadPaddingException, MalformedURLException, ServiceException, RemoteException{
		byte[] bNewWaybillNo = encryptDecryptUtil.encrypt(to.getNewBno());
		byte[] bOldWaybillNo = encryptDecryptUtil.encrypt(to.getOvertimeBno());
		IFaceTimeOutQueryServiceServiceLocator locator = new IFaceTimeOutQueryServiceServiceLocator();
		IFaceTimeOutQueryService service = locator.getIFaceTimeOutQueryServicePort(new URL(wsUrl));
		FaceTimeOut4HHTDto dto = service.queryWayBillNoHasUsed(bOldWaybillNo, bNewWaybillNo);
		return dto;
	}
	
	/**
	 * 预处理数据，将数据与线程绑定
	 * Nov 22, 2011
	 * @param conn
	 * @return
	 * @throws SQLException
	 */
	private int beforeLoadRecords() throws SQLException{
		Connection conn = null;
		PreparedStatement pstmt = null;
		int affectRecordCount = 0;
		
		try {
			conn = dbManager.getConnection();
			
			pstmt = conn.prepareStatement(SQL_BEFORE_LOAD);
			pstmt.setString(1, CommonHelper.getServerId());
			pstmt.setLong(2, Thread.currentThread().getId());
			pstmt.setLong(3, task.getRecordSize());
			
			affectRecordCount = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}finally{
			dbManager.close(conn);
			dbManager.close(pstmt);
		}
		
		return affectRecordCount;
	}
	
	/**
	 * 重置发送失败数据状态
	 * Aug 12, 2013
	 * @return
	 */
	private int resetStatus(){
		int count = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = dbManager.getConnection();
			
			pstmt = conn.prepareStatement(SQL_RESET_STATUS);
			count = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			dbManager.close(pstmt);
			dbManager.close(conn);
		}
		
		return count;
	}
	
	public static void main(String[] args) throws IllegalBlockSizeException, BadPaddingException, MalformedURLException, RemoteException, ServiceException {
		FaceTimeoutWorker worker = new FaceTimeoutWorker();
		worker.setWsUrl("http://10.0.4.91:8080/cms/ws/FaceTimeOutQueryService");
		OvertimeFreePackDto dto = new OvertimeFreePackDto();
		dto.setNewBno("");
		dto.setOvertimeBno("123456789123");
		FaceTimeOut4HHTDto rs = worker.queryWayBillNoHasUsed(dto);
		System.out.println("webservice status ："+rs.getStatus());
		
	}
}
