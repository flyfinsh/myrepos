package com.sf.hht.interfaces.task.facetimeout.dto;

import java.util.Date;

public class OvertimeFreePackDto {
	private Long id;
	private String empId;
	private String deptId;
	private String newBno;
	private String overtimeBno;
	private Date barTime;
	private Date insertTime;
	private Long sendStatus;
	private Long sendThread;
	private Date sendTm;
	private String replyResult;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getDeptId() {
		return deptId;
	}
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}
	public String getNewBno() {
		return newBno;
	}
	public void setNewBno(String newBno) {
		this.newBno = newBno;
	}
	public String getOvertimeBno() {
		return overtimeBno;
	}
	public void setOvertimeBno(String overtimeBno) {
		this.overtimeBno = overtimeBno;
	}
	public Date getBarTime() {
		return barTime;
	}
	public void setBarTime(Date barTime) {
		this.barTime = barTime;
	}
	public Date getInsertTime() {
		return insertTime;
	}
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}
	public Long getSendStatus() {
		return sendStatus;
	}
	public void setSendStatus(Long sendStatus) {
		this.sendStatus = sendStatus;
	}
	public Long getSendThread() {
		return sendThread;
	}
	public void setSendThread(Long sendThread) {
		this.sendThread = sendThread;
	}
	public Date getSendTm() {
		return sendTm;
	}
	public void setSendTm(Date sendTm) {
		this.sendTm = sendTm;
	}
	public String getReplyResult() {
		return replyResult;
	}
	public void setReplyResult(String replyResult) {
		this.replyResult = replyResult;
	}
}
