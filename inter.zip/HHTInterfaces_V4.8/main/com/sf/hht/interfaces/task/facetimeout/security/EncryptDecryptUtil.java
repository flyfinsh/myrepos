package com.sf.hht.interfaces.task.facetimeout.security;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.security.Key;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;

public class EncryptDecryptUtil {

	private static Cipher encrypt = null;
	private static Cipher decrypt = null;

	private static String keyFilePath;
	
	public void setKeyFilePath(String keyFilePath){
		this.keyFilePath = keyFilePath;
	}
	
	public void init() {
		try {
			ObjectInputStream keyIn = new ObjectInputStream(
					new FileInputStream(keyFilePath));
			Key key = (Key) keyIn.readObject();
			keyIn.close();

			encrypt = Cipher.getInstance("AES");
			encrypt.init(Cipher.ENCRYPT_MODE, key);

			decrypt = Cipher.getInstance("AES");
			decrypt.init(Cipher.DECRYPT_MODE, key);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static byte[] encrypt(String waybillNo)
			throws IllegalBlockSizeException, BadPaddingException {
		return encrypt.doFinal(waybillNo.getBytes());
	}

	public static String decrypt(byte[] bs) throws IllegalBlockSizeException,
			BadPaddingException {
		byte[] codes = decrypt.doFinal(bs);
		return new String(codes);
	}

	public static void main(String[] args) throws IllegalBlockSizeException,
			BadPaddingException {
		String waybillNo = "755123456789";
		String t = decrypt(encrypt(waybillNo));
		System.out.println(waybillNo.equals(t));
	}
}
