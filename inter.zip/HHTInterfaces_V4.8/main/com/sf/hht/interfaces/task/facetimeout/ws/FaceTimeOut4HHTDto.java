/**
 * FaceTimeOut4HHTDto.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.task.facetimeout.ws;

public class FaceTimeOut4HHTDto  implements java.io.Serializable {
    private double feeAmt;
    private java.lang.String norefundType;
    private java.util.Calendar refundEndDt;
    private java.lang.Long status;
    private java.lang.String usedWayBillNo;

    public FaceTimeOut4HHTDto() {
    }

    public double getFeeAmt() {
        return feeAmt;
    }

    public void setFeeAmt(double feeAmt) {
        this.feeAmt = feeAmt;
    }

    public java.lang.String getNorefundType() {
        return norefundType;
    }

    public void setNorefundType(java.lang.String norefundType) {
        this.norefundType = norefundType;
    }

    public java.util.Calendar getRefundEndDt() {
        return refundEndDt;
    }

    public void setRefundEndDt(java.util.Calendar refundEndDt) {
        this.refundEndDt = refundEndDt;
    }

    public java.lang.Long getStatus() {
        return status;
    }

    public void setStatus(java.lang.Long status) {
        this.status = status;
    }

    public java.lang.String getUsedWayBillNo() {
        return usedWayBillNo;
    }

    public void setUsedWayBillNo(java.lang.String usedWayBillNo) {
        this.usedWayBillNo = usedWayBillNo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof FaceTimeOut4HHTDto)) return false;
        FaceTimeOut4HHTDto other = (FaceTimeOut4HHTDto) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            feeAmt == other.getFeeAmt() &&
            ((norefundType==null && other.getNorefundType()==null) || 
             (norefundType!=null &&
              norefundType.equals(other.getNorefundType()))) &&
            ((refundEndDt==null && other.getRefundEndDt()==null) || 
             (refundEndDt!=null &&
              refundEndDt.equals(other.getRefundEndDt()))) &&
            ((status==null && other.getStatus()==null) || 
             (status!=null &&
              status.equals(other.getStatus()))) &&
            ((usedWayBillNo==null && other.getUsedWayBillNo()==null) || 
             (usedWayBillNo!=null &&
              usedWayBillNo.equals(other.getUsedWayBillNo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Double(getFeeAmt()).hashCode();
        if (getNorefundType() != null) {
            _hashCode += getNorefundType().hashCode();
        }
        if (getRefundEndDt() != null) {
            _hashCode += getRefundEndDt().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getUsedWayBillNo() != null) {
            _hashCode += getUsedWayBillNo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(FaceTimeOut4HHTDto.class);

    static {
        org.apache.axis.description.FieldDesc field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("feeAmt");
        field.setXmlName(new javax.xml.namespace.QName("", "feeAmt"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("norefundType");
        field.setXmlName(new javax.xml.namespace.QName("", "norefundType"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("refundEndDt");
        field.setXmlName(new javax.xml.namespace.QName("", "refundEndDt"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("status");
        field.setXmlName(new javax.xml.namespace.QName("", "status"));
        field.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "long"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("usedWayBillNo");
        field.setXmlName(new javax.xml.namespace.QName("", "usedWayBillNo"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
    };

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
