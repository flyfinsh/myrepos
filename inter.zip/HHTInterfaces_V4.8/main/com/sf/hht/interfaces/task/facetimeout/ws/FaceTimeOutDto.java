/**
 * FaceTimeOutDto.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.task.facetimeout.ws;

public class FaceTimeOutDto  implements java.io.Serializable {
    private java.lang.String bilType;
    private double feeAmt;
    private java.lang.Long isRefund;
    private java.lang.String noRefundType;
    private java.util.Calendar refundEndDt;
    private java.lang.Long status;
    private java.lang.String usedWayBillNo;
    private java.lang.String wayBillNo;

    public FaceTimeOutDto() {
    }

    public java.lang.String getBilType() {
        return bilType;
    }

    public void setBilType(java.lang.String bilType) {
        this.bilType = bilType;
    }

    public double getFeeAmt() {
        return feeAmt;
    }

    public void setFeeAmt(double feeAmt) {
        this.feeAmt = feeAmt;
    }

    public java.lang.Long getIsRefund() {
        return isRefund;
    }

    public void setIsRefund(java.lang.Long isRefund) {
        this.isRefund = isRefund;
    }

    public java.lang.String getNoRefundType() {
        return noRefundType;
    }

    public void setNoRefundType(java.lang.String noRefundType) {
        this.noRefundType = noRefundType;
    }

    public java.util.Calendar getRefundEndDt() {
        return refundEndDt;
    }

    public void setRefundEndDt(java.util.Calendar refundEndDt) {
        this.refundEndDt = refundEndDt;
    }

    public java.lang.Long getStatus() {
        return status;
    }

    public void setStatus(java.lang.Long status) {
        this.status = status;
    }

    public java.lang.String getUsedWayBillNo() {
        return usedWayBillNo;
    }

    public void setUsedWayBillNo(java.lang.String usedWayBillNo) {
        this.usedWayBillNo = usedWayBillNo;
    }

    public java.lang.String getWayBillNo() {
        return wayBillNo;
    }

    public void setWayBillNo(java.lang.String wayBillNo) {
        this.wayBillNo = wayBillNo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof FaceTimeOutDto)) return false;
        FaceTimeOutDto other = (FaceTimeOutDto) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((bilType==null && other.getBilType()==null) || 
             (bilType!=null &&
              bilType.equals(other.getBilType()))) &&
            feeAmt == other.getFeeAmt() &&
            ((isRefund==null && other.getIsRefund()==null) || 
             (isRefund!=null &&
              isRefund.equals(other.getIsRefund()))) &&
            ((noRefundType==null && other.getNoRefundType()==null) || 
             (noRefundType!=null &&
              noRefundType.equals(other.getNoRefundType()))) &&
            ((refundEndDt==null && other.getRefundEndDt()==null) || 
             (refundEndDt!=null &&
              refundEndDt.equals(other.getRefundEndDt()))) &&
            ((status==null && other.getStatus()==null) || 
             (status!=null &&
              status.equals(other.getStatus()))) &&
            ((usedWayBillNo==null && other.getUsedWayBillNo()==null) || 
             (usedWayBillNo!=null &&
              usedWayBillNo.equals(other.getUsedWayBillNo()))) &&
            ((wayBillNo==null && other.getWayBillNo()==null) || 
             (wayBillNo!=null &&
              wayBillNo.equals(other.getWayBillNo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBilType() != null) {
            _hashCode += getBilType().hashCode();
        }
        _hashCode += new Double(getFeeAmt()).hashCode();
        if (getIsRefund() != null) {
            _hashCode += getIsRefund().hashCode();
        }
        if (getNoRefundType() != null) {
            _hashCode += getNoRefundType().hashCode();
        }
        if (getRefundEndDt() != null) {
            _hashCode += getRefundEndDt().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getUsedWayBillNo() != null) {
            _hashCode += getUsedWayBillNo().hashCode();
        }
        if (getWayBillNo() != null) {
            _hashCode += getWayBillNo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(FaceTimeOutDto.class);

    static {
        org.apache.axis.description.FieldDesc field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("bilType");
        field.setXmlName(new javax.xml.namespace.QName("", "bilType"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("feeAmt");
        field.setXmlName(new javax.xml.namespace.QName("", "feeAmt"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("isRefund");
        field.setXmlName(new javax.xml.namespace.QName("", "isRefund"));
        field.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "long"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("noRefundType");
        field.setXmlName(new javax.xml.namespace.QName("", "noRefundType"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("refundEndDt");
        field.setXmlName(new javax.xml.namespace.QName("", "refundEndDt"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("status");
        field.setXmlName(new javax.xml.namespace.QName("", "status"));
        field.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "long"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("usedWayBillNo");
        field.setXmlName(new javax.xml.namespace.QName("", "usedWayBillNo"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("wayBillNo");
        field.setXmlName(new javax.xml.namespace.QName("", "wayBillNo"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
    };

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
