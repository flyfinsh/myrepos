/**
 * IFaceTimeOutQueryService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.task.facetimeout.ws;

public interface IFaceTimeOutQueryService extends java.rmi.Remote {
    public com.sf.hht.interfaces.task.facetimeout.ws.FaceTimeOut4HHTDto queryWayBillNoHasUsed(byte[] arg0, byte[] arg1) throws java.rmi.RemoteException;
    public com.sf.hht.interfaces.task.facetimeout.ws.FaceTimeOutDto queryFaceTimeOutInfo(java.lang.String arg0) throws java.rmi.RemoteException;
}
