package com.sf.hht.interfaces.task.facetimeout.ws;

public class IFaceTimeOutQueryServiceProxy implements com.sf.hht.interfaces.task.facetimeout.ws.IFaceTimeOutQueryService {
  private String _endpoint = null;
  private com.sf.hht.interfaces.task.facetimeout.ws.IFaceTimeOutQueryService iFaceTimeOutQueryService = null;
  
  public IFaceTimeOutQueryServiceProxy() {
    _initIFaceTimeOutQueryServiceProxy();
  }
  
  public IFaceTimeOutQueryServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initIFaceTimeOutQueryServiceProxy();
  }
  
  private void _initIFaceTimeOutQueryServiceProxy() {
    try {
      iFaceTimeOutQueryService = (new com.sf.hht.interfaces.task.facetimeout.ws.IFaceTimeOutQueryServiceServiceLocator()).getIFaceTimeOutQueryServicePort();
      if (iFaceTimeOutQueryService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)iFaceTimeOutQueryService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)iFaceTimeOutQueryService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (iFaceTimeOutQueryService != null)
      ((javax.xml.rpc.Stub)iFaceTimeOutQueryService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.sf.hht.interfaces.task.facetimeout.ws.IFaceTimeOutQueryService getIFaceTimeOutQueryService() {
    if (iFaceTimeOutQueryService == null)
      _initIFaceTimeOutQueryServiceProxy();
    return iFaceTimeOutQueryService;
  }
  
  public com.sf.hht.interfaces.task.facetimeout.ws.FaceTimeOut4HHTDto queryWayBillNoHasUsed(byte[] arg0, byte[] arg1) throws java.rmi.RemoteException{
    if (iFaceTimeOutQueryService == null)
      _initIFaceTimeOutQueryServiceProxy();
    return iFaceTimeOutQueryService.queryWayBillNoHasUsed(arg0, arg1);
  }
  
  public com.sf.hht.interfaces.task.facetimeout.ws.FaceTimeOutDto queryFaceTimeOutInfo(java.lang.String arg0) throws java.rmi.RemoteException{
    if (iFaceTimeOutQueryService == null)
      _initIFaceTimeOutQueryServiceProxy();
    return iFaceTimeOutQueryService.queryFaceTimeOutInfo(arg0);
  }
  
  
}