package com.sf.hht.interfaces.task.fuelrates;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.transaction.UserTransaction;

import org.apache.log4j.Logger;

import com.sf.framework.integration.ISGConverter;
import com.sf.framework.integration.SGConverterException;
import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.log.ErrorDataLog;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.resource.MQManager;
import com.sf.hht.interfaces.skeleton.resource.TransManager;
import com.sf.integration.basedata.dto.BaseTO;
import com.sf.integration.basedata.dto.FuelRatesCnTO;
import com.sf.integration.basedata.dto.FuelRatesTO;

public class FuelRateWorker extends TaskWorker {
	
	private static final Logger LOG = Logger.getLogger(FuelRateWorker.class);
	
	private static final SimpleDateFormat SDF_YMDHMS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	// 插入港澳台燃油附加费SQL
	private String SQL_INSERT_FUEL_RATES = "insert into pd_fuel_rates(id, source_code, dest_code, cargo_type_code, fuel_rate, fuel_cost, validate_tm, invalidate_tm, modified_tm, start_weight, hht_crate_tm, hht_modified_tm) values(?,?,?,?,?,?,?,?,?,?,sysdate,sysdate)";
	// 更新港澳台燃油附加费SQL
	private String SQL_UPDATE_FUEL_RATES = "update pd_fuel_rates set source_code = ?, dest_code = ?, cargo_type_code = ?, fuel_rate = ?, fuel_cost = ?, validate_tm = ?, invalidate_tm = ?, modified_tm = ?, start_weight = ?, hht_modified_tm = sysdate where id = ?";
	// 按ID查询港澳台燃油附加费SQL
	private String SQL_QUERY_FUEL_RATES_BY_ID = "select count(1) from pd_fuel_rates where id = ?";
	
	// 插入大陆燃油附加费SQL
	private String SQL_INSERT_FUEL_RATES_CN = "insert into pd_tm_fuel_rates_cn(id, distance_type_code, fuel_rate, fuel_cost, validate_tm, invalidate_tm, modified_tm, begin_date, hht_create_tm, hht_modified_tm) values(?,?,?,?,?,?,?,sysdate,sysdate,sysdate)";
	// 更新大陆燃油附加费SQL
	private String SQL_UPDATE_FUEL_RATES_CN = "update pd_tm_fuel_rates_cn set distance_type_code = ?, fuel_rate = ?, fuel_cost = ?, validate_tm = ?, invalidate_tm = ?, modified_tm = ?, begin_date = sysdate, hht_modified_tm = sysdate where id = ?";
	// 按ID查询大陆燃油附加费SQL
	private String SQL_QUERY_FUEL_RATES_CN_BY_ID = "select count(1) from pd_tm_fuel_rates_cn where id = ?";
	
	private DBManager dbManager;
	// 队列管理器
	private MQManager mqManager;
	// 目标队列
	private Destination queue;
	// 转换器
	private ISGConverter sgConverter;
	// 接收超时上限
	private long receiveTimeout;
	
	private TransManager transManager;
	
	@Override
	public void preprocess() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("FuleRatesWorker[").append(Thread.currentThread().getId()).append("]");
		
		LOG.info(logPrefix.toString() + " start");
		
		while(running){
			try{
				int num = receive(logPrefix.toString());
				
				if(num < task.getRecordSize()){
					makeWait(task.getPeriod());
				}
			}catch(Exception e){
				LOG.error("Exception Occured", e);
			}
		}
		
	}
	
	/**
	 * 从MQ读取数据并且处理这些数据
	 * Jul 17, 2012
	 * @param logPrefix
	 */
	private int receive(String logPrefix){
		LOG.info("FuelRatesWorker: sync data start");
		
		// MQ连接
		javax.jms.Connection mqConn = null;
		// 会话
		Session session = null;
		// 消息消费者
		MessageConsumer consumer = null;
		// 用户事务
		UserTransaction ut = null;
		// 数据库连接
		Connection dbConn = null;
		
		int num = 1;
		
		try{
			ut = transManager.getUserTransaction();
			ut.begin();
			
			dbConn = dbManager.getConnection();
			
			mqConn = mqManager.getConnection();
			mqConn.start();
			
			session = mqConn.createSession(true, Session.AUTO_ACKNOWLEDGE);
			consumer = session.createConsumer(queue);
			
			String message = null;
			
			try{
				// 接收消息
				message = receive(consumer);
				
				while(message != null){
					
					BaseTO to = (BaseTO) sgConverter.fromXML(message, BaseTO.class);
					
					if ("FuelRatesCnTO".equals(to.getObjName())) {
						Long id = ((FuelRatesCnTO)to).getId();
						// 按ID检索记录是否存在，如果存在则更新，否则做新增
						if(checkFuelRatesCNExists(id, dbConn)){
							updateFuelRates((FuelRatesCnTO)to, dbConn);
						}else{
							insertFuelRates((FuelRatesCnTO)to, dbConn);
						}
					}else {
						Long id = ((FuelRatesTO)to).getId();
						// 按ID检索记录是否存在，如果存在则更新，否则做新增
						if(checkFuelRatesExists(id, dbConn)){
							updateFuelRates((FuelRatesTO)to, dbConn);
						}else{
							insertFuelRates((FuelRatesTO)to, dbConn);
						}
					}
					
					// 每读取100条消息做一次事务提交，然后重新开启一次事务
					if(num == task.getRecordSize()){
						break;
					}
					
					num ++;
					// 接收消息
					message = receive(consumer);
				}
					
				ut.commit();
				
				LOG.info(logPrefix + "--Handled "+ num + " record(s)");
				
			}catch(Exception e){
				e.printStackTrace();
				ut.rollback();
				LOG.error("Exception Occured receiving fuel rate : " + message);
			}finally{
				dbManager.close(dbConn);
			}
			
		}catch(Exception e){
			e.printStackTrace();
			LOG.error("Exception Occured before connect fuel rate queue");
		}finally{
			mqManager.close(consumer);
			mqManager.close(session);
			mqManager.close(mqConn);
		}
		
		return num;
	}

	/**
	 * 从MQ读取消息
	 * Jul 16, 2012
	 * @param consumer
	 * @return
	 * @throws JMSException
	 */
	private String receive(MessageConsumer consumer) throws JMSException{
		Message message = consumer.receive(receiveTimeout);
		
		if(message instanceof TextMessage) {
			return ((TextMessage)message).getText();
		}else{
			return null;
		}
	}
	
	/****************** 港澳台燃油附加费业务方法 ***********************/
	
	/**
	 * 插入港澳台燃油附加费数据
	 * Jul 16, 2012
	 * @param fuelRatesTO
	 */
	private void insertFuelRates(FuelRatesTO fuelRatesTO, Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		
		try{
			pstmt = conn.prepareStatement(SQL_INSERT_FUEL_RATES);
			
			pstmt.setLong(1, fuelRatesTO.getId());					// ID
			pstmt.setString(2, fuelRatesTO.getSourceCode());		// 源寄地
			pstmt.setString(3, fuelRatesTO.getDestCode());			// 目的地
			pstmt.setString(4, fuelRatesTO.getCargoTypeCode());		// 货物类型
			pstmt.setDouble(5, fuelRatesTO.getFuelRate());			// 费率
			pstmt.setDouble(6, fuelRatesTO.getFuelCost());			// 固定金额
			
			// 生效日期
			if(fuelRatesTO.getValidateTm() != null){
				pstmt.setString(7, SDF_YMDHMS.format(fuelRatesTO.getValidateTm()));
			}else{
				pstmt.setString(7, null);
			}
			// 失效日期
			if(fuelRatesTO.getInvalidateTm() != null){
				pstmt.setString(8, SDF_YMDHMS.format(fuelRatesTO.getInvalidateTm()));
			}else{
				pstmt.setString(8, null);
			}
			// 最后一次修改时间(ASURA使用)
			if(fuelRatesTO.getModifiedTm() != null){
				pstmt.setString(9, SDF_YMDHMS.format(fuelRatesTO.getModifiedTm()));
			}else{
				pstmt.setString(9, null);
			}
			
			pstmt.setDouble(10, fuelRatesTO.getStartWeight());			// 开始收费的重量
			
			pstmt.executeUpdate();
		}finally{
			dbManager.close(pstmt);
		}
	}
	
	/**
	 * 更新港澳台燃油附加费数据
	 * Jul 16, 2012
	 * @param fuelRatesTO
	 */
	private void updateFuelRates(FuelRatesTO fuelRatesTO, Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		
		try{
			pstmt = conn.prepareStatement(SQL_UPDATE_FUEL_RATES);
			
			pstmt.setString(1, fuelRatesTO.getSourceCode());		// 源寄地
			pstmt.setString(2, fuelRatesTO.getDestCode());			// 目的地
			pstmt.setString(3, fuelRatesTO.getCargoTypeCode());		// 货物类型
			pstmt.setDouble(4, fuelRatesTO.getFuelRate());			// 费率
			pstmt.setDouble(5, fuelRatesTO.getFuelCost());			// 固定金额
			
			// 生效日期
			if(fuelRatesTO.getValidateTm() != null){
				pstmt.setString(6, SDF_YMDHMS.format(fuelRatesTO.getValidateTm()));
			}else{
				pstmt.setString(6, null);
			}
			// 失效日期
			if(fuelRatesTO.getInvalidateTm() != null){
				pstmt.setString(7, SDF_YMDHMS.format(fuelRatesTO.getInvalidateTm()));
			}else{
				pstmt.setString(7, null);
			}
			// 最后一次修改时间(ASURA使用)
			if(fuelRatesTO.getModifiedTm() != null){
				pstmt.setString(8, SDF_YMDHMS.format(fuelRatesTO.getModifiedTm()));
			}else{
				pstmt.setString(8, null);
			}
			
			pstmt.setDouble(9, fuelRatesTO.getStartWeight());			// 开始收费的重量
			pstmt.setLong(10, fuelRatesTO.getId());						// ID
			
			pstmt.executeUpdate();
			
		}finally{
			dbManager.close(pstmt);
		}
	}

	/**
	 * 查询港澳台燃油附加费数据是否存在
	 * Jul 16, 2012
	 * @param id
	 * @return
	 */
	private boolean checkFuelRatesExists(Long id, Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try{
			pstmt = conn.prepareStatement(SQL_QUERY_FUEL_RATES_BY_ID);
			
			pstmt.setLong(1, id);
			rs = pstmt.executeQuery();
			
			long count = 0;
			if(rs.next()){
				count = rs.getLong(1);
			}
			
			if(count > 0){
				return true;
			}
		}finally{
			dbManager.close(rs);
			dbManager.close(pstmt);
		}
		
		return false;
	}
	
	
	/****************** 大陆燃油附加费业务方法 ***********************/
	/**
	 * 插入大陆燃油附加费数据
	 * Jul 16, 2012
	 * @param fuelRatesCnTO
	 */
	private void insertFuelRates(FuelRatesCnTO fuelRatesCnTO, Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		
		try{
			pstmt = conn.prepareStatement(SQL_INSERT_FUEL_RATES_CN);
			
			pstmt.setLong(1, fuelRatesCnTO.getId());					// ID
			pstmt.setString(2, fuelRatesCnTO.getDistanceTypeCode());	// 地域类型
			pstmt.setDouble(3, fuelRatesCnTO.getFuelRate());			// 费率
			pstmt.setDouble(4, fuelRatesCnTO.getFuelCost());			// 固定金额
			
			// 生效日期
			if(fuelRatesCnTO.getValidateTm() != null){
				pstmt.setString(5, SDF_YMDHMS.format(fuelRatesCnTO.getValidateTm()));
			}else{
				pstmt.setString(5, null);
			}
			// 失效日期
			if(fuelRatesCnTO.getInvalidateTm() != null){
				pstmt.setString(6, SDF_YMDHMS.format(fuelRatesCnTO.getInvalidateTm()));
			}else{
				pstmt.setString(6, null);
			}
			// 最后一次修改时间(ASURA使用)
			if(fuelRatesCnTO.getModifiedTm() != null){
				pstmt.setString(7, SDF_YMDHMS.format(fuelRatesCnTO.getModifiedTm()));
			}else{
				pstmt.setString(7, null);
			}
			
			pstmt.executeUpdate();
		}finally{
			dbManager.close(pstmt);
		}
	}
	
	
	/**
	 * 更新大陆燃油附加费数据
	 * Jul 16, 2012
	 * @param fuelRatesCnTO
	 */
	private void updateFuelRates(FuelRatesCnTO fuelRatesCnTO, Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		
		try{
			pstmt = conn.prepareStatement(SQL_UPDATE_FUEL_RATES_CN);
			
			pstmt.setString(1, fuelRatesCnTO.getDistanceTypeCode());	// 地域类型
			pstmt.setDouble(2, fuelRatesCnTO.getFuelRate());			// 费率
			pstmt.setDouble(3, fuelRatesCnTO.getFuelCost());			// 固定金额
			
			// 生效日期
			if(fuelRatesCnTO.getValidateTm() != null){
				pstmt.setString(4, SDF_YMDHMS.format(fuelRatesCnTO.getValidateTm()));
			}else{
				pstmt.setString(4, null);
			}
			// 失效日期
			if(fuelRatesCnTO.getInvalidateTm() != null){
				pstmt.setString(5, SDF_YMDHMS.format(fuelRatesCnTO.getInvalidateTm()));
			}else{
				pstmt.setString(5, null);
			}
			// 最后一次修改时间(ASURA使用)
			if(fuelRatesCnTO.getModifiedTm() != null){
				pstmt.setString(6, SDF_YMDHMS.format(fuelRatesCnTO.getModifiedTm()));
			}else{
				pstmt.setString(6, null);
			}
			
			pstmt.setLong(7, fuelRatesCnTO.getId());						// ID
			
			pstmt.executeUpdate();
			
		}finally{
			dbManager.close(pstmt);
		}
	}
	
	
	/**
	 * 查询大陆燃油附加费数据是否存在
	 * Jul 16, 2012
	 * @param id
	 * @return
	 */
	private boolean checkFuelRatesCNExists(Long id, Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try{
			pstmt = conn.prepareStatement(SQL_QUERY_FUEL_RATES_CN_BY_ID);
			
			pstmt.setLong(1, id);
			rs = pstmt.executeQuery();
			
			long count = 0;
			if(rs.next()){
				count = rs.getLong(1);
			}
			
			if(count > 0){
				return true;
			}
		}finally{
			dbManager.close(rs);
			dbManager.close(pstmt);
		}
		
		return false;
	}
	
	
	/**************** get/set方法 *****************/
	public void setMqManager(MQManager mqManager) {
		this.mqManager = mqManager;
	}

	public void setQueue(Destination queue) {
		this.queue = queue;
	}

	public void setSgConverter(ISGConverter sgConverter) {
		this.sgConverter = sgConverter;
	}

	public void setReceiveTimeout(long receiveTimeout) {
		this.receiveTimeout = receiveTimeout;
	}

	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}

	public void setTransManager(TransManager transManager) {
		this.transManager = transManager;
	}
	
}
