package com.sf.hht.interfaces.task.hhtbar;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;

import com.sf.framework.integration.ISGConverter;
import com.sf.framework.integration.SGConverterException;
import com.sf.framework.integration.dto.SGTransferObject;
import com.sf.hht.interfaces.skeleton.cache.WantedReasonCache;
import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.log.ErrorDataLog;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.resource.MQManager;
import com.sf.hht.interfaces.skeleton.util.CommonHelper;
import com.sf.hht.interfaces.skeleton.util.DateUtil;
import com.sf.integration.bar.dto.BarRecordTempTO;

public class HHTBarWorker extends TaskWorker {

    private static final Logger logger = Logger.getLogger(HHTBarWorker.class);

    private static final String sql_load_record = "select xh,opcode,bno,zno,baropr,opr,bartime,pkg,inputty,pcs,weight,phonezone,phone,jmstr,sn,signurl,why,prodtype,box,attach,warning,mno,CONSIGNOR_PHONE,SF_CVS_CODE,C_TYPE_CUSTOMER,MONEY,CODPAY,COUPON_NO,PKG0,PROXY_SIGNER,COURIER_MOBILE_NUM,SMS_PAY,DIST_CODE,RECV_SMS,OPATTACH,SAFEST_EXPRESS_SMS,wantedty,wantedcode,tran_code,tran_name,ewaybill_correct, locker_code,over_long_weight_fee,medicine_box_code,dmcode,volume,barcode,assist_empno,contact_point_code,booktime,sendtype_code,wl_code,cmd,codpayreason from tbilltrace where send_thread = ? and server_id = ? and send_status = 1 and rownum <= ?";
    private static final String sql_after_insert = "insert into tbilltrace_bak select * from tbilltrace where xh = ?";
    private static final String sql_after_delete = "delete from tbilltrace where xh = ?";
    private static final String sql_get_deptid = "select deptid from EMPLOYEE where empid = ?";
    private static final String sql_update_zno = "update tbilltrace set zno=? where xh = ?";

    private DBManager dbManager;
    private MQManager mqManager;
    private Destination queue;
    private ISGConverter sgConverter;

    public void setDbManager(DBManager dbManager) {
        this.dbManager = dbManager;
    }

    public void setMqManager(MQManager mqManager) {
        this.mqManager = mqManager;
    }

    public void setQueue(Destination queue) {
        this.queue = queue;
    }

    public void setSgConverter(ISGConverter sgConverter) {
        this.sgConverter = sgConverter;
    }

    @Override
    public void preprocess() {
        // do nothing
    }

    @Override
    protected void execute() {
        StringBuffer logPrefix = new StringBuffer();
        logPrefix.append("HHTBarWorker[")
                .append(Thread.currentThread().getId()).append("]");

        logger.info(logPrefix.toString() + " start");

        while (running) {
            try {
                int handleRows = handleRecords(logPrefix.toString());

                if (handleRows < task.getRecordSize()) {
                    makeWait(task.getPeriod());
                }
            } catch (Exception e) {
                logger.error("Exception Occured", e);
            }
        }

        logger.info(logPrefix + " end");
    }

    private int handleRecords(String logPrefix) {
        List<BarRecordTempTO> records = new ArrayList<BarRecordTempTO>();

        javax.jms.Connection mqConn = null;
        Session session = null;
        MessageProducer producer = null;

        java.sql.Connection dbConn = null;

        try {
            dbConn = dbManager.getConnection();

            dbConn.setAutoCommit(false);

            loadRecords(dbConn, records);

            int loadSize = records.size();

            if (loadSize > 0) {

                mqConn = mqManager.getConnection();
                session = mqConn.createSession(false, Session.AUTO_ACKNOWLEDGE);
                producer = session.createProducer(queue);
                producer.setDeliveryMode(DeliveryMode.PERSISTENT);
                TextMessage textMessage = session.createTextMessage();

                for (BarRecordTempTO to : records) {
                    // 获得事务ID号，并将TO对象中的事务ID号清空
                    String xh = to.getOpName();
                    to.setObjName("");

                    // 如果网点代码为空，则回补网点代码，不管数据回补是否成功，都要进行MQ发送，及后续的操作
                    if ((to.getZoneCode() == null)
                            || (to.getZoneCode().trim().length() == 0)) {
                        addZoneCode(dbConn, to, xh);
                    }

                    // 如果bno、opcode、bartime、baropr不为空，则发送到MQ
                    if (verifyData(to)) {
                        try {
                            sendToMQ(producer, textMessage, to);
                        } catch (SGConverterException ce) {
                            // 数据异常单独记录日志文件,然后转至BAK表
                            ErrorDataLog.error("HHTBar[" + xh + "]");
                        } catch (Exception e) {
                            // 其它异常则不转BAK表,等待下次继续发送
                            logger.error("Failed to send HHTBar to MQ!", e);

                            continue;
                        }

                        if (logger.isDebugEnabled()) {
                            logger
                                    .debug("Sended HHTBar to MQ successfully! xh--"
                                            + xh);
                        }
                    } else {
                        ErrorDataLog.error("HHTBar xh--" + xh);
                    }

                    backupRecords(dbConn, xh, to.getOpCode());
                }

                logger.info(logPrefix + "--Handled " + loadSize + " record(s)");
            }
            dbConn.commit();
            dbConn.setAutoCommit(true);

            return loadSize;
        } catch (Exception e) {
            logger.error("Exception Occured when sending HHTBar", e);

            try {
                if (dbConn != null) {
                    dbConn.rollback();
                }
            } catch (SQLException e1) {
                logger.error(e1);
            }
        } finally {
            mqManager.close(producer);
            mqManager.close(session);
            mqManager.close(mqConn);

            dbManager.close(dbConn);
        }

        return -1;
    }

    private void loadRecords(java.sql.Connection conn,
            List<BarRecordTempTO> records) throws SQLException {

        PreparedStatement pstmt = conn.prepareStatement(sql_load_record);

        pstmt.setLong(1, Thread.currentThread().getId());
        pstmt.setString(2, CommonHelper.getServerId());
        pstmt.setLong(3, task.getRecordSize());
        ResultSet rs = pstmt.executeQuery();

        BarRecordTempTO to;
        while (rs.next()) {
            to = new BarRecordTempTO();

            // to.setBillTraceId(0);//事务标识号
            String xh  = rs.getString("xh");	// ID
            String opCode = rs.getString("opcode");
            String reasonCode = rs.getString("why");// 原因代码
            Timestamp barScanTm = rs.getTimestamp("bartime");	// 扫描时间
            
            // 检查时间合法性,如出现1980年时间则进行转换成系统当前时间
            Date barTm = checkBarTmValid(barScanTm, xh);
            
            to.setOpCode(opCode);// 操作类型
            to.setWaybillNo(rs.getString("bno"));// 运单号（母运单号或子运单号)
            to.setZoneCode(rs.getString("zno"));// 网络网点号
            to.setBarOprCode(rs.getString("baropr"));// 操作员
            // 操作码为50，51，70，80, 82的，将巴枪操作员的工号，赋值给收派员
            if ("50".equals(opCode) || "51".equals(opCode)
                    || "70".equals(opCode) || "80".equals(opCode)
                    || "82".equals(opCode)) {
                to.setCourierCode(rs.getString("baropr"));// 收派员
            } else {
                to.setCourierCode(rs.getString("opr"));// 收派员
            }
            to.setBarScanTm(barTm);// 扫描时间

            if ("80".equals(opCode)) {
                to.setOpAttachInfo(rs.getString("opattach"));// 部分退回原因代码
            } else {
                to.setOpAttachInfo(rs.getString("pkg"));// 母运单号
            }
            

            to.setBarUploadTypeCode(rs.getLong("inputty"));// 输入方法
            to.setSubbillPieceQty(rs.getLong("pcs"));// 件数
            to.setWeightQty(rs.getDouble("weight"));// 重量

            if ("80".equals(opCode)) {
                to.setPhoneZone(rs.getString("proxy_signer"));// 代签收人姓名
                to.setPhone(rs.getString("courier_mobile_num"));// 收派员手机号码
                to.setDestZoneCode(rs.getString("codpayreason")); //COD付款方式变更原因
            } else {
                to.setPhoneZone(rs.getString("phonezone"));// 电话区号
                to.setPhone(rs.getString("phone"));// 电话号码
            }

            //to.setEncryptString(rs.getString("jmstr"));// 加密串
            to.setBarSn(rs.getString("sn"));// 设备号
            to.setExtendAttach6(rs.getString("attach"));// 是否有附件
            to.setExtendAttach7(rs.getString("warning"));// 是否有预警

            if ("50".equals(opCode) || "51".equals(opCode)) {
                try {
                    if (rs.getString("recv_sms") != null) {
                        to.setSignTypeCode(Long.parseLong(rs
                                .getString("recv_sms"))); // 收件触发短信标识
                    } else {
                        to.setSignTypeCode(0L);
                    }
                } catch (NumberFormatException ne) {
                    to.setSignTypeCode(0L);
                }

                to.setStayWhyCode(rs.getString("dist_code")); // 地域类型编码
                to.setExtendAttach3(rs.getString("locker_code"));// 储物柜编码
                to.setFeeAmt(rs.getDouble("over_long_weight_fee"));	// 超长超重附加费
                to.setExtendAttach6(rs.getString("ewaybill_correct"));	// 电子运单内容是否正确:1-错误,null-正确
            } else {
                // 注意：signurl如果为空，会报错
                if (rs.getString("signurl") == null) {
                    to.setSignTypeCode(0L);
                } else {
                    try {
                        to.setSignTypeCode(Long.parseLong(rs
                                .getString("signurl")));// 签收方式
                    } catch (NumberFormatException ne) {
                        to.setSignTypeCode(0L);
                    }
                }
                to.setStayWhyCode(reasonCode);// 原因代码
            }

            to.setAutoloading("3");// 上传数据的巴枪类型: DT900=1 DTX-5=2 HHT=3
            to.setProdType(rs.getString("prodtype"));// 产品类型
            // to.setExtendAttach4(rs.getString("box"));// 密码箱条码
            
            if ("82".equals(opCode)) {
                to.setExtendAttach5(WantedReasonCache.getContent(reasonCode));	// 通缉件需要传原因代码内容
            }
            
            if ("50".equals(opCode)) {
                to.setExtendAttach5(rs.getString("CONSIGNOR_PHONE"));	// 便利店需求－寄件方电话号码、储物柜需求-寄方电话号码
                to.setScheduleCode(rs.getString("medicine_box_code"));	// 医药箱编码
            }
            to.setAccountantCode(rs.getString("SF_CVS_CODE"));// 便利店需求－便利店代码
            // 判断子母件
            String bno = to.getWaybillNo();
            if (bno != null) {
                if (bno.startsWith("00")) {
                    to.setObjTypeCode(new Long(10));// 运单号码类型，10：子运单，20：母运单，30：包，40：,
                    // 50：袋，60：车
                } else {
                    to.setObjTypeCode(new Long(20));
                }
            }
            // 判断内部件
            if (bno != null) {
                if (bno.startsWith("888")) {
                    to.setExtendAttach2("1");
                }
            }
            // 暂时缓存，用于后续的转移数据和删除数据，在发送MQ消息时，要清空
            to.setOpName(xh);

            String cTypeCustomer = rs.getString("C_TYPE_CUSTOMER"); // C类客户

            if (cTypeCustomer != null) {
                if (cTypeCustomer.equals("B2C") || cTypeCustomer.equals("C2B")
                        || cTypeCustomer.equals("C2C")) {
                    to.setContnrCode(cTypeCustomer);
                } else {
                    to.setContnrCode(null);
                }
            }

            // COD代收货款，每日上缴业务
            if ("80".equals(opCode)) {
                to.setSrcContnrCode(rs.getString("MONEY"));// COD代收货款金额
                to.setOtherInfo(rs.getString("CODPAY"));// 付款方式 1：现金 2：POS机刷卡
                to.setBatchCode(rs.getString("COUPON_NO")); // 电子券号
                to.setExtendAttach3(rs.getString("DMCODE")); // DM条码
            }

            if ("50".equals(opCode)) {
                to.setBatchCode(rs.getString("COUPON_NO")); // 电子券号
                to.setSrcContnrCode(rs.getString("box")); // 寄方电话号码
                to.setEncryptString(String.valueOf(rs.getDouble("volume")));	// 体积
            }

            if ("50".equals(opCode) || "51".equals(opCode)) {
                to.setExtendAttach4(rs.getString("pkg0")); // 虚拟地址
                to.setDestZoneCode(rs.getString("SAFEST_EXPRESS_SMS")); // 特安触发短信标识
            }

            // 通缉回执巴枪
            if ("635".equals(opCode)) {
                to.setExtendAttach3(rs.getString("wantedty")); // 通缉回执巴枪的通缉类型
                to.setExtendAttach4(rs.getString("wantedcode")); // 被通缉巴枪操作码
            }

            // 二程接驳
            if ("46".equals(opCode) || "47".equals(opCode)) {
                to.setBarScanDt(rs.getTimestamp("bartime"));// 扫描日期
                to.setExtendAttach3(rs.getString("tran_name")); // 接驳点名称
                to.setStopOverFlg(1L); // 接驳标记
                to.setBatchCode(rs.getString("tran_code")); // 接驳线路编码
            }
            
            if ("9999".equals(opCode)) {
				to.setExtendAttach3(rs.getString("barcode"));	// 运力保贴码
			}
            
            //协助收派件
            if ("662".equals(opCode) || "663".equals(opCode)) {
				to.setExtendAttach3(rs.getString("assist_empno"));	// 被协助员工工号
			}
            
            //客户接触点交接
            if ("664".equals(opCode)) {
				to.setExtendAttach3(rs.getString("contact_point_code"));	// 客户接触点编码
			}
            
            //客户接触点派件
            if ("80".equals(opCode)) {
				to.setExtendAttach6(rs.getString("contact_point_code"));	// 客户接触点编码
			}
            
            //预约收派时间
            if ("70".equals(opCode)) {
            	
            	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            	Timestamp date = rs.getTimestamp("booktime");
            	if(date != null){
            		to.setExtendAttach3(sdf.format(date));
            	}
			}
            
            //通辑巴枪数据
           if("501".equals(opCode)) {
        	   to.setExtendAttach2(rs.getString("wl_code")); //物料编码
        	   to.setExtendAttach3(rs.getString("weight"));  //轻抛重量
        	   to.setExtendAttach4(rs.getString("cmd")); //类型
           }
            records.add(to);
        }

        dbManager.close(rs);
        dbManager.close(pstmt);
    }

    private void addZoneCode(java.sql.Connection conn, BarRecordTempTO to,
            String xh) {
        // 巴枪操作员baropr为空，不能回补
        String baropr = to.getBarOprCode();
        if (baropr == null || baropr.trim().equals("")) {
            logger.warn("Failed to fill up deptid: baropr is null. xh--" + xh);
            return;
        }

        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String deptid = null;

        try {
            pstmt = conn.prepareStatement(sql_get_deptid);
            pstmt.setString(1, baropr);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                deptid = rs.getString("deptid");
            }
            dbManager.close(pstmt);

            // 网点代码deptid为空，不能回补
            if (deptid == null || deptid.trim().equals("")) {
                logger
                        .warn("Failed to fill up deptid: Cannot find deptid by empid in employee table. xh--"
                                + xh);
                return;
            }

            to.setZoneCode(deptid);// 给TO对象赋值

            pstmt = conn.prepareStatement(sql_update_zno);
            pstmt.setString(1, deptid);
            pstmt.setString(2, xh);
            pstmt.executeUpdate();

            logger.info("Filled up deptied successfully! xh--" + xh
                    + "; deptid" + deptid);
        } catch (SQLException e) {
            logger.error(e);
            logger.warn("Failed to fill up deptid: SQLException occured. xh--"
                    + xh);
        } finally {
            dbManager.close(rs);
            dbManager.close(pstmt);
        }
    }

    private boolean verifyData(BarRecordTempTO to) {

        // verify bno data
        if (to.getWaybillNo() == null || to.getWaybillNo().trim().length() == 0) {
            return false;
        }

        // verify opcode data
        if (to.getOpCode() == null || to.getOpCode().trim().length() == 0) {
            return false;
        }

        // verify bartime data
        if (to.getBarScanTm() == null) {
            return false;
        }

        // verify baropr data
        if (to.getBarOprCode() == null
                || to.getBarOprCode().trim().length() == 0) {
            return false;
        }

        return true;
    }

    private void sendToMQ(MessageProducer producer, TextMessage msg,
            SGTransferObject to) throws SGConverterException, JMSException {
        String xml = sgConverter.toXML(to);

        msg.clearBody();
        msg.setText(xml);

        producer.send(msg);
    }

    private void backupRecords(java.sql.Connection conn, String xh,
            String opCode) throws SQLException {
        PreparedStatement pstmt = null;

        // OPCODE不等于44的巴枪数据，全部转到TBILLTRACE_BAK表
        if (!"44".equals(opCode)) {
            pstmt = conn.prepareStatement(sql_after_insert);
            pstmt.setString(1, xh);
            System.out.println(xh);
            pstmt.executeUpdate();
            dbManager.close(pstmt);
        }

        // 删除Tbilltrace数据
        pstmt = conn.prepareStatement(sql_after_delete);
        pstmt.setString(1, xh);
        pstmt.executeUpdate();

        dbManager.close(pstmt);
    }

    private Date checkBarTmValid(Date barTm, String xh){
    	Date returnBarTm = null;
    	Date now = new Date();
    	
    	try{
	    	if (barTm == null || ((barTm.before(now)) && ( DateUtil.getDayDiff(barTm) > 20 ))) {
	    		returnBarTm = now;
	    		
	    		logger.info("HHTBarWorker format bar time success, xh->"+xh);
			}else {
				returnBarTm = barTm;
			}
    	}catch (Exception e) {
			e.printStackTrace();
			
			returnBarTm = barTm;
			logger.error("HHTBarWorker check bar time exception, xh->"+xh);
		}

    	return returnBarTm;
    }
    
    public static void main(String[] args) {
		HHTBarWorker bar = new HHTBarWorker();
		System.out.println(bar.checkBarTmValid(new Timestamp(Calendar.getInstance().getTimeInMillis()), "1"));
    	
	}
}