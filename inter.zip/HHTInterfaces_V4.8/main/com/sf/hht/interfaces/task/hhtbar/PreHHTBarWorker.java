package com.sf.hht.interfaces.task.hhtbar;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.Random;

import oracle.jdbc.driver.OracleTypes;

import org.apache.log4j.Logger;

import com.sf.hht.interfaces.skeleton.core.TaskTracker;
import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.util.CommonHelper;

public class PreHHTBarWorker extends TaskWorker {

	private static final Logger logger = Logger.getLogger(PreHHTBarWorker.class);

	private static final String sql_before_load = "update tbilltrace set send_thread = ?, server_id=?, send_status = 1, send_tm = sysdate where send_status = 0 and rownum <= ?";
	// 数据接管
	private static final String SQL_RESET_STATUS = "update tbilltrace set send_status = 0 where send_status = 1 and send_tm < (sysdate - 10 / (24 * 60))";
	// 分配资源存储过程（同步）
	private static final String SQL_BEFORE_LOAD = "{call PKG_GET_SERVERID.p_tbilltrace(?,?,?,?,?)}";
	
	private static Random random = new Random();
	
	// 下次执行接口表状态复位时间
	private long nextResetTime = 0;

	private DBManager dbManager;
	private TaskTracker hhtBarTracker;
	private String hhtBarUpdateResourceMethod;

	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}
	public void setHhtBarTracker(TaskTracker hhtBarTracker) {
		this.hhtBarTracker = hhtBarTracker;
	}
	public void setHhtBarUpdateResourceMethod(String hhtBarUpdateResourceMethod) {
		this.hhtBarUpdateResourceMethod = hhtBarUpdateResourceMethod;
	}
	
	@Override
	public void preprocess() {
	}

	@Override
	protected void execute() {
		logger.info("PreHHTBarWorker start");
		
		long[] hhtBarWorkerIds = null;
		
		if (hhtBarTracker != null) {
			List<TaskWorker> workers = hhtBarTracker.getWorkers();
			
			if (workers != null && workers.size() != 0) {
				hhtBarWorkerIds = new long[workers.size()];
				
				for (int i = 0; i < workers.size(); i++) {
					hhtBarWorkerIds[i] = workers.get(i).getId();
				}
			}
		}
		
		if (hhtBarWorkerIds == null) {
			logger.error("Cannot find any HHTBarWorker");
			return;
		}
		
		while (running) {
			try {
				int handleRows = 0;
				
				if ("1".equals(hhtBarUpdateResourceMethod)) {
					handleRows = handleRecords(hhtBarWorkerIds);
				}else {
					handleRows = handleRecordsNew(hhtBarWorkerIds);
				}
				
				if (System.currentTimeMillis() > nextResetTime) {
					// 更新处理失败数据状态
					int count = resetStatus();
					
					logger.info("PreHHTBarWorker reset record status count->"+count);
					
					// 设置下次执行复位操作的时间为：10分钟之后
					nextResetTime = System.currentTimeMillis() + (10 * 60 * 1000);
				}
			
				if (handleRows < task.getRecordSize()) {
					makeWait(task.getPeriod());
				}
			} catch (Exception e) {
				logger.error("Exception Occured", e);
			}
		}
		
		logger.info("PreHHTBarWorker end");
	}
	
	
	private int handleRecords(long[] hhtBarWorkerIds) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = dbManager.getConnection();
			pstmt = conn.prepareStatement(sql_before_load);
			
			pstmt.setLong(1, getHHTBarWorkerId(hhtBarWorkerIds));
			pstmt.setString(2, CommonHelper.getServerId());
			pstmt.setLong(3, task.getRecordSize());
			
			int affectRecordCount = pstmt.executeUpdate();
			
			if (affectRecordCount > 0) {
				logger.info("PreHHTBarWorker--Updated " + affectRecordCount + " record(s)");
			}

			return affectRecordCount;
		} catch (Exception e) {
			logger.error("Exception Occured when updating send_status in tbilltrace in advance", e);
		} finally {
			dbManager.close(pstmt);
			dbManager.close(conn);
		}
		
		return -1;
	}
	
	
	private int handleRecordsNew(long[] hhtBarWorkerIds) {
		Connection conn = null;
		CallableStatement cs = null;
		int affectRecordCount = 0;
		int lockFlag = 0;
		
		try {
			conn = dbManager.getConnection();
			cs = conn.prepareCall(SQL_BEFORE_LOAD);
			
			cs.setString(1, CommonHelper.getServerId());
			cs.setLong(2, getHHTBarWorkerId(hhtBarWorkerIds));
			cs.setLong(3, task.getRecordSize());
			cs.registerOutParameter(4, OracleTypes.INTEGER);
			cs.registerOutParameter(5, OracleTypes.INTEGER);
			
			cs.execute();
			
			lockFlag = cs.getInt(4);
			affectRecordCount = cs.getInt(5);
			
//			if (affectRecordCount > 0) {
				logger.info("PreHHTBarWorker--Updated " + affectRecordCount + " record(s),lockFlag--"+lockFlag);
//			}

			return affectRecordCount;
		} catch (Exception e) {
			logger.error("Exception Occured when updating send_status in tbilltrace in advance", e);
		} finally {
			dbManager.close(cs);
			dbManager.close(conn);
		}
		
		return -1;
	}
	
	/**
	 * 重置发送失败数据状态
	 * description
	 * Aug 9, 2013
	 */
	private int resetStatus(){
		int count = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = dbManager.getConnection();
			
			pstmt = conn.prepareStatement(SQL_RESET_STATUS);
			count = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			dbManager.close(pstmt);
			dbManager.close(conn);
		}
		
		return count;
	}
	
	private long getHHTBarWorkerId(long[] hhtBarWorkerIds) {
		return hhtBarWorkerIds[random.nextInt(hhtBarWorkerIds.length)];
	}
	
}