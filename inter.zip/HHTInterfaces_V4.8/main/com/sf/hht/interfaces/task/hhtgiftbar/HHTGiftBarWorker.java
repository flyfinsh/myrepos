package com.sf.hht.interfaces.task.hhtgiftbar;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONObject;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.util.CommonHelper;
import com.sf.hht.interfaces.task.hhtgiftbar.dto.HHTGiftBarDtoRequest;
import com.sf.hht.interfaces.task.hhtgiftbar.dto.HHTGiftBarResponse;

public class HHTGiftBarWorker extends TaskWorker {
	private static final Logger LOG = Logger.getLogger(HHTGiftBarWorker.class);
	
	// 加载需要处理的数据
	private static final String SQL_LOAD_RECORDS = "select id, bar_emp_code, dept_code, nvl(to_char(bar_tm, 'yyyy-mm-dd HH:mi:ss'), null) bar_tm, gift_code from gift_bar_record where send_thread = ? and server_id = ? and send_status = 1 and rownum <= ?";
	// 记录与线程绑定
	private static final String SQL_BEFORE_LOAD = "update gift_bar_record set server_id = ?, send_thread = ?, send_status = 1, send_tm = sysdate where send_status = 0 and rownum <= ?";
	// 返回结果更新到对应记录
	private static final String SQL_AFTER_UPDATE = "update gift_bar_record set send_status = 2 where id = ?";
	// 数据接管
	private static final String SQL_RESET_STATUS = "update gift_bar_record set send_status = 0 where send_status = 1 and send_tm < (sysdate - 10 / (24 * 60))";
	
	// 下次执行接口表状态复位时间
	private long nextResetTime = 0;
	
	// 数据库连接管理
	private DBManager dbManager;
	
	// 顺手拍礼品数据上传地址
	private String pushUrl;
	// http连接超时时间
	private String httpConnectionTimeout;
	private String httpSoTimeout;
	
	// 调用方法名称
	private static final String API = "attach_barcode_for_courier";
	// 响应成功代码
	private static final String SUCCESS = "OK";
	
	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}
	
	public void setPushUrl(String pushUrl) {
		this.pushUrl = pushUrl;
	}

	public void setHttpConnectionTimeout(String httpConnectionTimeout) {
		this.httpConnectionTimeout = httpConnectionTimeout;
	}

	public void setHttpSoTimeout(String httpSoTimeout) {
		this.httpSoTimeout = httpSoTimeout;
	}

	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("HHTGiftBarWorker[").append(Thread.currentThread().getId()).append("]");
		
		LOG.info(logPrefix.toString() + " start");

		while(running){
			try{
				int handleRows = handleRecords(logPrefix.toString());
				
				if (System.currentTimeMillis() > nextResetTime) {
					// 更新处理失败数据状态
					int count = resetStatus();
					
					LOG.info("HHTGiftBarWorker reset record status count->"+count);
					
					// 设置下次执行复位操作的时间为：10分钟之后
					nextResetTime = System.currentTimeMillis() + (10 * 60 * 1000);
				}
				
				if(handleRows < task.getRecordSize()){
					makeWait(task.getPeriod());
				}
			}catch(Exception e){
				LOG.error("HHTGiftBarWorker sync data exception", e);
			}
		}
		
		LOG.info(logPrefix + " end");
	}
	
	private int handleRecords(String logPrefix){
		List<HHTGiftBarDtoRequest> records = new ArrayList<HHTGiftBarDtoRequest>();
		
		Connection conn = null;
		try{
			// 更新发送状态
			beforeLoadRecords();
			
			conn = dbManager.getConnection();
			conn.setAutoCommit(false);
			
			// 加载数据
			loadRecords(conn, records);
			
			int loadSize = records.size();
			
			if(loadSize > 0){
				for(HHTGiftBarDtoRequest to : records){
					HHTGiftBarResponse giftBarResponse = null;
					String result = null;
					
					try {
						// 请求数据对象转换成json
						String request = convertRequestToJson(to);
						// 推送数据
						String response = sendData(request);
						// 响应Json报文转成数据对象
						giftBarResponse = convertReponseToDto(response);
						result = giftBarResponse.getResult();
						
						LOG.info("HHTGiftBarWorker http response successfully, id->" + to.getId() + ", result->"+result);
					}catch(Exception e){
						LOG.info("HHTGiftBarWorker http response failure, id->" + to.getId() + ", result->"+result);
						e.printStackTrace();
					}
					
					if(null != giftBarResponse 
							&& giftBarResponse.getResult().equals(SUCCESS)){
						// 更新数据状态为成功
						updateStatus(conn, to.getId());
					}
				}
				
				LOG.info(logPrefix + "--Handled " + loadSize + " record(s)");
			}
			
			conn.commit();
			conn.setAutoCommit(true);
			
			return loadSize;
		}catch(Exception e){
			LOG.error("HHTGiftBarWorker receive data exception ", e);

			try {
				if (conn != null) {
					conn.rollback();
				}
			} catch (SQLException e1) {
				LOG.error(e1);
			}
		}finally{
			// 关闭数据库连接
			dbManager.close(conn);
		}
		return -1;
	}
	
	private int beforeLoadRecords() throws SQLException{
		Connection conn = null;
		PreparedStatement pstmt = null;
		int affectRecordCount = 0;
		
		try {
			conn = dbManager.getConnection();
			
			pstmt = conn.prepareStatement(SQL_BEFORE_LOAD);
			pstmt.setString(1, CommonHelper.getServerId());
			pstmt.setLong(2, Thread.currentThread().getId());
			pstmt.setLong(3, task.getRecordSize());
			
			affectRecordCount = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}finally{
			dbManager.close(conn);
			dbManager.close(pstmt);
		}
		
		return affectRecordCount;
	}
	
	private void loadRecords(Connection conn, List<HHTGiftBarDtoRequest> records) throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(SQL_LOAD_RECORDS);
			pstmt.setLong(1, Thread.currentThread().getId());
			pstmt.setString(2, CommonHelper.getServerId());
			pstmt.setLong(3, task.getRecordSize());
			
			rs = pstmt.executeQuery();
			
			HHTGiftBarDtoRequest to;
			while(rs.next()){
				to = new HHTGiftBarDtoRequest();
				to.setApi(API);
				to.setId(rs.getLong("id"));
				to.setCourier_id(rs.getString("bar_emp_code"));
				to.setBarcodes(rs.getString("gift_code"));
				to.setDept_code(rs.getString("dept_code"));
				to.setScan_time(rs.getString("bar_tm"));
				records.add(to);
			}
		} finally{
			dbManager.close(rs);
			dbManager.close(pstmt);
		}
		
	}
	
	private void updateStatus(Connection conn, Long id) throws SQLException {
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(SQL_AFTER_UPDATE);
			pstmt.setLong(1, id);
			pstmt.executeUpdate();
		} finally {
			dbManager.close(pstmt);
		}
		
	}
	
	private int resetStatus(){
		int count = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = dbManager.getConnection();
			
			pstmt = conn.prepareStatement(SQL_RESET_STATUS);
			count = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			dbManager.close(pstmt);
			dbManager.close(conn);
		}
		
		return count;
	}
	
	/**
	 * 将请求数据对象转换成JSON
	 * Mar 27, 2014
	 * @param request
	 * @return
	 */
	private String convertRequestToJson(HHTGiftBarDtoRequest request){
		JSONObject jsonObject = JSONObject.fromObject(request);
		return jsonObject.toString();
	}
	
	/**
	 * 将响应JSON报文转换成数据对象
	 * Mar 27, 2014
	 * @param response
	 * @return
	 */
	private HHTGiftBarResponse convertReponseToDto(String response){
		HHTGiftBarResponse giftBarResponse = (HHTGiftBarResponse) JSONObject.toBean(JSONObject.fromObject(response), HHTGiftBarResponse.class);
		return giftBarResponse;
	}
	
	/**
	 * 推送数据 
	 * Mar 27, 2014
	 * @param request
	 * @return
	 */
	private String sendData(String request){
		String responseJson = null;
		HttpClient httpClient = null;
		HttpResponse response = null;
		HttpEntity entity = null;
		
		try {
			httpClient = new DefaultHttpClient();
			// 设置Cookie兼容性
			httpClient.getParams().setParameter(ClientPNames.COOKIE_POLICY, CookiePolicy.BROWSER_COMPATIBILITY);
			// 请求超时
			httpClient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, Integer.parseInt(httpConnectionTimeout));
		    // 读取超时
			httpClient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, Integer.parseInt(httpSoTimeout));
			
			List <NameValuePair> params = new ArrayList<NameValuePair>();  
	        params.add(new BasicNameValuePair("params", request));  
	        
	        HttpPost httpPost = new HttpPost(pushUrl);
	        httpPost.setEntity(new UrlEncodedFormEntity(params,HTTP.UTF_8));
			
			// 发起HTTP请求
	        response = httpClient.execute(httpPost);
	        
	        if(response != null 
	        		&& HttpStatus.SC_OK == response.getStatusLine().getStatusCode() ){
	        	entity = response.getEntity(); // 返回服务器响应 
	        	if (entity != null) {
	        		responseJson = EntityUtils.toString(entity); //返回服务器响应HTML代码
				}
	        }
	  
	        System.out.println("HHTGiftBarWorker send request successfully, response->"+responseJson);
	  
	    } catch (Exception e) {
	    	e.printStackTrace();
	    	System.out.println("HHTGiftBarWorker send request exception->" + e.toString());

	    	throw new RuntimeException();
	    } finally {
	    	try {
	    		if (entity != null) {  
	    			EntityUtils.consume(entity); // 释放连接  
		        }
	    		
	    		if (httpClient != null) {
					httpClient.getConnectionManager().shutdown();	// 关闭连接
				}
			} catch (Exception e) {
				System.out.println("HHTGiftBarWorker consume content exception : " + e.toString());
				e.printStackTrace();			
			}
	  
	    }
	    
	    return responseJson;
	}

	@Override
	public void preprocess() {
	}

	public static void main(String[] args) {
		
		HHTGiftBarWorker worker = new HHTGiftBarWorker();
		
		HHTGiftBarDtoRequest request = new HHTGiftBarDtoRequest();
		request.setId(1L);
		request.setApi(API);
		request.setBarcodes("123123123,456456456,789789789");
		request.setCourier_id("000212");
		request.setDept_code("755A");
		request.setScan_time("2014-03-27 16:52:12");
		
		
		String json = worker.convertRequestToJson(request);
//		System.out.println(json);
//		String response = "{\"result\":\"OK\",\"msg\":\"xxxxxxx\"}";
//		
//		HHTGiftBarResponse giftBarResponse = worker.convertReponseToDto(response);
//		System.out.println(giftBarResponse.getResult());
//		System.out.println(giftBarResponse.getMsg());
		
		worker.setPushUrl("http://skss.sfdc.com.cn/api/hht");
		worker.sendData(json);
	}
}
