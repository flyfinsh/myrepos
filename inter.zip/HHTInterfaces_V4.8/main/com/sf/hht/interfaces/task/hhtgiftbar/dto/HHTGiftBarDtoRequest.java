package com.sf.hht.interfaces.task.hhtgiftbar.dto;

public class HHTGiftBarDtoRequest {
	private Long id;
	// 方法名称
	private String api;
	// 工号
	private String courier_id;
	// 扫描时间
	private String scan_time;
	// 网点编码
	private String dept_code;
	// 礼品编码
	private String barcodes;
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getApi() {
		return api;
	}
	public void setApi(String api) {
		this.api = api;
	}
	public String getCourier_id() {
		return courier_id;
	}
	public void setCourier_id(String courier_id) {
		this.courier_id = courier_id;
	}
	public String getScan_time() {
		return scan_time;
	}
	public void setScan_time(String scan_time) {
		this.scan_time = scan_time;
	}
	public String getDept_code() {
		return dept_code;
	}
	public void setDept_code(String dept_code) {
		this.dept_code = dept_code;
	}
	public String getBarcodes() {
		return barcodes;
	}
	public void setBarcodes(String barcodes) {
		this.barcodes = barcodes;
	}
}
