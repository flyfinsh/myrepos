package com.sf.hht.interfaces.task.hkmactwcod;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;

import com.sf.framework.integration.ISGConverter;
import com.sf.hht.interfaces.skeleton.cache.Employee;
import com.sf.hht.interfaces.skeleton.cache.WantedReasonCache;
import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.log.ErrorDataLog;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.resource.MQManager;
import com.sf.integration.sss.dto.RmsCodDto;

public class HkMacTwCodWorkder extends TaskWorker{
	
	private static final Logger LOG = Logger.getLogger(HkMacTwCodWorkder.class);
	
	private static final String SQL_QUERY_EMP_BY_DEPT = "select empid, deptid from employee where deptid = ?";
	private static final String SQL_INSERT_WAYBILLCOD = "insert into waybillcod(id,empid,bno,money,type) values (SEQ_WAYBILLCOD_ID.nextval,?,?,?,'0')";
	private static final String SQL_CHECK_COD_EXIST = "select count(1) from waybillcod t where t.bno = ? and empid = ? and t.instdate >= trunc(sysdate) and t.instdate < trunc(sysdate+1)";
	
	private DBManager dbManager;
	private MQManager mqManager;
	private Destination queue;
	private ISGConverter sgConverter;
	private long receiveTimeout;
	
	@Override
	public void preprocess() {}

	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("HkMacTwCodWorkder[").append(Thread.currentThread().getId()).append("]");
		
		LOG.info(logPrefix.toString() + " start");
		
		while (running) {
			try {
				receive(logPrefix.toString());
			
				makeWait(task.getPeriod());
			} catch (Exception e) {
				e.printStackTrace();
				LOG.error("HkMacTwCodWorkder execute exception", e);
			}
		}
		
		LOG.info(logPrefix + " end");
	}
	
	/**
	 * 接收并且保存waybillcod数据
	 * Apr 26, 2013
	 * @param logPrefix
	 */
	private void receive(String logPrefix){
		LOG.info(logPrefix + " is running");
		
		javax.jms.Connection mqConn = null;
		Session session = null;
		MessageConsumer consumer = null;
		
		try {
			mqConn = mqManager.getConnection();
			mqConn.start();
			
			session = mqConn.createSession(false, Session.AUTO_ACKNOWLEDGE);
			consumer = session.createConsumer(queue);
			
			try {
				String message = receive(consumer);
				
				while (message != null) {
					if (LOG.isDebugEnabled()) {
						LOG.debug(logPrefix + " received rmscod:" + message);
					}
					
					RmsCodDto to = null;
					try {
						to = (RmsCodDto) sgConverter.fromXML(message, RmsCodDto.class);
					} catch (Exception e) {
						e.printStackTrace();
						ErrorDataLog.error("HkMacTwCodWorkder convert xml exception, message->"+message);
					}
					
					try {
						if (to != null) {
							handleWaybillCod(to);
							
							LOG.info("HkMacTwCodWorkder handle cod successful, bno->"+to.getWaybillNo());
						}
					} catch (Exception e) {
						e.printStackTrace();
						ErrorDataLog.error("HkMacTwCodWorkder handle waybillcod exception, message->"+message);
					}
					
					message = receive(consumer);
					
				}
			} catch (Exception e) {
				e.printStackTrace();
				LOG.error("HkMacTwCodWorkder receiving data exception", e);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error("HkMacTwCodWorkder connect mq exception", e);
		}finally {
			mqManager.close(consumer);
			mqManager.close(session);
			mqManager.close(mqConn);
		}
	}
	
	/**
	 * 保存waybillcod信息
	 * Apr 26, 2013
	 * @param rmsCodDto
	 * @throws SQLException
	 */
	private void handleWaybillCod(RmsCodDto rmsCodDto) throws SQLException{
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try{
			conn = dbManager.getConnection();
			pstmt = conn.prepareStatement(SQL_INSERT_WAYBILLCOD);
			
			String deptCode = rmsCodDto.getDeptCode();		// 网点编码
			String bno = rmsCodDto.getWaybillNo();			// 运单号
			String money = rmsCodDto.getInfo();				// 金额
			String empCode = null;							// 员工工号
			
			if (deptCode != null) {
				// 从缓存中获取部门所有员工工号
				List<Employee> empList = WantedReasonCache.getEmployees(deptCode);
				
				if (empList == null || empList.size() == 0) {
					// 如果没有从缓存中查到该网点员工则直接从数据库中查询
					empList = queryEmployees(conn, deptCode);
					
					LOG.info("HkMacTwCodWorkder didn't get from cache, deptCode->"+deptCode);
				}else {
					LOG.info("HkMacTwCodWorkder get from cache null, deptCode->"+deptCode);
				}
				
				if (empList != null || empList.size() > 0) {
					// 网点下所有员工工号都下发waybillcod信息
					for (Employee employee : empList) {
						try{
							empCode = employee.getEmpId();
							
							// 判断同一工号当天是否保存同一运单号的waybillcod信息
							if(!checkCodWaybillExist(conn, bno, empCode)){
								pstmt.setString(1, empCode);
								pstmt.setString(2, bno);
								pstmt.setString(3, money);
								
								pstmt.executeUpdate();
							}
							
						}catch (Exception e) {
							LOG.error("HkMacTwCodWorkder save waybillcod exception, empId->"+empCode);
							e.printStackTrace();
						}
					}
				}else {
					LOG.info("HkMacTwCodWorkder get empty employee list, deptCode->"+deptCode);
				}
			}
		}finally{
			dbManager.close(conn);
			dbManager.close(pstmt);
		}
	}
	
	
	/**
	 * 按网点编码查询员工信息
	 * Apr 26, 2013
	 * @param conn
	 * @param deptCode
	 * @return
	 * @throws SQLException
	 */
	private List<Employee> queryEmployees(Connection conn, String deptCode) throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Employee> list = new ArrayList<Employee>();
		
		try {
			pstmt = conn.prepareStatement(SQL_QUERY_EMP_BY_DEPT);
			pstmt.setString(1, deptCode);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				Employee employee = new Employee();
				employee.setEmpId(rs.getString("empid"));
				employee.setDeptId(rs.getString("deptid"));
				
				list.add(employee);
			}
		}finally{
			dbManager.close(rs);
			dbManager.close(pstmt);
		}
		
		return list;
	}
	
	
	/**
	 * 根据运单号检查当天是否存在该COD运单
	 * Apr 26, 2013
	 * @param conn
	 * @param to
	 * @return
	 * @throws SQLException
	 */
	private boolean checkCodWaybillExist(Connection conn, String bno, String empId) throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		boolean isExist = false;
		
		try {
			pstmt = conn.prepareStatement(SQL_CHECK_COD_EXIST);
			pstmt.setString(1, bno);
			pstmt.setString(2, empId);
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				int count = rs.getInt(1);
				
				if (count > 0) {
					isExist = true;
				}
			}
		} finally {
			dbManager.close(rs);
			dbManager.close(pstmt);
		}
		
		return isExist;
	}


	private String receive(MessageConsumer consumer) throws JMSException {
		Message message = consumer.receive(receiveTimeout);
		
		if (message instanceof TextMessage) {
			return ((TextMessage) message).getText();
		} else {
			return null;
		}
	}
	
	/***************get/set方法******************/
	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}

	public void setMqManager(MQManager mqManager) {
		this.mqManager = mqManager;
	}

	public void setQueue(Destination queue) {
		this.queue = queue;
	}

	public void setSgConverter(ISGConverter sgConverter) {
		this.sgConverter = sgConverter;
	}

	public void setReceiveTimeout(long receiveTimeout) {
		this.receiveTimeout = receiveTimeout;
	}
	
}
