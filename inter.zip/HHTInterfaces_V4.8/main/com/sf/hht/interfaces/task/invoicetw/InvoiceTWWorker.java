package com.sf.hht.interfaces.task.invoicetw;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.sf.framework.integration.ISGConverter;
import com.sf.framework.integration.SGConverterException;
import com.sf.framework.integration.dto.SGTransferObject;
import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.log.ErrorDataLog;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.resource.MQManager;
import com.sf.hht.interfaces.skeleton.util.CommonHelper;
import com.sf.integration.taxinv.dto.TWHhtInvoiceTO;

public class InvoiceTWWorker extends TaskWorker {

	private static final Logger logger = Logger.getLogger(InvoiceTWWorker.class);

	private static final String sql_before_load = "update printinvoice_tw set server_id = ?, send_thread = ?, send_status = 1, send_tm = sysdate where send_status = 0 and rownum <= ?";
	private static final String sql_load_record = "select id, bno, inv_no, cust_code, cust_name, empid, deptid, print_time, fee1, fee2, fee3, fee4, fee5, sale_amt, tax, total, bill_flag, print_type, rand_no, love_no, carry_no, title, ban, tel, address, fee6, billing_method, import_duty, cod, fees, collecting_import_duty, monthly_account, gathering_in, cash, credit_card, cheque from printinvoice_tw where server_id = ? and send_thread = ? and send_status = 1 and rownum <= ?";
	private static final String sql_after_update = "update printinvoice_tw set send_status = 2 where id = ?";
	// 数据接管
	private static final String SQL_RESET_STATUS = "update printinvoice_tw set send_status = 0 where send_status = 1 and send_tm < (sysdate - 10 / (24 * 60))";
	
	// 下次执行接口表状态复位时间
	private long nextResetTime = 0;

	private DBManager dbManager;
	private MQManager mqManager;
	private Destination queue;
	private ISGConverter sgConverter;
	
	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}
	public void setMqManager(MQManager mqManager) {
		this.mqManager = mqManager;
	}
	public void setQueue(Destination queue) {
		this.queue = queue;
	}
	public void setSgConverter(ISGConverter sgConverter) {
		this.sgConverter = sgConverter;
	}
	
	@Override
	public void preprocess() {
	}
	
	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("InvoiceTWWorker[").append(Thread.currentThread().getId()).append("]");
		
		logger.info(logPrefix.toString() + " start");
		
		while (running) {
			try {
				int handleRows = handleRecords(logPrefix.toString());
				
				if (System.currentTimeMillis() > nextResetTime) {
					// 更新处理失败数据状态
					int count = resetStatus();
					
					logger.info("InvoiceTWWorker reset record status count->"+count);
					
					// 设置下次执行复位操作的时间为：10分钟之后
					nextResetTime = System.currentTimeMillis() + (10 * 60 * 1000);
				}
			
				if (handleRows < task.getRecordSize()) {
					makeWait(task.getPeriod());
				}
			} catch (Exception e) {
				logger.error("Exception Occured", e);
			}
		}
		
		logger.info(logPrefix + " end");
	}
	
	
	private int handleRecords(String logPrefix) {
		List<TWHhtInvoiceTO> records = new ArrayList<TWHhtInvoiceTO>();
		
		javax.jms.Connection mqConn = null;
		Session session = null;
		MessageProducer producer = null;
		
		java.sql.Connection dbConn = null;
		
		try {
			//update send_statua
			beforeLoadRecords();
			
			dbConn = dbManager.getConnection();
			
			dbConn.setAutoCommit(false);
			
			loadRecords(dbConn, records);
			
			int loadSize = records.size();
			
			if (loadSize > 0) {
				
				mqConn = mqManager.getConnection();
				session = mqConn.createSession(false, Session.AUTO_ACKNOWLEDGE);
				producer = session.createProducer(queue);
				producer.setDeliveryMode(DeliveryMode.PERSISTENT);
				TextMessage textMessage = session.createTextMessage();
				
				for (TWHhtInvoiceTO to : records) {
					//获得事务ID号，并将TO对象中的事务ID号清空
					Long id = Long.valueOf(to.getRemark());
					to.setRemark(null);

					try {
						sendToMQ(producer, textMessage, to);
					} catch (SGConverterException ce) {
						ce.printStackTrace();
						//数据异常单独记录日志文件,然后更新数据库记录状态
						ErrorDataLog.error("InvoiceTW[" + id + "]");
					} catch (Exception e) {
						//其它异常则不更新数据库记录状态,等待下次继续发送
						logger.error("Failed to send InvoiceTW to MQ!", e);
						
						continue;
					}
					
					if (logger.isDebugEnabled()) {
						logger.debug("Sended InvoiceTW to MQ successfully! id--" + id);
					}

					updateSendStatus(dbConn, id);
				}
				
				logger.info(logPrefix + "--Handled " + loadSize + " record(s)");
			}
			
			dbConn.commit();
			dbConn.setAutoCommit(true);
			
			return loadSize;
		} catch (Exception e) {
			logger.error("Exception Occured when sending Invoice", e);

			try {
				if (dbConn != null) {
					dbConn.rollback();
				}
			} catch (SQLException e1) {
				logger.error(e1);
			}
		} finally {
			mqManager.close(producer);
			mqManager.close(session);
			mqManager.close(mqConn);
			
			dbManager.close(dbConn);
		}
		
		return -1;
	}
	
	private int beforeLoadRecords() throws SQLException {
		int affectRecordCount = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = dbManager.getConnection();
			
			pstmt = conn.prepareStatement(sql_before_load);
			pstmt.setString(1, CommonHelper.getServerId());
			pstmt.setLong(2, Thread.currentThread().getId());
			pstmt.setLong(3, task.getRecordSize());
			
			affectRecordCount = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			
			throw new RuntimeException(e);
		}finally{
			dbManager.close(pstmt);
			dbManager.close(conn);
		}
		
		return affectRecordCount;
	}

	
	private void loadRecords(java.sql.Connection conn, List<TWHhtInvoiceTO> records) 
			throws SQLException {

		PreparedStatement pstmt = conn.prepareStatement(sql_load_record);
		pstmt.setString(1, CommonHelper.getServerId());
		pstmt.setLong(2, Thread.currentThread().getId());
		pstmt.setLong(3, task.getRecordSize());
		
		ResultSet rs = pstmt.executeQuery();
		
		TWHhtInvoiceTO to;
		while (rs.next()) {
			to = new TWHhtInvoiceTO();
			to.setWaybillNo(StringUtils.defaultIfBlank((rs.getString("bno")),"000000000000"));
			to.setInvoiceNo(rs.getString("inv_no"));
			to.setCustUnifiedCode(rs.getString("cust_code"));
			to.setCustInvoiceName(rs.getString("cust_name"));
			to.setInvoiceEmpCode(rs.getString("empid"));
			to.setDeptCode(rs.getString("deptid"));
			to.setInvoiceDate(rs.getTimestamp("print_time"));
			to.setFeeItemAmt(rs.getDouble("fee1"));     //运费
			to.setRcServiceItemAmt(rs.getDouble("fee2"));  //入仓服务费
			to.setCustomServiceItemAmt(rs.getDouble("fee3")); //报关服务费
			to.setRcItemAmt(rs.getDouble("fee4"));  //入仓费
			to.setOtherItemAmt(rs.getDouble("fee5")); //其他费用
			to.setSaleSumAmt(rs.getDouble("sale_amt"));
			to.setIncomeFeeAmt(rs.getDouble("tax"));
			to.setTotalAmt(rs.getDouble("total"));
			to.setWaybillTypeCode(rs.getString("bill_flag"));	// 是否多票
			to.setInvoiceKindCode(rs.getString("print_type")); 	// 打印类型
			to.setRandomCode(rs.getString("rand_no"));		// 随机码
			to.setLoveCode(rs.getString("love_no")); 		// 爱心码
			to.setInvoiceVehicleCode(rs.getString("carry_no")); 	// 发票载具码
			to.setCompanyName(rs.getString("title")); 	// 公司名称
			to.setBusinessUnitedNumber(rs.getString("ban")); 	// 营业人统一编号
			to.setCompanyTel(rs.getString("tel")); 	// 营业人电话
			to.setCompanyAddress(rs.getString("address")); 	// 营业人地址
			to.setFuelSurchargeFee(rs.getDouble("fee6"));	// 燃油附加费
			/* 新增字段 */
			to.setGatheringWay(rs.getString("billing_method"));	//收款方式
			to.setMonthCustomerCardNo(rs.getString("monthly_account")); //月结客户卡号
			to.setGatheringMonth(rs.getString("gathering_in"));	//收款月份
			to.setCash(rs.getDouble("cash"));	//现金
			to.setCheque(rs.getDouble("cheque")); //支票
			to.setTheCreditCard(rs.getDouble("credit_card"));	//信用卡
			to.setCodImportDuties(rs.getDouble("collecting_import_duty"));	//代收进口关税
			to.setImportDuties(rs.getDouble("import_duty"));	//进口关税
			to.setCod(rs.getDouble("cod"));		//代收货款
			to.setFees(rs.getDouble("fees"));	//规费
	
			// 暂时缓存，用于后续更新数据，在发送MQ消息时，要清空
			to.setRemark(rs.getString("id"));

			records.add(to);
		}
		
		dbManager.close(rs);
		dbManager.close(pstmt);
	}
	
	private void sendToMQ(MessageProducer producer, TextMessage msg, SGTransferObject to) 
			throws SGConverterException, JMSException {
		String xml = sgConverter.toXML(to);
		
		msg.clearBody();
		msg.setText(xml);
		producer.send(msg);
	}
	
	private void updateSendStatus(java.sql.Connection conn, Long id) 
			throws SQLException {
		PreparedStatement pstmt = null;
		
		//更新数据
		pstmt = conn.prepareStatement(sql_after_update);
		pstmt.setLong(1, id);
		pstmt.executeUpdate();
		
		dbManager.close(pstmt);
	}
	
	
	/**
	 * 重置发送失败数据状态
	 * Aug 12, 2013
	 * @return
	 */
	private int resetStatus(){
		int count = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = dbManager.getConnection();
			
			pstmt = conn.prepareStatement(SQL_RESET_STATUS);
			count = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			dbManager.close(pstmt);
			dbManager.close(conn);
		}
		
		return count;
	}
	
}