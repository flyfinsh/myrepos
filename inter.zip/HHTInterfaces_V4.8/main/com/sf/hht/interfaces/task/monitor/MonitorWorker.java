package com.sf.hht.interfaces.task.monitor;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.sms.SMSNotifier;

public class MonitorWorker extends TaskWorker {

	private static final Logger logger = Logger.getLogger(MonitorWorker.class); 

	private List<TableUnit> tableUnits;
	private SMSNotifier smsNotifier;
	// 表监控短信开关
	private boolean smsAlarm;

	public void setTableUnits(List<TableUnit> tableUnits) {
		this.tableUnits = tableUnits;
	}
	public void setSmsNotifier(SMSNotifier smsNotifier) {
		this.smsNotifier = smsNotifier;
	}
	public void setSmsAlarm(boolean smsAlarm) {
		this.smsAlarm = smsAlarm;
	}	
	
	@Override
	public void preprocess() {
		//do nothing
	}
	
	@Override
	protected void execute() {
		logger.info("MonitorWorker start");
		
		while (running) {
			try {
				for (TableUnit unit : tableUnits) {
					monitorTable(unit);
				}
			
				makeWait(task.getPeriod());
			} catch (Exception e) {
				logger.error("Exception Occured", e);
			}
		}
		
		logger.info("MonitorWorker end");
	}
	
	private void monitorTable(TableUnit tableUnit) {
		StringBuffer body = new StringBuffer();
		
		DBManager dbManager = tableUnit.getDbManager();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		int count = 0;
		
		try {
			StringBuffer sql = new StringBuffer();
			sql.append("select count(*) from ").append(tableUnit.getTable());
			if (tableUnit.getSendStatus() >= 0) {
				sql.append(" where send_status=").append(tableUnit.getSendStatus());
			}
			
			if (logger.isDebugEnabled()) {
				logger.debug("Monitor SQL:" + sql.toString());
			}
			
			conn = dbManager.getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql.toString());
			
			if (rs.next()) {
				count = rs.getInt(1);
			}
			
			if (count > tableUnit.getMaxSize()) {
				body.append("数据库").append(tableUnit.getDbName()).append("表").append(tableUnit.getTable())
					   .append("中积压了").append(count).append("条数据!");
			}
		}catch (SQLException e){
			logger.error("DataBase exception", e);
			
			// 短信提示开关
			if (smsAlarm) {
				// 数据连接异常发送短信提示
				String message = getMessagePrefix().append(":").append(tableUnit.getDbName()).append("数据库连接异常,请尽快解决!").toString();
				smsNotifier.sendMessage(message);
				System.out.println("短信息已发送！");
			}
		} catch (Exception e) {
			logger.error("Exception Occured when monitoring table", e);
		} finally {
			dbManager.close(rs);
			dbManager.close(stmt);
			dbManager.close(conn);
		}
		
		if (body.length() > 0) {
			String message = getMessagePrefix().append(":").append(body).toString();
			
			logger.warn(message);
			
			if (smsAlarm) {
				smsNotifier.sendMessage(message);
			}
		}
	}
	
	private StringBuffer getMessagePrefix() {
		StringBuffer prefix = new StringBuffer("HHTInterfaces");
		try {
			String hostName = InetAddress.getLocalHost().getHostName();
			
			prefix.append("[").append(hostName).append("]");
		} catch (UnknownHostException e) {
			logger.error(e);
		}
		
		return prefix;
	}
	
}