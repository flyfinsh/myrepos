package com.sf.hht.interfaces.task.monitor;

import com.sf.hht.interfaces.skeleton.resource.DBManager;

public class TableUnit {

	private DBManager dbManager;
	private String table;
	private int sendStatus = -1;
	private int maxSize;
	private String dbName;
	
	public DBManager getDbManager() {
		return dbManager;
	}
	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}
	public String getTable() {
		return table;
	}
	public void setTable(String table) {
		this.table = table;
	}
	public int getSendStatus() {
		return sendStatus;
	}
	public void setSendStatus(int sendStatus) {
		this.sendStatus = sendStatus;
	}
	public int getMaxSize() {
		return maxSize;
	}
	public void setMaxSize(int maxSize) {
		this.maxSize = maxSize;
	}
	public String getDbName() {
		return dbName;
	}
	public void setDbName(String dbName) {
		this.dbName = dbName;
	}
}