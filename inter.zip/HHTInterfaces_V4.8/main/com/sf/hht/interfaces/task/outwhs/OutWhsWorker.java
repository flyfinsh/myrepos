package com.sf.hht.interfaces.task.outwhs;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;

import com.sf.framework.integration.ISGConverter;
import com.sf.framework.integration.SGConverterException;
import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.log.ErrorDataLog;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.resource.MQManager;
import com.sf.integration.bar.dto.HHTBarTO;

public class OutWhsWorker extends TaskWorker {

	private static final Logger logger = Logger.getLogger(OutWhsWorker.class);

	private static final String sql_insert = "insert into tbilltrace_bak (xh,bno,zno,opcode,baropr,opr,bardate,bartime,jmstr,sn,pc,money) values ('exp5->hht_' || s_getxh.nextval,?,?,?,?,?,?,?,?,?,?,?)";
	private static final String sql_insert_waybillcod = "insert into waybillcod(id,empid,bno,money,type) values (SEQ_WAYBILLCOD_ID.nextval,?,?,?,?)";
	private static final String SQL_CHECK_COD_EXIST = "select count(1) from waybillcod t where t.bno = ? and empid = ? and t.instdate >= trunc(sysdate) and t.instdate < trunc(sysdate+1)";
	private static final String SQL_INSERT_TBILLTRACE_640 = "INSERT INTO TBILLTRACE_640(ID,EMPID,BNO,BARTIME) VALUES (SEQ_TBILLTRACE_640_ID.NEXTVAL,?,?,?)";
	private static final String SQL_CHECK_TBILLTRACE_640_EXIST = "select count(1) from waybillcod t where t.bno = ? and empid = ? and t.instdate >= trunc(sysdate) and t.instdate < trunc(sysdate+1)";
	
	private DBManager dbManager;
	private MQManager mqManager;
	private Destination queue;
	private ISGConverter sgConverter;
	private long receiveTimeout;

	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}
	public void setMqManager(MQManager mqManager) {
		this.mqManager = mqManager;
	}
	public void setQueue(Destination queue) {
		this.queue = queue;
	}
	public void setSgConverter(ISGConverter sgConverter) {
		this.sgConverter = sgConverter;
	}
	public void setReceiveTimeout(long receiveTimeout) {
		this.receiveTimeout = receiveTimeout;
	}

	@Override
	public void preprocess() {
		//do nothing
	}
	
	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("OutWhsWorker[").append(Thread.currentThread().getId()).append("]");
		
		logger.info(logPrefix.toString() + " start");

		while (running) {
			try {
				receive(logPrefix.toString());
			
				makeWait(task.getPeriod());
			} catch (Exception e) {
				logger.error("Exception Occured", e);
			}
		}
		
		logger.info(logPrefix + " end");
	}

	private void receive(String logPrefix) {
		logger.info(logPrefix + " is running");
		
		javax.jms.Connection mqConn = null;
		Session session = null;
		MessageConsumer consumer = null;
		
		try {
			mqConn = mqManager.getConnection();
			mqConn.start();
			
			session = mqConn.createSession(false, Session.AUTO_ACKNOWLEDGE);
			consumer = session.createConsumer(queue);

			try {
				String message = receive(consumer);
				
				while (message != null) {
					if (logger.isDebugEnabled()) {
						logger.debug(logPrefix + " received OutWhs:" + message);
					}
					
					HHTBarTO to = null;
					try {
						to = (HHTBarTO)sgConverter.fromXML(message, HHTBarTO.class);
					} catch (SGConverterException ce) {
						//数据异常单独记录日志文件
						ErrorDataLog.error("Error OutWhs[" + message + "]");
						ce.printStackTrace();
					}
					
					if (validate(to)) {
						try {
							insertRecord(to);
						} catch (SQLException se) {
							logger.error("Failed to insert OutWhs into tbilltrace_bak", se);
							ErrorDataLog.error("Fail OutWhs[" + message + "]");
							se.printStackTrace();
							//exit loop
							break;
						}
					} else {
						ErrorDataLog.error("Invalid OutWhs[" + message + "]");
					}

					message = receive(consumer);
				}
			} catch (Exception e) {
				logger.error("Exception Occured when receiving OutWhs", e);
			}
		} catch (Exception e) {
			logger.error("Exception Occured when receiving OutWhs", e);
		} finally {
			mqManager.close(consumer);
			mqManager.close(session);
			mqManager.close(mqConn);
		}
	}
	
	private String receive(MessageConsumer consumer) throws JMSException {
		Message message = consumer.receive(receiveTimeout);
		
		if (message instanceof TextMessage) {
			return ((TextMessage) message).getText();
		} else {
			return null;
		}
	}
	
	private boolean validate(HHTBarTO to){
		if (to == null) {
			return false;
		}
		//巴枪操作码
		if( to.getOpCode() != null && to.getOpCode().length() > 4 ){
			return false;
		}
		//运单号
		if( to.getBillCode() != null && to.getBillCode().length() > 12 ){
			return false;
		}
		//网络网点号
		if( to.getZoneCode() != null && to.getZoneCode().length() > 12){
			return false;
		}
		//操作员
		if(to.getBarOpr() != null && to.getBarOpr().length() > 16){
			return false;
		}
		//收派员
		if(to.getCourier() != null && to.getCourier().length() > 16){
			return false;
		}
		//加密串
		if(to.getEncryptString() != null && to.getEncryptString().length() > 16){
			return false;
		}
		//设备号
//		if(to.getBarSn() != null && to.getBarSn().length() > 16){
//			return false;
//		}
		//批次
		if(to.getBatch() != null && to.getBatch().length() > 20){
			return false;
		}
		//COD代收货款金额
		if(to.getAccountantCode() != null && to.getAccountantCode().length() > 10){
			return false;
		}
		
		return true;
	}
	
	private void insertRecord(HHTBarTO to) throws SQLException{
		java.sql.Connection conn = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt2 = null;
		PreparedStatement pstmt3 = null;

		try {
			conn = dbManager.getConnection();
			conn.setAutoCommit(false);
			
			//插入tbilltrace_bak表
			pstmt = conn.prepareStatement(sql_insert);
			pstmt.setString(1, to.getBillCode());// 运单号
			pstmt.setString(2, to.getZoneCode());// 网络网点号
			pstmt.setString(3, to.getOpCode());// 巴枪操作码
			pstmt.setString(4, to.getBarOpr());// 操作员
			pstmt.setString(5, to.getCourier());// 收派员
			if (to.getBarScanTm() != null) {// 扫描时间
				pstmt.setDate(6, new java.sql.Date(to.getBarScanTm().getTime()));
				pstmt.setTimestamp(7, new java.sql.Timestamp(to.getBarScanTm().getTime()));
			} else {
				pstmt.setDate(6, new java.sql.Date(System.currentTimeMillis()));
				pstmt.setTimestamp(7, new java.sql.Timestamp(System.currentTimeMillis()));
			}
			pstmt.setString(8, to.getEncryptString());// 加密串
			pstmt.setString(9, to.getBarSn());// 设备号
			pstmt.setString(10, to.getBatch());// 批次
			pstmt.setString(11, to.getAccountantCode());//COD代收货款金额
			pstmt.executeUpdate();
			
			// 如果COD代收货款金额有值，则插入waybillcod表（COD代收货款，每日上缴业务）
			if (to.getAccountantCode() != null && to.getAccountantCode().length() > 0) {
				// 如果运单当天COD代收货款记录不存在，则将COD代收货款记录参入到waybillcode表
				if (!checkWaybillExist(conn, to,SQL_CHECK_COD_EXIST)) {
					pstmt2 = conn.prepareStatement(sql_insert_waybillcod);
					pstmt2.setString(1, to.getCourier());// 收派员
					pstmt2.setString(2, to.getBillCode());// 运单号
					pstmt2.setString(3, to.getAccountantCode()); // COD代收货款金额
					
					// 短信支付标识
					String smsPay = to.getOtherInfo();
					if (smsPay != null && "1".equals(smsPay.trim())) {
						pstmt2.setString(4, "1");	// 短信支付
					}else {
						pstmt2.setString(4, "0");	// COD
					}
					
					pstmt2.executeUpdate();
				}
			}
			
			//640二程接驳出仓数据
			if("640".equals(to.getOpCode())) {
				if(!checkWaybillExist(conn, to, SQL_CHECK_TBILLTRACE_640_EXIST)) {
					pstmt3 = conn.prepareStatement(SQL_INSERT_TBILLTRACE_640);
					pstmt3.setString(1, to.getCourier());
					pstmt3.setString(2, to.getBillCode());
					pstmt3.setTimestamp(3, new Timestamp(to.getBarScanTm().getTime()));
					pstmt3.executeUpdate();
				}
			}
			
			conn.commit();
			conn.setAutoCommit(true);
			
		} catch (SQLException e) {
			try {
				if (conn != null) {
					conn.rollback();
				}
			} catch (SQLException e1) {
				logger.error(e1);
			}
			throw e;
		} finally {
			dbManager.close(pstmt3);
			dbManager.close(pstmt2);
			dbManager.close(pstmt);
			dbManager.close(conn);
		}
	}
	
	/**
	 * 根据运单号检查当天是否存在该运单
	 * Oct 30, 2012
	 * @param conn
	 * @param to
	 * @return
	 * @throws SQLException
	 */
	private boolean checkWaybillExist(Connection conn, HHTBarTO to,String checkSQL) throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		boolean isExist = false;
		
		try {
			pstmt = conn.prepareStatement(checkSQL);
				
			pstmt.setString(1, to.getBillCode());
			pstmt.setString(2, to.getCourier());
			
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				int count = rs.getInt(1);
				
				if (count > 0) {
					isExist = true;
				}
			}
		} finally {
			dbManager.close(rs);
			dbManager.close(pstmt);
		}
		
		return isExist;
	}
	
}