package com.sf.hht.interfaces.task.pickup;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;

import com.sf.framework.integration.ISGConverter;
import com.sf.framework.integration.SGConverterException;
import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.log.ErrorDataLog;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.resource.MQManager;
import com.sf.integration.bar.dto.BarRecordTempTO;;

public class PickUpWorker extends TaskWorker {

	private static final Logger logger = Logger.getLogger(PickUpWorker.class);

	private static final String sql_insert = "insert into tbilltrace_bak (xh,bno,zno,opcode,baropr,opr,bardate,bartime,jmstr,sn,pc,why) values ('exp5->hht_' || s_getxh.nextval,?,?,?,?,?,?,?,?,?,?,?)";
	
	private DBManager dbManager;
	private MQManager mqManager;
	private Destination queue;
	private ISGConverter sgConverter;
	private long receiveTimeout;

	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}
	public void setMqManager(MQManager mqManager) {
		this.mqManager = mqManager;
	}
	public void setQueue(Destination queue) {
		this.queue = queue;
	}
	public void setSgConverter(ISGConverter sgConverter) {
		this.sgConverter = sgConverter;
	}
	public void setReceiveTimeout(long receiveTimeout) {
		this.receiveTimeout = receiveTimeout;
	}

	@Override
	public void preprocess() {
		//do nothing
	}
	
	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("PickUpWorker[").append(Thread.currentThread().getId()).append("]");
		
		logger.info(logPrefix.toString() + " start");

		while (running) {
			try {
				receive(logPrefix.toString());
			
				makeWait(task.getPeriod());
			} catch (Exception e) {
				logger.error("Exception Occured", e);
			}
		}
		
		logger.info(logPrefix + " end");
	}

	private void receive(String logPrefix) {
		logger.info(logPrefix + " is running");
		
		javax.jms.Connection mqConn = null;
		Session session = null;
		MessageConsumer consumer = null;
		
		try {
			mqConn = mqManager.getConnection();
			mqConn.start();
			
			session = mqConn.createSession(false, Session.AUTO_ACKNOWLEDGE);
			consumer = session.createConsumer(queue);

			try {
				String message = receive(consumer);
				
				while (message != null) {
					if (logger.isDebugEnabled()) {
						logger.debug(logPrefix + " received DT900PickUp:" + message);
					}
					
					BarRecordTempTO to = null;
					try {
						to = (BarRecordTempTO)sgConverter.fromXML(message, BarRecordTempTO.class);
					} catch (SGConverterException ce) {
						//数据异常单独记录日志文件
						ErrorDataLog.error("Error DT900PickUp[" + message + "]");
					}
					
					if (validate(to)) {
						try {
							insertRecord(to);
						} catch (SQLException se) {
							logger.error("Failed to insert DT900PickUp into tbilltrace_bak", se);
							ErrorDataLog.error("Fail DT900PickUp[" + message + "]");
							
							//exit loop
							break;
						}
					} else {
						ErrorDataLog.error("Invalid DT900PickUp[" + message + "]");
					}

					message = receive(consumer);
				}
			} catch (Exception e) {
				logger.error("Exception Occured when receiving DT900PickUp", e);
			}
		} catch (Exception e) {
			logger.error("Exception Occured when receiving DT900PickUp", e);
		} finally {
			mqManager.close(consumer);
			mqManager.close(session);
			mqManager.close(mqConn);
		}
	}
	
	private String receive(MessageConsumer consumer) throws JMSException {
		Message message = consumer.receive(receiveTimeout);
		
		if (message instanceof TextMessage) {
			return ((TextMessage) message).getText();
		} else {
			return null;
		}
	}
	
	private boolean validate(BarRecordTempTO to){
		if (to == null) {
			return false;
		}
		//巴枪操作码
		if( to.getOpCode() != null && to.getOpCode().length() > 2 ){
			return false;
		}
		//运单号
		if( to.getWaybillNo() != null && to.getWaybillNo().length() > 12 ){
			return false;
		}
		//网络网点号
		if( to.getZoneCode() != null && to.getZoneCode().length() > 12){
			return false;
		}
		//操作员
		if(to.getBarOprCode() != null && to.getBarOprCode().length() > 16){
			return false;
		}
		//收派员
		if(to.getCourierCode() != null && to.getCourierCode().length() > 16){
			return false;
		}
		//加密串
		if(to.getEncryptString() != null && to.getEncryptString().length() > 16){
			return false;
		}
		//设备号
//		if(to.getBarSn() != null && to.getBarSn().length() > 16){
//			return false;
//		}
		//批次
		if(to.getBatchCode() != null && to.getBatchCode().length() > 20){
			return false;
		}
		//原因代码
		if(to.getStayWhyCode() != null){
			//字段超4位
			if(to.getStayWhyCode().length() > 4){
				return false;
			}
			//是否为数字
			try{
			   Integer.valueOf(to.getStayWhyCode());
			}catch( NumberFormatException e){
				e.printStackTrace();
				return false;
			}
		}
		
		return true;
	}
	
	private void insertRecord(BarRecordTempTO to) throws SQLException {
		java.sql.Connection conn = null;
		PreparedStatement pstmt = null;
		int why = -1;
		
		try {
			conn = dbManager.getConnection();
			pstmt = conn.prepareStatement(sql_insert);
			
			pstmt.setString(1, to.getWaybillNo());// 运单号
			pstmt.setString(2, to.getZoneCode());// 网络网点号
			pstmt.setString(3, to.getOpCode());// 巴枪操作码
			pstmt.setString(4, to.getBarOprCode());// 操作员
			pstmt.setString(5, to.getCourierCode());// 收派员
			if (to.getBarScanTm() != null) {// 扫描时间
				pstmt.setDate(6, new java.sql.Date(to.getBarScanTm().getTime()));
				pstmt.setTimestamp(7, new java.sql.Timestamp(to.getBarScanTm().getTime()));
			} else {
				pstmt.setDate(6, new java.sql.Date(System.currentTimeMillis()));
				pstmt.setTimestamp(7, new java.sql.Timestamp(System.currentTimeMillis()));
			}
			pstmt.setString(8, to.getEncryptString());// 加密串
			pstmt.setString(9, to.getBarSn());// 设备号
			pstmt.setString(10, to.getBatchCode());// 批次
			pstmt.setString(11, to.getStayWhyCode()); //原因代码

			
			pstmt.executeUpdate();
		} finally {
			dbManager.close(pstmt);
			dbManager.close(conn);
		}
	}

}