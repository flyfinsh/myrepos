package com.sf.hht.interfaces.task.postcode;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;

import com.sf.framework.integration.ISGConverter;
import com.sf.framework.integration.SGConverterException;
import com.sf.framework.integration.converter.JiBXConverter;
import com.sf.framework.integration.converter.XStreamConverter;
import com.sf.framework.integration.dto.SGTransferObject;
import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.log.ErrorDataLog;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.resource.MQManager;
import com.sf.integration.basedata.dto.BaseTO;


public class PostcodeWorker extends TaskWorker {

	private static final Logger LOG = Logger.getLogger(PostcodeWorker.class);
	
	// 发送MQ SQL
	private static final String SQL_LOAD_RECORDS = "select t.id, "
       + "t.postcode_id, "
       + "t.des_country_code, "
       + "t.des_city_code, "
       + "t.postcode_begin, "
       + "t.postcode_end, "
       + "t.coverage_area, "
       + "t.additional_working_day, "
       + "t.remote_area_charge, "
       + "t.remark, "
       + "t.country, "
       + "t.oprflag "
  + "from pd_abroad_postcode_cu t "
  + "where rownum <= ?"
  + "order by t.id asc";
	
	// 更新发送状态值
	private static final String SQL_DEL_SENDED_RECORD = "delete from pd_abroad_postcode_cu t where t.id = ?";
	
	// 数据库连接管理
	private DBManager dbManager;
	// 队列管理器
	private MQManager mqManager;
	// Asura发送队列
	private Destination auscmsQueue;
	// Css发送队列
	private Destination cssQueue;
	// MEM发送队列
	private Destination memQueue;
	// 转换器
	private ISGConverter sgConverter;
	
	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}

	public void setMqManager(MQManager mqManager) {
		this.mqManager = mqManager;
	}

	public void setAuscmsQueue(Destination auscmsQueue) {
		this.auscmsQueue = auscmsQueue;
	}

	public void setCssQueue(Destination cssQueue) {
		this.cssQueue = cssQueue;
	}

	public void setMemQueue(Destination memQueue) {
		this.memQueue = memQueue;
	}

	public void setSgConverter(ISGConverter sgConverter) {
		this.sgConverter = sgConverter;
	}
	
	@Override
	public void preprocess() {
		
	}

	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("HhtPostcodeWorker[").append(Thread.currentThread().getId()).append("]");
		LOG.info(logPrefix.toString() + " start");
		
		while(running){
			try{
				int handleRows = handleRecords(logPrefix.toString());
				if(handleRows < task.getRecordSize()){
					makeWait(task.getPeriod());
				}
			}catch(Exception e){
				LOG.error("Exception Occured", e);
			}
		}
		
		LOG.info(logPrefix.toString() + " end");
	}
	
	/**
	 * 加载数据并且将数据发送到队列
	 * Nov 17, 2011
	 * @param logPrefix
	 * @return
	 */
	private int handleRecords(String logPrefix){
		// 查询结果记录集
		List<HhtPostcodeTO> records = new ArrayList<HhtPostcodeTO>();
		
		javax.jms.Connection mqConn = null;
		Session session = null;
		// Asura 队列消息生产者
		MessageProducer asucmsProducer = null;
		// Css 队列消息生产者
		MessageProducer cssProducer = null;
		// Mem 队列消息生产者
		MessageProducer memProducer = null;
		
		java.sql.Connection dbConn = null;
		
		try{
			// 获取数据库连接
			dbConn = dbManager.getConnection();
			dbConn.setAutoCommit(false);
			
			// 加载数据到集合
			loadRecords(dbConn, records);
			int loadSize = records.size();
			
			if(loadSize > 0){
				// 获取队列管理器连接
				mqConn = mqManager.getConnection();
				// 创建MQ Session
				session = mqConn.createSession(false, Session.AUTO_ACKNOWLEDGE);
				// 创建消息文本对象
				TextMessage textMessage = session.createTextMessage();
				
				// 消息生产者集合
				List<MessageProducer> producerList = new ArrayList<MessageProducer>();
				if(null != auscmsQueue){
					// 创建Asura队列消息生产者
					asucmsProducer = session.createProducer(auscmsQueue);
					asucmsProducer.setDeliveryMode(DeliveryMode.PERSISTENT);
					producerList.add(asucmsProducer);
				}
				if(null != cssQueue){
					// 创建Css队列消息生产者
					cssProducer = session.createProducer(cssQueue);
					cssProducer.setDeliveryMode(DeliveryMode.PERSISTENT);
					producerList.add(cssProducer);
				}
				if(null != memQueue){
					// 创建Css队列消息生产者
					memProducer = session.createProducer(memQueue);
					memProducer.setDeliveryMode(DeliveryMode.PERSISTENT);
					producerList.add(memProducer);
				}
				
				for(HhtPostcodeTO to : records){
					Long id = to.getId();
					try{
						// 发送消息到指定队列
						sendToMQ(producerList, textMessage, to);
						// 删除数据操作记录
						delSendedRecord(dbConn, id);
					}catch(SGConverterException ce){
						// 数据异常单独记录日志文件
						ErrorDataLog.error("Convert Object:HhtPostcode to XML Exception, Id->[" + id + "] ");
						ce.printStackTrace();
					}catch(Exception e){
						LOG.error("Failed to send HhtPostcode to MQ!", e);
						continue;
					}
					
					if(LOG.isDebugEnabled()){
						LOG.debug("Send HhtPostcode to MQ successfully! id--"+id);
					}
				}
				
				LOG.info(logPrefix + "--Handled "+ loadSize + " record(s)");
			}
			
			dbConn.commit();
			dbConn.setAutoCommit(true);
			
			return loadSize;
		}catch(Exception e){
			LOG.error("Exception Occured when sending hhtpostcode", e);
			try{
				if(dbConn != null){
					dbConn.rollback();
				}
			}catch(SQLException e1){
				LOG.error(e1);
			}
			e.printStackTrace();
		}finally{
			mqManager.close(asucmsProducer);
			mqManager.close(cssProducer);
			mqManager.close(memProducer);
			mqManager.close(session);
			mqManager.close(mqConn);
			
			dbManager.close(dbConn);
		}
		
		return -1;
	}
	
	/**
	 * 删除已经发送数据
	 * Nov 18, 2011
	 * @param conn
	 * @param id
	 * @throws SQLException
	 */
	private void delSendedRecord(java.sql.Connection conn , Long id) throws SQLException{
		PreparedStatement pstmt = conn.prepareStatement(SQL_DEL_SENDED_RECORD);
		pstmt.setLong(1, id);
		pstmt.executeUpdate();
		dbManager.close(pstmt);
	}
	
	/**
	 * 分批加载数据放入到集合
	 * Nov 17, 2011
	 * @param conn
	 * @param records
	 * @throws SQLException 
	 */
	private void loadRecords(java.sql.Connection conn, List<HhtPostcodeTO> records) throws SQLException{
		PreparedStatement pstmt = conn.prepareStatement(SQL_LOAD_RECORDS);
		pstmt.setLong(1, task.getRecordSize());
		ResultSet rs = pstmt.executeQuery();
		HhtPostcodeTO to = null;
		while(rs.next()){
			to = new HhtPostcodeTO();
			to.setAdditionalWorkingDay(rs.getString("additional_working_day"));	// 加工作日
			to.setCountry(rs.getString("country"));	// 语言
			to.setCoverageArea(rs.getString("coverage_area"));	// 收送范围说明
			to.setDesCityCode(rs.getString("des_city_code"));	// 目的地城市代码
			to.setDesCountryCode(rs.getString("des_country_code"));	// 目的地国家代码
			to.setId(rs.getLong("id"));	// 主键ID
			to.setOprFlag(rs.getString("oprflag"));	// 操作类型：I:新增,U:修改,D:删除
			to.setPostcodeBegin(rs.getString("postcode_begin"));	// 起始邮编
			to.setPostcodeEnd(rs.getString("postcode_end"));	// 结束邮编
			to.setPostcodeId(rs.getLong("postcode_id"));	// 邮编ID
			to.setRemark(rs.getString("remark"));	// 备注
			to.setRemoteAreaCharge(rs.getString("remote_area_charge"));	// 加偏远地区附加费
			records.add(to);
		}
		dbManager.close(rs);
		dbManager.close(pstmt);
	}
	
	/**
	 * 发送消息到指定队列
	 * Nov 22, 2011
	 * @param producerList
	 * @param msg
	 * @param to
	 * @throws JMSException
	 */
	private void sendToMQ(List<MessageProducer> producerList, TextMessage msg, SGTransferObject to) throws JMSException{
		// 对象转换成xml
		String xml = sgConverter.toXML(to);
		msg.clearBody();
		msg.setText(xml);
		
		if(null != producerList && producerList.size() > 0){
			Iterator<MessageProducer> it = producerList.iterator();
			while(it.hasNext()){
				MessageProducer producer = it.next();
				producer.send(msg);
			}
		}
	}
	
	public static void main(String[] args) {
		String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><hht_postcode_to>  <base_to>    <sg_transfer_object>      <obj_name>HhtPostcodeTO</obj_name>    </sg_transfer_object>  </base_to>  <postcodeId>789123</postcodeId>  <desCountryCode>CN</desCountryCode>  <desCityCode>755</desCityCode>  <postcodeBegin>518000</postcodeBegin>  <postcodeEnd>518000</postcodeEnd>  <country>CN</country></hht_postcode_to>";
		JiBXConverter jibx = new JiBXConverter();
		HhtPostcodeTO to = null;
		to = (HhtPostcodeTO)jibx.fromXML(xml, HhtPostcodeTO.class);
		System.out.println("Country : "+to.getCountry());
		
//		BaseTO to = (BaseTO)jibx.fromXML(xml, BaseTO.class);
//		System.out.println(to.getCountry());
		
		/*HhtPostcodeTO to = new HhtPostcodeTO();
		to.setPostcodeId(123456L);
		to.setPostcodeId(789123L);
		to.setDesCountryCode("CN");
		to.setDesCityCode("755");
		to.setPostcodeBegin(518000L);
		to.setPostcodeEnd(518000L);
		to.setCountry("CN");
		
		String xml_1 = jibx.toXML(to);
		System.out.println(xmli_1);*/
		
	}
}
