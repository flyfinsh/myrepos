package com.sf.hht.interfaces.task.range;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import org.apache.log4j.Logger;
import com.sf.framework.integration.ISGConverter;
import com.sf.framework.integration.SGConverterException;
import com.sf.framework.integration.dto.SGTransferObject;
import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.log.ErrorDataLog;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.resource.MQManager;
import com.sf.integration.hht.dto.PdProdGroupCuTO;
import com.sf.integration.hht.dto.PdTreeDetailCuTO;


public class RangeWorker extends TaskWorker{
	
    private static final Logger logger =Logger.getLogger(RangeWorker.class);
    private static final String sql_clear_dirty_group = "update pd_prod_group_cu set send_status = 0 where send_status = 1 ";
    private static final String sql_before_load_group = "update pd_prod_group_cu set send_thread = ? , send_status = 1  where send_status = 0  and rownum <= ? ";
    private static final String sql_load_record_group = "select id,group_id,des,product_code,apart_flight,begin_date,oprflag from pd_prod_group_cu where send_thread =? and send_status = 1 and rownum <= ? order by id asc";
    private static final String sql_after_delete_group = "delete pd_prod_group_cu where id =? ";
    	
    private static final String sql_clear_dirty_tree = "update pd_tree_detail_cu set send_status = 0 where send_status = 1 ";
    private static final String sql_before_load_tree = "update pd_tree_detail_cu set send_thread = ? , send_status = 1 where send_status = 0 and rownum <=? ";
    private static final String sql_load_record_tree = "select id,tree_id,address,pid,status,remark,addresstag,begin_date,oprflag from pd_tree_detail_cu where  send_thread =? and send_status = 1 and rownum <=? order by id asc";
    private static final String sql_after_delete_tree = "delete pd_tree_detail_cu where id =? ";
  
	private DBManager dbManager;
	private MQManager mqManager;
	private ISGConverter sgConverter;
	private Destination cssQueue;
	
	//预处理
	@Override
	public  void preprocess(){
		clearDirtyRecords();
		
	}
	
	@Override
	public  void execute(){
		StringBuffer logPrefix =new StringBuffer();
		logPrefix.append("RangeWorker[").append(Thread.currentThread().getId()).append("]");
	   
		logger.info(logPrefix.toString()+ "start");
		while(running){
			try{
				int handleRows = handleRecords(logPrefix.toString());
				if(handleRows <= 0){
					makeWait(task.getPeriod());
				}
			}catch(Exception e){
				logger.error("Exception Occured", e);
			}

			
		}
		logger.info(logPrefix.toString()+ "end");
		
		
		
	}
	
	//发送数据并返回发送行数
	public int handleRecords(String logPrefix){
		
		List<PdProdGroupCuTO>  groupList = new ArrayList<PdProdGroupCuTO>();
		List<PdTreeDetailCuTO> treeList = new ArrayList<PdTreeDetailCuTO>();
		
		java.sql.Connection dbConn = null;
		javax.jms.Connection mqConn = null;
		Session session = null;
		MessageProducer cssProducer = null; //CSS队列
		
		try {
			dbConn = dbManager.getConnection();
			beforeLoadRecords(dbConn);//预处理加载数据
			dbConn.setAutoCommit(false);
			loadRecords(dbConn ,groupList,treeList); //加载数据
			
			int groupLoadSize = groupList.size();
			int treeLoadSize = treeList.size();
			
			mqConn = mqManager.getConnection();
			session = mqConn.createSession(false, Session.AUTO_ACKNOWLEDGE);
			TextMessage textMessage = session.createTextMessage();
			
			List<MessageProducer> produclist = new ArrayList<MessageProducer>();
			if(cssQueue!=null){
				cssProducer = session.createProducer(cssQueue);
				cssProducer.setDeliveryMode(DeliveryMode.PERSISTENT);
				produclist.add(cssProducer);
			}
			
			//发送主表数据
			if(groupLoadSize > 0){
				for (PdProdGroupCuTO  to : groupList) {
					long  id = to.getId() ;
					try {
						sendToMQ(produclist, textMessage, to);
					} catch (SGConverterException ce) {
						//数据异常单独记录日志文件,然后更新数据库记录状态
						ErrorDataLog.error("range of pd_prod_group_cu[" + id + "]");
					} catch (Exception e) {
						//其它异常则不更新数据库记录状态,等待下次继续发送
						logger.error("Failed to send range of pd_prod_group_cu to MQ!", e);
						
						continue;
					}
					
					if (logger.isDebugEnabled()) {
						logger.debug("Sended Range of pd_prod_group_cu to MQ successfully! id--" + id);
					}
					//删除发送主表数据
					deleteSendData(dbConn, sql_after_delete_group, id);
				}
				logger.info(logPrefix + "--Handled pd_prod_group_cu " + groupLoadSize + " record(s)");
			}
			
			//发送明细表数据
			if(treeLoadSize > 0){
				for (PdTreeDetailCuTO  to : treeList) {
					long  id = to.getId() ;
					try {
						sendToMQ(produclist, textMessage, to);
					} catch (SGConverterException ce) {
						//数据异常单独记录日志文件,然后更新数据库记录状态
						ErrorDataLog.error("range of pd_tree_detail_cu[" + id + "]");
					} catch (Exception e) {
						//其它异常则不更新数据库记录状态,等待下次继续发送
						logger.error("Failed to send range of pd_tree_detail_cu to MQ!", e);
						
						continue;
					}
					
					if (logger.isDebugEnabled()) {
						logger.debug("Sended Range of pd_tree_detail_cu to MQ successfully! id--" + id);
					}
                    //删除已发送明细表数据
					deleteSendData(dbConn, sql_after_delete_tree, id);
				}
				logger.info(logPrefix + "--Handled pd_tree_detail_cu " + treeLoadSize + " record(s)");
			}
			
			dbConn.commit();
			dbConn.setAutoCommit(true);
			
			return (groupLoadSize+treeLoadSize);
				
		} catch (Exception e) {
			logger.error("Exception Occured when sending Range", e);
			try{
				if(dbConn!=null){
					dbConn.rollback();
				}
			}catch(SQLException e1){
				logger.error(e1);
			}
		}finally{
			if(cssQueue != null) {mqManager.close(cssProducer);}
			mqManager.close(session);
			mqManager.close(mqConn);
			
			dbManager.close(dbConn);
		}
		
		return -1 ;
		
	}
	
	//发送数据到MQ
	private void sendToMQ(List<MessageProducer> produclist, TextMessage msg, SGTransferObject to) 
	throws SGConverterException, JMSException {
		String xml = sgConverter.toXML(to);
		msg.clearBody();
		msg.setText(xml);
		
		if(produclist != null && produclist.size() > 0){
			Iterator it =produclist.iterator();
			while(it.hasNext()){
				MessageProducer messageProducer = (MessageProducer)it.next();
				messageProducer.send(msg);
			  }
			}
		}
	
	//预处理需要加载的数据
	public void beforeLoadRecords(Connection dbConn)throws SQLException {
		PreparedStatement pstmt_group = dbConn.prepareStatement(sql_before_load_group);
		pstmt_group.setLong(1,Thread.currentThread().getId());
		pstmt_group.setLong(2, task.getRecordSize());
		pstmt_group.executeUpdate();
		dbManager.close(pstmt_group);
		
		PreparedStatement pstmt_tree = dbConn.prepareStatement(sql_before_load_tree);
		pstmt_tree.setLong(1,Thread.currentThread().getId());
		pstmt_tree.setLong(2, task.getRecordSize());
		pstmt_tree.executeUpdate();
		dbManager.close(pstmt_tree);
		
	}
	
	//加载传输数据
	public void loadRecords(Connection dbConn , List<PdProdGroupCuTO> groupList, List<PdTreeDetailCuTO> treeList)throws SQLException{
		//加载父根数据
		PreparedStatement pstmt_group = dbConn.prepareStatement(sql_load_record_group);
		pstmt_group.setLong(1, Thread.currentThread().getId());
		pstmt_group.setLong(2, task.getRecordSize());
		
		ResultSet rs = pstmt_group.executeQuery();
		PdProdGroupCuTO groupTo ; 
		while(rs.next()){
			groupTo = new PdProdGroupCuTO();
			
			groupTo.setId(rs.getLong("id")); //序列号
			groupTo.setGroupId(rs.getLong("group_id")); //根节点ID
			groupTo.setDes(rs.getString("des"));//目的地城市代码
			groupTo.setProductCode(rs.getString("product_code"));//产品类型
			groupTo.setApartFlight(rs.getString("apart_flight"));//散货班次
			groupTo.setBeginDate(rs.getDate("begin_date"));//生效日期
			groupTo.setOprFlag(rs.getString("oprflag"));//操作类别
			
			groupList.add(groupTo);
			
		}
		logger.info("pd_group data load successful");
		dbManager.close(rs);
		dbManager.close(pstmt_group);
		
		//加载明细数据
		PreparedStatement pstmt_tree = dbConn.prepareStatement(sql_load_record_tree);
		pstmt_tree.setLong(1, Thread.currentThread().getId());
		pstmt_tree.setLong(2, task.getRecordSize());
		
		ResultSet rs_tree = pstmt_tree.executeQuery();
		PdTreeDetailCuTO treeTo;
		while(rs_tree.next()){
			treeTo = new PdTreeDetailCuTO();
			treeTo.setId(rs_tree.getLong("id"));//序列号
			treeTo.setTreeId(rs_tree.getLong("tree_id"));//明细id
			treeTo.setAddress(rs_tree.getString("address"));//地址
			treeTo.setPid(rs_tree.getLong("pid"));//父ID
			treeTo.setStatus(rs_tree.getInt("status"));//节点状态
			treeTo.setRemark(rs_tree.getString("remark"));//备注
			treeTo.setAddressTag(rs_tree.getString("addresstag"));//地址标识
			treeTo.setBeginDate(rs_tree.getDate("begin_date"));//生效日期
			treeTo.setOprFlag(rs_tree.getString("oprflag"));//操作类别
			
			treeList.add(treeTo);
		}
		logger.info("pd_tree_detail data load successful");
		dbManager.close(rs_tree);
		dbManager.close(pstmt_tree);
		
		
	}
	
	//清除脏数据
	public void clearDirtyRecords(){
		java.sql.Connection dbConn = null;
		PreparedStatement pstmt_group = null;
		PreparedStatement pstmt_tree = null;
		
		try {
			dbConn = dbManager.getConnection();
			pstmt_group = dbConn.prepareStatement(sql_clear_dirty_group);
			pstmt_tree = dbConn.prepareStatement(sql_clear_dirty_tree);
			
			pstmt_group.executeUpdate();
			pstmt_tree.executeUpdate();
			logger.info("Cleared dirty records in range  successfully");
			
		} catch (SQLException e) {
			logger.error("Exception Occured when clearing dirty records in range", e);
		}finally {
			dbManager.close(pstmt_group);
			dbManager.close(pstmt_tree);
			dbManager.close(dbConn);
		}
	}
	
	
	//删除已发送的数据
	public void deleteSendData(java.sql.Connection dbConn ,String sql , long id)throws SQLException{
		PreparedStatement pstmt = null;
		
		pstmt = dbConn.prepareStatement(sql);
		pstmt.setLong(1, id);
		pstmt.executeUpdate();
		
		dbManager.close(pstmt);
		
	}


	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}

	public void setMqManager(MQManager mqManager) {
		this.mqManager = mqManager;
	}
	
	public void setCssQueue(Destination cssQueue) {
		this.cssQueue = cssQueue;
	}

	public void setSgConverter(ISGConverter sgConverter) {
		this.sgConverter = sgConverter;
	}
	
}
