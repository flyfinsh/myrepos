package com.sf.hht.interfaces.task.rms;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.util.CommonHelper;
import com.sf.hht.interfaces.task.rms.to.RmsDataTO;
import com.sf.hht.interfaces.task.rms.ws.IRMSInterfaceService;
import com.sf.hht.interfaces.task.rms.ws.IRMSInterfaceServiceLocator;
import com.sf.hht.interfaces.task.rms.ws.RmsData;

public class RmsDataWorker extends TaskWorker{
	
	private static final Logger LOG = Logger.getLogger(RmsDataWorker.class);
	
	private static final StringBuffer SQL_BEFORE_LOAD = new StringBuffer();
	private static final StringBuffer SQL_LOAD_RECORD = new StringBuffer();
	private static final StringBuffer SQL_SEND_SUCCESS = new StringBuffer();
	// 数据接管
	private static final StringBuffer SQL_RESET_STATUS = new StringBuffer();
	
	// 下次执行接口表状态复位时间
	private long nextResetTime = 0;
	
	private String wsUrl;
	private DBManager dbManager;
	
	static{
		// before load data
		SQL_BEFORE_LOAD.append("update hht_sss_int_rms_data");
		SQL_BEFORE_LOAD.append("   set server_id = ?, send_thread = ?, send_status = 1, send_tm = sysdate");
		SQL_BEFORE_LOAD.append(" where send_status = 0");
		SQL_BEFORE_LOAD.append("   and rownum <= ?");

		// load data
		SQL_LOAD_RECORD.append("select id,");
		SQL_LOAD_RECORD.append("       waybill_no,");
		SQL_LOAD_RECORD.append("       dept_code,");
		SQL_LOAD_RECORD.append("       emp_code,");
		SQL_LOAD_RECORD.append("       weight,");
		SQL_LOAD_RECORD.append("       src,");
		SQL_LOAD_RECORD.append("       city_code,");
		SQL_LOAD_RECORD.append("       info,");
		SQL_LOAD_RECORD.append("       find_detail,");
		SQL_LOAD_RECORD.append("       data_type,");
		SQL_LOAD_RECORD.append("       inst_tm");
		SQL_LOAD_RECORD.append("  from hht_sss_int_rms_data");
		SQL_LOAD_RECORD.append(" where send_status = 1");
		SQL_LOAD_RECORD.append("   and server_id = ?");
		SQL_LOAD_RECORD.append("   and send_thread = ?");
		SQL_LOAD_RECORD.append("   and rownum <= ?");
		
		// send successfully
		SQL_SEND_SUCCESS.append("update hht_sss_int_rms_data");
		SQL_SEND_SUCCESS.append("   set send_status = 2");
		SQL_SEND_SUCCESS.append(" where id = ?");
		
		SQL_RESET_STATUS.append("update hht_sss_int_rms_data set send_status = 0 where send_status = 1 and send_tm < (sysdate - 10 / (24 * 60))");
		
	}
	
	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("RmsDataWorker[").append(Thread.currentThread().getId()).append("]");
		
		LOG.info(logPrefix.toString() + " start");
		
		while (running) {
			try {
				handleRecords();
				
				if (System.currentTimeMillis() > nextResetTime) {
					// 更新处理失败数据状态
					int count = resetStatus();
					
					LOG.info("RmsDataWorker reset record status count->"+count);
					
					// 设置下次执行复位操作的时间为：10分钟之后
					nextResetTime = System.currentTimeMillis() + (10 * 60 * 1000);
				}
				
				makeWait(task.getPeriod());
			}catch (Exception e) {
				e.printStackTrace();
				
				LOG.error("RmsDataWorker Exception Occured", e);
			}
		}
	}

	@Override
	public void preprocess() {
	}
	
	
	/**
	 * 处理所有待下发的数据
	 * Mar 29, 2013
	 */
	private void handleRecords(){
		Connection conn = null;
		
		try {
			// 预加载
			beforeLoadRecords();
			
			conn = dbManager.getConnection();
			
			// 加载数据
			List<RmsDataTO> list = loadRecords(conn);
			
			if (list != null && list.size() > 0) {
				for (RmsDataTO rmsDataTO : list) {
					// 转换数据
					RmsData rmsData = buildRmsData(rmsDataTO);
					
					Long id = rmsDataTO.getId();
					
					String result = null;
					try {
						// 调WebService下发数据
						result = sendData(rmsData);
					} catch (Exception e) {
						result = "fail";
						LOG.error("RmsDataWorker connect SSS server exception", e);
						e.printStackTrace();
					}
					
					try{
						if (result == null) {
							// 数据下发成功
							sendSucc(conn, id);
							
							LOG.info("RmsDataWorker send rms data successfully, id->"+id+",result->"+result);
						}else {
							LOG.info("RmsDataWorker send rms data failure, id->"+id+",result->"+result);
						}
						
					}catch (Exception e) {
						e.printStackTrace();
						LOG.error("RmsDataWorker send rms data failure, result->"+result, e);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			
			LOG.error("RmsDataWorker handle rms data exception", e);
		}finally{
			dbManager.close(conn);
		}
	}
	
	/**
	 * 更新预加载数据状态 
	 * Mar 29, 2013
	 * @throws SQLException
	 */
	private void beforeLoadRecords() throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = dbManager.getConnection();
			
			pstmt = conn.prepareStatement(SQL_BEFORE_LOAD.toString());
			pstmt.setString(1, CommonHelper.getServerId());
			pstmt.setLong(2, Thread.currentThread().getId());
			pstmt.setLong(3, task.getRecordSize());
			
			pstmt.executeUpdate();
		} finally {
			dbManager.close(pstmt);
			dbManager.close(conn);
		}
	}
	
	/**
	 * 加载数据
	 * Mar 29, 2013
	 * @param conn
	 * @return
	 * @throws SQLException
	 */
	private List<RmsDataTO> loadRecords(Connection conn) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<RmsDataTO> list = new ArrayList<RmsDataTO>();
		
		try{
			pstmt = conn.prepareStatement(SQL_LOAD_RECORD.toString());
			pstmt.setString(1, CommonHelper.getServerId());
			pstmt.setLong(2, Thread.currentThread().getId());
			pstmt.setLong(3, task.getRecordSize());
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				RmsDataTO rmsDataTO = new RmsDataTO();
				rmsDataTO.setId(rs.getLong("id"));
				rmsDataTO.setWaybillNo(rs.getString("waybill_no"));
				rmsDataTO.setDeptCode(rs.getString("dept_code"));
				rmsDataTO.setEmpCode(rs.getString("emp_code"));
				rmsDataTO.setWeight(rs.getDouble("weight"));
				rmsDataTO.setSrc(rs.getString("src"));
				rmsDataTO.setCityCode(rs.getString("city_code"));
				rmsDataTO.setInfo(rs.getString("info"));
				rmsDataTO.setFindDetail(rs.getInt("find_detail"));
				rmsDataTO.setDataType(rs.getInt("data_type"));
				rmsDataTO.setInstTm(rs.getTimestamp("inst_tm"));
				
				list.add(rmsDataTO);
			}
		}finally{
			dbManager.close(rs);
			dbManager.close(pstmt);
		}
		
		return list;
	}
	
	/**
	 * 发送成功 
	 * Mar 29, 2013
	 * @param conn
	 * @param id
	 * @throws SQLException
	 */
	private void sendSucc(Connection conn, Long id) throws SQLException{
		PreparedStatement pstmt = null;
		
		try{
			pstmt = conn.prepareStatement(SQL_SEND_SUCCESS.toString());
			pstmt.setLong(1, id);
			
			pstmt.executeUpdate();
		}finally{
			dbManager.close(pstmt);
		}
	}
	
	/**
	 * 调用SSS通缉接口
	 * Mar 29, 2013
	 * @param rmsData
	 * @return
	 * @throws Exception
	 */
	private String sendData(RmsData rmsData) throws Exception{
		IRMSInterfaceService service = new IRMSInterfaceServiceLocator();
		String result = service.getIRMSInterfacePort(new URL(wsUrl)).saveRmsData(rmsData);
		
		return result;
	}
	
	/**
	 * 组装RmsData对象
	 * 
	 * Mar 29, 2013
	 * @param rmsDataTO
	 * @return
	 */
	private RmsData buildRmsData(RmsDataTO rmsDataTO){
		RmsData rmsData = new RmsData();
		rmsData.setCityCode(rmsDataTO.getCityCode());
		rmsData.setCreateTime(rmsDataTO.getInstTm().getTime());
		rmsData.setDataType(rmsDataTO.getDataType());
		rmsData.setDeptCode(rmsDataTO.getDeptCode());
		rmsData.setEmpCode(rmsDataTO.getEmpCode());
		rmsData.setFindDetail(rmsDataTO.getFindDetail());
		rmsData.setInfo(rmsDataTO.getInfo());
		rmsData.setSrc(rmsDataTO.getSrc());
		rmsData.setWaybillNo(rmsDataTO.getWaybillNo());
		rmsData.setWeight(rmsDataTO.getWeight());
		
		return rmsData;
	}
	
	
	/**
	 * 重置发送失败数据状态
	 * Aug 12, 2013
	 * @return
	 */
	private int resetStatus(){
		int count = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = dbManager.getConnection();
			
			pstmt = conn.prepareStatement(SQL_RESET_STATUS.toString());
			count = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			dbManager.close(pstmt);
			dbManager.close(conn);
		}
		
		return count;
	}
	
	
	/************** get/set *******************/
	public void setWsUrl(String wsUrl) {
		this.wsUrl = wsUrl;
	}

	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}
	
	/************** get/set *******************/
}
