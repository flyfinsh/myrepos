package com.sf.hht.interfaces.task.rms.to;

import java.util.Date;

public class RmsDataTO {
	private Long id;
	
	private String cityCode;
	
    private long createTime;
    
    private int dataType;
    
    private String deptCode;
    
    private String empCode;
    
    private int findDetail;
    
    private String info;
    
    private String src;
    
    private String waybillNo;
    
    private double weight;
    
    private Date instTm;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public long getCreateTime() {
		return createTime;
	}

	public void setCreateTime(long createTime) {
		this.createTime = createTime;
	}

	public int getDataType() {
		return dataType;
	}

	public void setDataType(int dataType) {
		this.dataType = dataType;
	}

	public String getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	public String getEmpCode() {
		return empCode;
	}

	public void setEmpCode(String empCode) {
		this.empCode = empCode;
	}

	public int getFindDetail() {
		return findDetail;
	}

	public void setFindDetail(int findDetail) {
		this.findDetail = findDetail;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getSrc() {
		return src;
	}

	public void setSrc(String src) {
		this.src = src;
	}

	public String getWaybillNo() {
		return waybillNo;
	}

	public void setWaybillNo(String waybillNo) {
		this.waybillNo = waybillNo;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public Date getInstTm() {
		return instTm;
	}

	public void setInstTm(Date instTm) {
		this.instTm = instTm;
	}
}
