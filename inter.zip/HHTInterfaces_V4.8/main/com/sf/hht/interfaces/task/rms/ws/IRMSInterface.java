/**
 * IRMSInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.task.rms.ws;

public interface IRMSInterface extends java.rmi.Remote {
    public java.lang.String saveRmsData(com.sf.hht.interfaces.task.rms.ws.RmsData arg0) throws java.rmi.RemoteException;
    public java.lang.String saveBatchRmsData(com.sf.hht.interfaces.task.rms.ws.RmsData[] rmsData) throws java.rmi.RemoteException;
}
