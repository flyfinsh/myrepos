/**
 * IRMSInterfaceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.task.rms.ws;

public interface IRMSInterfaceService extends javax.xml.rpc.Service {
    public java.lang.String getIRMSInterfacePortAddress();

    public com.sf.hht.interfaces.task.rms.ws.IRMSInterface getIRMSInterfacePort() throws javax.xml.rpc.ServiceException;

    public com.sf.hht.interfaces.task.rms.ws.IRMSInterface getIRMSInterfacePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
