/**
 * IRMSInterfaceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.task.rms.ws;


public class IRMSInterfaceServiceLocator extends org.apache.axis.client.Service implements com.sf.hht.interfaces.task.rms.ws.IRMSInterfaceService {

    // Use to get a proxy class for IRMSInterfacePort
    private java.lang.String IRMSInterfacePort_address = "http://10.0.14.194:8080/sss/services/RMSInterface";
    

	public java.lang.String getIRMSInterfacePortAddress() {
        return IRMSInterfacePort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String IRMSInterfacePortWSDDServiceName = "IRMSInterfacePort";

    public java.lang.String getIRMSInterfacePortWSDDServiceName() {
        return IRMSInterfacePortWSDDServiceName;
    }

    public void setIRMSInterfacePortWSDDServiceName(java.lang.String name) {
        IRMSInterfacePortWSDDServiceName = name;
    }

    public com.sf.hht.interfaces.task.rms.ws.IRMSInterface getIRMSInterfacePort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(IRMSInterfacePort_address);
        }
        catch (java.net.MalformedURLException e) {
            return null; // unlikely as URL was validated in WSDL2Java
        }
        return getIRMSInterfacePort(endpoint);
    }

    public com.sf.hht.interfaces.task.rms.ws.IRMSInterface getIRMSInterfacePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.sf.hht.interfaces.task.rms.ws.IRMSInterfaceServiceSoapBindingStub _stub = new com.sf.hht.interfaces.task.rms.ws.IRMSInterfaceServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getIRMSInterfacePortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.sf.hht.interfaces.task.rms.ws.IRMSInterface.class.isAssignableFrom(serviceEndpointInterface)) {
                com.sf.hht.interfaces.task.rms.ws.IRMSInterfaceServiceSoapBindingStub _stub = new com.sf.hht.interfaces.task.rms.ws.IRMSInterfaceServiceSoapBindingStub(new java.net.URL(IRMSInterfacePort_address), this);
                _stub.setPortName(getIRMSInterfacePortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        java.rmi.Remote _stub = getPort(serviceEndpointInterface);
        ((org.apache.axis.client.Stub) _stub).setPortName(portName);
        return _stub;
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://service.rms.integration.sf.com/", "IRMSInterfaceService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("IRMSInterfacePort"));
        }
        return ports.iterator();
    }

}
