/**
 * RmsData.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.task.rms.ws;

public class RmsData  implements java.io.Serializable {
    private java.lang.String cityCode;
    private long createTime;
    private int dataType;
    private java.lang.String deptCode;
    private java.lang.String empCode;
    private int findDetail;
    private java.lang.String info;
    private java.lang.String src;
    private java.lang.String waybillNo;
    private double weight;

    public RmsData() {
    }

    public java.lang.String getCityCode() {
        return cityCode;
    }

    public void setCityCode(java.lang.String cityCode) {
        this.cityCode = cityCode;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public int getDataType() {
        return dataType;
    }

    public void setDataType(int dataType) {
        this.dataType = dataType;
    }

    public java.lang.String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(java.lang.String deptCode) {
        this.deptCode = deptCode;
    }

    public java.lang.String getEmpCode() {
        return empCode;
    }

    public void setEmpCode(java.lang.String empCode) {
        this.empCode = empCode;
    }

    public int getFindDetail() {
        return findDetail;
    }

    public void setFindDetail(int findDetail) {
        this.findDetail = findDetail;
    }

    public java.lang.String getInfo() {
        return info;
    }

    public void setInfo(java.lang.String info) {
        this.info = info;
    }

    public java.lang.String getSrc() {
        return src;
    }

    public void setSrc(java.lang.String src) {
        this.src = src;
    }

    public java.lang.String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(java.lang.String waybillNo) {
        this.waybillNo = waybillNo;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RmsData)) return false;
        RmsData other = (RmsData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((cityCode==null && other.getCityCode()==null) || 
             (cityCode!=null &&
              cityCode.equals(other.getCityCode()))) &&
            createTime == other.getCreateTime() &&
            dataType == other.getDataType() &&
            ((deptCode==null && other.getDeptCode()==null) || 
             (deptCode!=null &&
              deptCode.equals(other.getDeptCode()))) &&
            ((empCode==null && other.getEmpCode()==null) || 
             (empCode!=null &&
              empCode.equals(other.getEmpCode()))) &&
            findDetail == other.getFindDetail() &&
            ((info==null && other.getInfo()==null) || 
             (info!=null &&
              info.equals(other.getInfo()))) &&
            ((src==null && other.getSrc()==null) || 
             (src!=null &&
              src.equals(other.getSrc()))) &&
            ((waybillNo==null && other.getWaybillNo()==null) || 
             (waybillNo!=null &&
              waybillNo.equals(other.getWaybillNo()))) &&
            weight == other.getWeight();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCityCode() != null) {
            _hashCode += getCityCode().hashCode();
        }
        _hashCode += new Long(getCreateTime()).hashCode();
        _hashCode += getDataType();
        if (getDeptCode() != null) {
            _hashCode += getDeptCode().hashCode();
        }
        if (getEmpCode() != null) {
            _hashCode += getEmpCode().hashCode();
        }
        _hashCode += getFindDetail();
        if (getInfo() != null) {
            _hashCode += getInfo().hashCode();
        }
        if (getSrc() != null) {
            _hashCode += getSrc().hashCode();
        }
        if (getWaybillNo() != null) {
            _hashCode += getWaybillNo().hashCode();
        }
        _hashCode += new Double(getWeight()).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RmsData.class);

    static {
        org.apache.axis.description.FieldDesc field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("cityCode");
        field.setXmlName(new javax.xml.namespace.QName("", "cityCode"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("createTime");
        field.setXmlName(new javax.xml.namespace.QName("", "createTime"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("dataType");
        field.setXmlName(new javax.xml.namespace.QName("", "dataType"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("deptCode");
        field.setXmlName(new javax.xml.namespace.QName("", "deptCode"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("empCode");
        field.setXmlName(new javax.xml.namespace.QName("", "empCode"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("findDetail");
        field.setXmlName(new javax.xml.namespace.QName("", "findDetail"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("info");
        field.setXmlName(new javax.xml.namespace.QName("", "info"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("src");
        field.setXmlName(new javax.xml.namespace.QName("", "src"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("waybillNo");
        field.setXmlName(new javax.xml.namespace.QName("", "waybillNo"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("weight");
        field.setXmlName(new javax.xml.namespace.QName("", "weight"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        typeDesc.addFieldDesc(field);
    };

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
