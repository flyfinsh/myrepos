package com.sf.hht.interfaces.task.secondTranshipProvide;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.rpc.ServiceException;

import org.apache.log4j.Logger;

import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.task.secondTranshipProvide.ws.SecondTranshipProvideServiceLocator;
import com.sf.hht.interfaces.task.secondTranshipProvide.ws.SecondTranshipResult;

/**
 * 二程接驳数据维护
 * 
 * @author 361412
 * 
 */
public class SecondTranshipProvideWorker extends TaskWorker {
    private static final Logger LOG = Logger
            .getLogger(SecondTranshipProvideWorker.class);

    private static final SimpleDateFormat sdf = new SimpleDateFormat(
            "yyyy-MM-dd HH:mm:ss");

    private static final String SQL_INSER = "insert into pd_second_tranship_provide(ID, ZNO, TRAN_CODE, TRAN_NAME, TRAN_EMP_ID) values(seq_sec_tran_pro.nextval,?,?,?,?)";
    private static final String SQL_DELETE = "delete from pd_second_tranship_provide";
    private static final int STATUS_SUCCESS_CODE = 1;

    private DBManager dbManager;
    // WebService 地址
    private String wsUrl;
    // 每天同步开始时间
    private int syncHour;

    @Override
    protected void execute() {
        StringBuffer logPrefix = new StringBuffer();
        logPrefix.append("SecondTranshipProvideWorker[").append(
                Thread.currentThread().getId()).append("]");

        LOG.info(logPrefix.toString() + " start");

        boolean isComplete = false;

        while (running) {
            try {
                if (!runTask()) {
                    isComplete = false;
                    makeWait(task.getPeriod());
                    continue;
                } else {
                    if (isComplete) {
                        makeWait(task.getPeriod());
                        continue;
                    }
                }

                receive();
                isComplete = true;
            } catch (Exception e) {
                LOG.error("SecondTranshipProvideWorker sync data exception", e);
            }
        }

        LOG.info(logPrefix + " end");
    }

    @Override
    public void preprocess() {
    }

    /**
     * 接收数据
     */
    private void receive() {
        Connection conn = null;

        SecondTranshipResult result = loadRecords();

        try {
            conn = dbManager.getConnection();
            conn.setAutoCommit(false);

            if (result != null) {
                if (result.getStatus() == STATUS_SUCCESS_CODE) {
                    // 删除所有数据
                    delteAllDate(conn);

                    // 获取所有数据
                    String[] date = result.getData();

                    if (date != null && date.length > 0) {
                        for (String infoArray : date) {
                            // 保存数据
                            insertBusinessStore(conn, infoArray);
                        }
                    }

                    LOG
                            .info("SecondTranshipProvideWorker WebService response successfully, status: "
                                    + result.getStatus());
                } else {
                    LOG
                            .info("SecondTranshipProvideWorker WebService response failure, status: "
                                    + result.getStatus());
                }
            }

            conn.commit();
        } catch (Exception e) {
            try {
                // 数据回滚
                conn.rollback();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }

            e.printStackTrace();
            LOG.error("SecondTranshipProvideWorker receive data exception ", e);
        } finally {
            try {
                if (conn != null) {
                    conn.setAutoCommit(true);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

            dbManager.close(conn);
        }
    }

    /**
     * 通过WebService获取数据
     * 
     * Feb 25, 2013
     * 
     * @return
     */
    private SecondTranshipResult loadRecords() {
        SecondTranshipResult result = null;

        try {
            LOG
                    .info("SecondTranshipProvideWorker WebService call start time : "
                            + sdf.format(new Date()));

            // 同步二程接驳数据
            SecondTranshipProvideServiceLocator locator = new SecondTranshipProvideServiceLocator();
            result = locator.getSecondTranshipProvidePort(new URL(wsUrl))
                    .searchByDept4TranshipMan("001");

            LOG.info("SecondTranshipProvideWorker WebService call end time : "
                    + sdf.format(new Date()));
        } catch (RemoteException e) {
            e.printStackTrace();
            LOG
                    .error(
                            "SecondTranshipProvideWorker WebService call failure, RemoteException",
                            e);
        } catch (ServiceException e) {
            e.printStackTrace();
            LOG
                    .error(
                            "SecondTranshipProvideWorker WebService call failure, ServiceException",
                            e);
        } catch (MalformedURLException e) {
            LOG
                    .error(
                            "SecondTranshipProvideWorker WebService call failure, MalformedURLException",
                            e);
            e.printStackTrace();
        }

        return result;
    }

    /**
     * 保存虚拟地址营业网点数据
     * 
     * Feb 25, 2013
     * 
     * @param conn
     * @param store
     * @throws SQLException
     */
    private void insertBusinessStore(Connection conn, String infoArray)
            throws SQLException {
        PreparedStatement pstmt = null;

        String[] info = infoArray.split(";");

        if (info != null && info.length > 0) {
            try {
                pstmt = conn.prepareStatement(SQL_INSER);
                pstmt.setString(1, info[0]);
                pstmt.setString(2, info[1]);
                pstmt.setString(3, info[2]);
                pstmt.setString(4, info[3]);

                pstmt.executeUpdate();
            } finally {
                dbManager.close(pstmt);
            }
        }
    }

    /**
     * 删除所有虚拟地址营业网点数据
     * 
     * Feb 25, 2013
     * 
     * @param conn
     * @throws SQLException
     */
    private void delteAllDate(Connection conn) throws SQLException {
        PreparedStatement pstmt = null;

        try {
            pstmt = conn.prepareStatement(SQL_DELETE);
            pstmt.executeUpdate();
        } finally {
            dbManager.close(pstmt);
        }
    }

    private boolean runTask() {
        Calendar curDate = Calendar.getInstance();

        int hour = curDate.get(Calendar.HOUR_OF_DAY);

        if (hour == syncHour) {
            return true;
        }

        return false;
    }

    /** **************** get/set ********************* */
    public void setDbManager(DBManager dbManager) {
        this.dbManager = dbManager;
    }

    public void setWsUrl(String wsUrl) {
        this.wsUrl = wsUrl;
    }

    public void setSyncHour(int syncHour) {
        this.syncHour = syncHour;
    }

    public static void main(String[] args) throws RemoteException,
            MalformedURLException, ServiceException {
        SecondTranshipProvideServiceLocator locator = new SecondTranshipProvideServiceLocator();
        SecondTranshipResult result = locator
                .getSecondTranshipProvidePort(
                        new URL(
                                "http://10.0.23.114:8080/sfmap/ws/secondTranshipProvide"))
                .searchByDept4TranshipMan("001");

        if (result != null && result.getStatus() == STATUS_SUCCESS_CODE) {
            if (result.getData() != null) {
                for (String str : result.getData()) {
                    System.out.println(str);
                }
            }
        }
    }
}
