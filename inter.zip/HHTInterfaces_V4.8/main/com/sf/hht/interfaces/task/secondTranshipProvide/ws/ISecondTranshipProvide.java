/**
 * ISecondTranshipProvide.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.task.secondTranshipProvide.ws;

public interface ISecondTranshipProvide extends java.rmi.Remote {
    public com.sf.hht.interfaces.task.secondTranshipProvide.ws.SecondTranshipResult searchByDeptCode(java.lang.String arg0) throws java.rmi.RemoteException;
    public com.sf.hht.interfaces.task.secondTranshipProvide.ws.SecondTranshipResult searchByDept4TranshipMan(java.lang.String arg0) throws java.rmi.RemoteException;
}
