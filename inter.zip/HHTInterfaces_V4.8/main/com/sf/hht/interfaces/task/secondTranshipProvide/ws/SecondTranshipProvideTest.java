package com.sf.hht.interfaces.task.secondTranshipProvide.ws;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

public class SecondTranshipProvideTest {

    public static void main(String[] args) throws RemoteException,
            MalformedURLException, ServiceException {
        SecondTranshipProvideServiceLocator locator = new SecondTranshipProvideServiceLocator();
        SecondTranshipResult result = locator
                .getSecondTranshipProvidePort(
                        new URL(
                                "http://10.0.23.127:8080/sfmap/ws/secondTranshipProvide"))
                .searchByDept4TranshipMan("001");

        System.out.println("status:" + result.getTypeDesc());

        String[] date = result.getData();
        if (date != null && date.length > 0) {
            System.out.println("date length:" + date.length);

            for (String str : date) {
                System.out.println(str);
            }
        } else {
            System.out.println("date length:" + 0);
        }
    }
}
