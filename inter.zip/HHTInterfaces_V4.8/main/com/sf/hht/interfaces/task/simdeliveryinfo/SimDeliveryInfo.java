package com.sf.hht.interfaces.task.simdeliveryinfo;

public class SimDeliveryInfo {
	private String waybillNo;	// 运单号
	
	private String deptCode;	// 网点编码
	
	private String cityCode;	// 城市代码
	
	private String deliveryType;	// 派送类型(0-改派;1-非改派)
	
	private String msg;			// 消息
	
	private String empId;		// 工号

	public String getWaybillNo() {
		return waybillNo;
	}

	public void setWaybillNo(String waybillNo) {
		this.waybillNo = waybillNo;
	}

	public String getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getDeliveryType() {
		return deliveryType;
	}

	public void setDeliveryType(String deliveryType) {
		this.deliveryType = deliveryType;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}
}
