package com.sf.hht.interfaces.task.simdeliveryinfo;

import javax.jws.WebService;

@WebService
public interface SimDeliveryInfoService {
	/**
	 * 保存安全岛推送消息
	 * Jun 28, 2013
	 * @param info
	 * @return
	 */
	public int pullInfo(SimDeliveryInfo info);
}
