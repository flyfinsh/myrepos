package com.sf.hht.interfaces.task.simdeliveryinfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.jws.WebService;

import com.sf.hht.interfaces.skeleton.resource.DBManager;


/**
 * 安全岛系统SIM推送消息服务
 * @author 256203
 * @version
 * @since Jun 27, 2013
 */
@WebService(endpointInterface = "com.sf.hht.interfaces.task.simdeliveryinfo.SimDeliveryInfoService")
public class SimDeliveryInfoServiceImpl implements SimDeliveryInfoService{
	// 推送成功
	private static final int SUCCESS = 1000;
	// 推送失败
	private static final int SYSERR = 1001;
	// 数据不合法
	private static final int DATA_NOT_AVAILABLE = 1002;
	
	private DBManager dbManager;
	
	/**
	 * 保存安全岛推送消息
	 * Jun 28, 2013
	 * @param info
	 * @return
	 */
	public int pullInfo(SimDeliveryInfo info){
		if (!valid(info)) {
			System.out.println("Webservice SimDeliveryInfoService request parameter not available");
			return DATA_NOT_AVAILABLE;
		}
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			String sql = "insert into sim_push_info(id, waybill_no, emp_code, dept_code, city_code, delivery_type, msg, inst_time, flag) values(SEQ_SIM_PUSH_INFO_ID.NEXTVAL, ?, ?, ?, ?, ?, ?, SYSDATE, '0')";

			conn = dbManager.getConnection();
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, info.getWaybillNo());
			pstmt.setString(2, info.getEmpId());
			pstmt.setString(3, info.getDeptCode());
			pstmt.setString(4, info.getCityCode());
			pstmt.setString(5, info.getDeliveryType());
			pstmt.setString(6, info.getMsg());
			
			pstmt.executeUpdate();
			
			System.out.println("Webservice SimDeliveryInfoService handle successfully, waybillno : " + info.getWaybillNo());
			
			return SUCCESS;
		} catch (Exception e) {
			System.out.println("Webservice SimDeliveryInfoService system error, waybillno : " + info.getWaybillNo());
			e.printStackTrace();
			return SYSERR;
		}finally{
			try {
				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
				}
				if(conn != null){
					conn.close();
					conn = null;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	private boolean valid(SimDeliveryInfo info){
		if (info == null) {
			return false;
		}
		
		String empCode = info.getEmpId();
		String msg = info.getMsg();
		
		if (empCode == null || empCode.trim().length() == 0) {
			return false;
		}
		
		if (msg == null || msg.trim().length() == 0) {
			return false;
		}
		
		return true;
	}

	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}
}
