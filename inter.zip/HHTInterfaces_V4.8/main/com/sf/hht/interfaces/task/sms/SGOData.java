package com.sf.hht.interfaces.task.sms;

public class SGOData {

	// msg中的第一个"|"到第二个"|"之间
	private String jobid;
	// 接收日期
	private String recvtime;
	
	public String getJobid() {
		return jobid;
	}
	public void setJobid(String jobid) {
		this.jobid = jobid;
	}
	public String getRecvtime() {
		return recvtime;
	}
	public void setRecvtime(String recvtime) {
		this.recvtime = recvtime;
	}
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("jobid=").append(jobid)
			.append(", recvtime=").append(recvtime);
		return buffer.toString();
	}
}
