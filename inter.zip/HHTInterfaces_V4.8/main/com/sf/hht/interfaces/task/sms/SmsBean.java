package com.sf.hht.interfaces.task.sms;

public class SmsBean {

	private String msg;	// 消息内容
	private String mobileno; // 手机号码
	private String recvtime; // 接收时间
	private String recvdate; // 接收日期
	
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getRecvtime() {
		return recvtime;
	}
	public void setRecvtime(String recvtime) {
		this.recvtime = recvtime;
	}
	public String getRecvdate() {
		return recvdate;
	}
	public void setRecvdate(String recvdate) {
		this.recvdate = recvdate;
	}
}
