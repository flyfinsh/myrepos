package com.sf.hht.interfaces.task.sms;

import java.util.List;

import javax.jws.WebService;

@WebService
public interface SmsService {

	/**
	 * 保存SMS信息
	 * @param smsList 通缉对象
	 * @return 成功返回"1000"，失败返回"1001"，数据不合法返回"1002"
	 */
	public String pushSmsDatas(List<SmsBean> smsList);
}
