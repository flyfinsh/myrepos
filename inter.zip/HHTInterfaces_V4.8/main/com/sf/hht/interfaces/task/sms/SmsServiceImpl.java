package com.sf.hht.interfaces.task.sms;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.sf.hht.interfaces.skeleton.resource.DBManager;

public class SmsServiceImpl implements SmsService {

	private static final Logger logger = Logger.getLogger(SmsServiceImpl.class);
	private DBManager dbManager;
	// OTHER信息头
	private static final String OTHER_HEADER = "HHTIBM";
	// SGO信息头
	private static final String SGO_HEADER = "HHTIBMSGO";
	// 成功
	private static final String SUCCESS = "1000";
	// 失败
	private static final String SYSERR = "1001";
	// 数据不合法
	private static final String DATA_NOT_AVAILABLE = "1002";
	// 插入数据到smsreply
	private static final String SQL_INS_SMS_REPLY = "insert into smsreply(jobid, mobile, msg, isp, recvtime) values(seq_smsreply.nextval, ?, ?, ?, to_date(?, 'yyyy-mm-dd hh24:mi:ss'))";
	// 按jobid删除smsreturncode记录
	private static final String SQL_DEL_SMS_RETURN_CODE = "delete from smsreturncode where jobid = ?";
	// 插入数据到smsreturncode
	private static final String SQL_INS_SMS_RETURN_CODE = "insert into smsreturncode(jobid, recvtime, sended, returncode) values(?, to_date(?, 'yyyy-mm-dd hh24:mi:ss'), 0, 0)";
	// 分隔符
	private static final String SEPARATOR = "|";

	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}

	@Override
	public String pushSmsDatas(List<SmsBean> smsList) {
		if (smsList == null || smsList.size() == 0) {
			logger.info("Webservice SmsService return code->"+DATA_NOT_AVAILABLE);
			return DATA_NOT_AVAILABLE;
		}
		
		Connection conn = null;
		try{
			conn = dbManager.getConnection();
			conn.setAutoCommit(false);
			for (SmsBean sms : smsList) {
				if (sms == null) {
					logger.info("Webservice SmsService list object illegal");
					continue;
				}
				
				if (sms.getMsg() == null || "".equals(sms.getMsg())) {
					logger.info("Webservice SmsService list object msg illegal");
					continue;
				}
				
				try{
					String msg = sms.getMsg();
					//订单、内部通讯回执数据，规则：短信回执内容以HHTIBMSGO开头。
					if(msg.startsWith(SGO_HEADER)) { 
						SGOData data = smsToSgoData(sms);
						if(data != null) {
							delSmsReturnCode(data.getJobid(), conn);
							addSmsReturnCode(data,conn);
						}
					}
					//短信登录、短信自测回执数据，规则：短信回执内容以HHTIBM开头，并且第7位到第9位不等于SGO；
					else if(msg.startsWith(OTHER_HEADER) && !msg.substring(6, 9).equals("SGO")) {
						OtherData data = smsToOtherData(sms);
						if(data != null)
							addSmsReply(data,conn);
					}
				}catch (Exception e) {
					logger.error("Webservice SmsService data processing exception, msg->"+sms.getMsg()+",errpr->"+e.getMessage());
				}
			}
			conn.commit();
		}catch (Exception e) {
			logger.error("Webservice SmsService system error" + "\n" + e.getMessage());
			if(conn != null) {
				try {
					conn.rollback();
				} catch (SQLException e1) {
					logger.error(e1.getMessage());
				}
			}
			return SYSERR;
		}finally{
			// 关闭数据库连接
			dbManager.close(conn);
		}
		logger.info("Webservice SmsService handle successfully");
		return SUCCESS;
	}

	private SGOData smsToSgoData(SmsBean smsBean) {
		String msg = smsBean.getMsg();
		String msgRecvtime = null;
		String jobId = null;
		SGOData data = null;
		if(msg != null){
			jobId = msg.substring(msg.indexOf(SEPARATOR) + 1, msg.lastIndexOf(SEPARATOR));	// jobid
			msgRecvtime = msg.substring(msg.lastIndexOf(SEPARATOR) + 1);	// 消息接收时间
			if(!"".equals(jobId)){ 
				data = new SGOData();
				data.setJobid(jobId);
				data.setRecvtime(msgRecvtime);
			}
		}
		return data;
	}
	
	private OtherData smsToOtherData(SmsBean smsBean) {
		String msg = smsBean.getMsg();
		String isp = null;
		String msgPart = null;
		String recevTime = null;
		OtherData otherData = null;
		if(msg != null) {
			isp = msg.substring(3, 6);
			msgPart = msg.substring(6);
			String date = smsBean.getRecvdate();
			String time = smsBean.getRecvtime();
			if(date != null && time != null){
				recevTime = date + " " + time;
			}
			
			otherData = new OtherData();
			otherData.setMobileno(smsBean.getMobileno());
			otherData.setIsp(isp);
			otherData.setMsg(msgPart);
			otherData.setRecvtime(recevTime);
		}
		return otherData;
	}

	/**
	 * 新增一条记录到表smsreply
	 * Mar 3, 2012
	 * @param otherData
	 * @return
	 * @throws SQLException 
	 */
	private void addSmsReply(OtherData data, Connection conn) throws SQLException{

		PreparedStatement pstmt = null;

		try{
			pstmt = conn.prepareStatement(SQL_INS_SMS_REPLY);
			pstmt.setString(1, data.getMobileno());
			pstmt.setString(2, data.getMsg());
			pstmt.setString(3, data.getIsp());
			pstmt.setString(4, data.getRecvtime());

			// 执行other数据插入
			pstmt.executeUpdate();

		}finally{
			dbManager.close(pstmt);
		}
	}

	/**
	 * 按jobid删除smsreturncode对应记录
	 * Mar 2, 2012
	 * @param jobId
	 * @param conn
	 * @throws SQLException 
	 */
	private void delSmsReturnCode(String jobId, Connection conn) throws SQLException{
		PreparedStatement pstmt = null;

		try{
			pstmt = conn.prepareStatement(SQL_DEL_SMS_RETURN_CODE);
			pstmt.setString(1, jobId);

			pstmt.executeUpdate();

		} finally{
			dbManager.close(pstmt);
		}
	}

	/**
	 * 插入smsreturncode数据
	 * Mar 2, 2012
	 * @param sgoData
	 * @param conn
	 * @throws SQLException 
	 */
	private void addSmsReturnCode(SGOData data, Connection conn) throws SQLException{
		PreparedStatement pstmt = null; 

		try{
			pstmt = conn.prepareStatement(SQL_INS_SMS_RETURN_CODE);
			pstmt.setString(1, data.getJobid());
			pstmt.setString(2, data.getRecvtime());

			pstmt.executeUpdate();

		}finally{
			dbManager.close(pstmt);
		}
	}

	public static void main(String[] args) {

//		System.out.println("123456789abc".substring(6, 10));
//		
//		List<SmsBean> list = new ArrayList<SmsBean>();
//		list.add(null);
//		System.out.println(list.size());
//		
//		System.out.println("123"+null);
		
		System.out.println("123456789".substring(0, 6));
		System.out.println("123456789".substring(6, 9));
	}
}
