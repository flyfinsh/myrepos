package com.sf.hht.interfaces.task.smsother;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.task.smsother.dto.OtherData;

public class SmsOtherWorker extends TaskWorker {
	private static final Logger LOG = Logger.getLogger(SmsOtherWorker.class);
	
	// 查询sms other 数据
	private static final String SQL_SMS_OTHER = "select rowid, mobileno, msg, recvdate, recvtime from recvmsg where substr(msg, 1, 6) = ? and substr(msg, 7, 3) <> 'SGO' and rownum < ?";
	// 插入数据到smsreply
	private static final String SQL_INS_SMS_REPLY = "insert into smsreply(jobid, mobile, msg, isp, recvtime) values(seq_smsreply.nextval, ?, ?, ?, to_date(?, 'yyyy-mm-dd hh24:mi:ss'))";
	// 按rowid删除recvmsg数据
	private static final String SQL_DEL_SMS_OTHER = "delete from recvmsg where rowid = ?";
	
	// OTHER信息头
	private static final String OTHER_HEADER = "HHTIBM";
	// 每次处理数据量
	private static final int DEFAULT_FETCH_SIZE = 100;
	
	// HHT数据源
	private DBManager hhtDBManager;
	// SMS数据库
	private DBManager smsDBManager;
	
	public void setHhtDBManager(DBManager hhtDBManager) {
		this.hhtDBManager = hhtDBManager;
	}
	public void setSmsDBManager(DBManager smsDBManager) {
		this.smsDBManager = smsDBManager;
	}

	
	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("SmsOtherWorker[").append(Thread.currentThread().getId()).append("]");
		
		LOG.info(logPrefix.toString() + " start");
		
		while(running){
			try{
				// 处理Other数据
				handleRecords(logPrefix.toString());
				// 线程休眠
				makeWait(task.getPeriod());
				
			}catch(Exception e){
				LOG.error("SmsOtherWorker Exception Occured");
			}
		}
		
		LOG.info(logPrefix + " end");
	}
	
	/**
	 * 处理数据
	 * Mar 3, 2012
	 * @param logPrefix
	 */
	private void handleRecords(String logPrefix){
		
		Connection hhtConn = null;
		Connection smsConn = null;
		
		try{
			hhtConn = hhtDBManager.getConnection();
			smsConn = smsDBManager.getConnection();
			hhtConn.setAutoCommit(true);
			smsConn.setAutoCommit(true);
			
			// 检索Other数据
			List<OtherData> list = queryOther(smsConn);
			
			for(OtherData otherData : list){
				try{
					// 插入一条other数据到smsreply
					addSmsReply(otherData, hhtConn);
					
					// 按rowid删除other数据
					delSmsOther(otherData.getRowid(), smsConn);
					
					if(LOG.isDebugEnabled()){
						LOG.debug("Saved Other data successfully! data["+otherData.toString()+"]");
					}
					
				}catch(Exception e){
					LOG.error("Saved Other data failure! data["+otherData.toString() + "], exception : ", e);
				}
				
			}
			
			LOG.info(logPrefix + "--Handled " + list.size() + " record(s)");
			
		}catch(Exception e){
			LOG.error("Exception Occured when getting connection", e);
			e.printStackTrace();
		}finally{
			// 关闭数据库连接
			hhtDBManager.close(hhtConn);
			smsDBManager.close(smsConn);
		}
	}
	
	/**
	 * 查询Other数据
	 * Mar 3, 2012
	 * @return
	 */
	private List<OtherData> queryOther(Connection conn){
		// Other集合对象
		List<OtherData> list = new ArrayList<OtherData>();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try{
			pstmt = conn.prepareStatement(SQL_SMS_OTHER);
			
			pstmt.setString(1, OTHER_HEADER);
			if(task.getRecordSize() > 0){
				pstmt.setInt(2, task.getRecordSize()+1);
			}else{
				pstmt.setInt(2, DEFAULT_FETCH_SIZE);
			}
			
			rs = pstmt.executeQuery();
			
			String msg = null;
			String msgPart = null;
			String isp = null;
			String rowid = null;
			String recevTime = null;
			
			while(rs.next()){
				rowid = rs.getString("rowid");
				msg = rs.getString("msg");
				
				try{
					// msg 格式：HHTIBMSLI 142364 142364 460002805610246 0
					if(msg != null){
						isp = msg.substring(3, 6);
						msgPart = msg.substring(6);
					}else{
						LOG.error("msg is null, rowid="+rowid);
						continue;
					}
				}catch(IndexOutOfBoundsException e){
					LOG.error("wrong msg format, msg=" + msg + ", rowid=" + rowid + ", exception:" + e);
					continue;
				}
				
				// 拼装成完整日期,比如：2012-03-03 18:02:00
				if(rs.getString("recvdate") != null && rs.getString("recvtime") != null){
					recevTime = rs.getString("recvdate") + " " + rs.getString("recvtime");
				}
				
				OtherData otherData = new OtherData();
				otherData.setRowid(rowid);
				otherData.setMobileno(rs.getString("mobileno"));
				otherData.setIsp(isp);
				otherData.setMsg(msgPart);
				otherData.setRecvtime(recevTime);
				list.add(otherData);
				
			}
			
		}catch(Exception e){
			LOG.error("Other data query exception : "+e);
			e.printStackTrace();
		}finally{
			smsDBManager.close(rs);
			smsDBManager.close(pstmt);
		}
		
		return list;
	}
	
	/**
	 * 新增一条记录到表smsreply
	 * Mar 3, 2012
	 * @param otherData
	 * @return
	 * @throws SQLException 
	 */
	private void addSmsReply(OtherData otherData, Connection conn) throws SQLException{
		
		PreparedStatement pstmt = null;
		
		try{
			pstmt = conn.prepareStatement(SQL_INS_SMS_REPLY);
			pstmt.setString(1, otherData.getMobileno());
			pstmt.setString(2, otherData.getMsg());
			pstmt.setString(3, otherData.getIsp());
			pstmt.setString(4, otherData.getRecvtime());
			
			// 执行other数据插入
			pstmt.executeUpdate();
			
		}finally{
			hhtDBManager.close(pstmt);
		}
	}
	
	/**
	 * 按rowId删除Other数据
	 * Mar 3, 2012
	 * @param rowId
	 * @return
	 * @throws SQLException 
	 */
	private void delSmsOther(String rowId, Connection conn) throws SQLException{
		
		PreparedStatement pstmt = null;
		
		try{
			pstmt = conn.prepareStatement(SQL_DEL_SMS_OTHER);
			pstmt.setString(1, rowId);
			
			// 按rowid删除other数据
			pstmt.executeUpdate();
			
		}finally{
			smsDBManager.close(pstmt);
		}
	}

	@Override
	public void preprocess() {}

}
