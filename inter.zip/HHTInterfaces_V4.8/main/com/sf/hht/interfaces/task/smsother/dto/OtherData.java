package com.sf.hht.interfaces.task.smsother.dto;

public class OtherData {
	// 行号
	private String rowid;
	// 手机号码
	private String mobileno;
	// 消息内容
	private String msg;
	//ISP
	private String isp;
	// 接收时间
	private String recvtime;
	
	public String getIsp() {
		return isp;
	}
	public void setIsp(String isp) {
		this.isp = isp;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getRecvtime() {
		return recvtime;
	}
	public void setRecvtime(String recvtime) {
		this.recvtime = recvtime;
	}
	public String getRowid() {
		return rowid;
	}
	public void setRowid(String rowid) {
		this.rowid = rowid;
	}
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("rowid=").append(rowid)
			.append(", mobileno=").append(mobileno)
			.append(", msg=").append(msg)
			.append(", isp=").append(isp)
			.append(", recvtime=").append(recvtime);
		return buffer.toString();
	}
}
