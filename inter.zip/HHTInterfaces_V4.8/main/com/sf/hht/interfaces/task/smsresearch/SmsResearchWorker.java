package com.sf.hht.interfaces.task.smsresearch;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.ws.Holder;

import org.apache.log4j.Logger;

import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.util.CommonHelper;
import com.sf.hht.interfaces.task.smsresearch.ws.ESBServerPortType;
import com.sf.hht.interfaces.task.smsresearch.ws.EsbSoapHeaderType;
import com.sf.hht.interfaces.task.smsresearch.ws.UpdateWayBillInfo;
import com.sf.hht.interfaces.task.smsresearch.ws.ImportWayBillRemkBodyType.SBODY;
import com.sf.hht.interfaces.task.smsresearch.ws.ImportWayBillRemkBodyType.SHEAD;

public class SmsResearchWorker extends TaskWorker {
	
	private static final Logger LOG = Logger.getLogger(SmsResearchWorker.class);
	
	private static final StringBuffer SQL_LOAD_RECORDS = new StringBuffer();
	static{
		SQL_LOAD_RECORDS.append("select s1.id,");
		SQL_LOAD_RECORDS.append("       s1.emp_code,");
		SQL_LOAD_RECORDS.append("       s1.cust_reply,");
		SQL_LOAD_RECORDS.append("       s1.waybill_no,");
		SQL_LOAD_RECORDS.append("       s2.msg_wqs_tmpl");
		SQL_LOAD_RECORDS.append("  from sms_research s1, sms_research_pda_msg_config s2");
		SQL_LOAD_RECORDS.append(" where s1.reason_code = s2.reason_code");
		SQL_LOAD_RECORDS.append("   and s1.done='1'");
		SQL_LOAD_RECORDS.append("   and s2.msg_wqs_tmpl is not null");
		SQL_LOAD_RECORDS.append("   and s1.update_wqs_tm is null");
		SQL_LOAD_RECORDS.append("   and ((s2.cust_reply is not null and s1.cust_reply = s2.cust_reply) or");
		SQL_LOAD_RECORDS.append("       (s2.cust_reply is null and length(s1.cust_reply) = 4))");
	}
	private static final String UPDATE_WQS_TM = "update sms_research set update_wqs_tm = sysdate, update_wqs_result = ? where id = ?";
	
	// 数据库连接管理
	private DBManager dbManager;
	// WebService url
	private String wsUrl;
	

	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("SmsResearchWorker[").append(Thread.currentThread().getId()).append("]");
		
		LOG.info(logPrefix.toString() + " start");
		
		while(running){
			try {
				int handleRows = handleRecords(logPrefix.toString());
				
				if(handleRows < task.getRecordSize()){
					makeWait(task.getPeriod());
				}
			} catch (Exception e) {
				e.printStackTrace();
				LOG.error("SmsResearchWorker running exception", e);
			}
		}
		
		LOG.info(logPrefix + " end");

	}
	
	private int handleRecords(String logPrefix){
		List<SmsResearchPdaMsg> records = new ArrayList<SmsResearchPdaMsg>();
		
		Connection conn = null;
		
		try {
			conn = dbManager.getConnection();
			conn.setAutoCommit(false);
			
			// 加载数据
			loadRecords(conn, records);
			
			int loadSize = records.size();
			
			if (loadSize > 0) {
				ESBServerPortType portType = UpdateWayBillInfo.getServerPortTypeInstance(wsUrl);
				
				SHEAD shead = new SHEAD();
				shead.setSYSTEMID("HHT");
				
				EsbSoapHeaderType esbSoapHeader = new EsbSoapHeaderType();
				esbSoapHeader.setFrom("HHT");
				esbSoapHeader.setTo("WQS");
				
				Holder<com.sf.hht.interfaces.task.smsresearch.ws.ImportWayBillRemkResponseBodyType.SHEAD> shead1 = new Holder<com.sf.hht.interfaces.task.smsresearch.ws.ImportWayBillRemkResponseBodyType.SHEAD>();
				Holder<com.sf.hht.interfaces.task.smsresearch.ws.ImportWayBillRemkResponseBodyType.SBODY> sbody1 = new Holder<com.sf.hht.interfaces.task.smsresearch.ws.ImportWayBillRemkResponseBodyType.SBODY>();
				Holder<EsbSoapHeaderType> esbSoapHeader1 = new Holder<EsbSoapHeaderType>();
				
				for (SmsResearchPdaMsg msg : records) {
					try {
						SBODY sbody = new SBODY();
						sbody.setEmployeeID(msg.getEmpCode());
						sbody.setMemo(msg.getMsgWqsTmpl());
						sbody.setWaybillNo(msg.getWaybillNO());
						
						// 调用wqs接口更新运单备注
						portType.importWayBillRemk(shead, sbody, esbSoapHeader, shead1, sbody1, esbSoapHeader1);
						
						com.sf.hht.interfaces.task.smsresearch.ws.ImportWayBillRemkResponseBodyType.SBODY result = sbody1.value;
						
						LOG.info("SmsResearchWorker update waybill remark successfully, bno->" + msg.getWaybillNO() + ",result->"+result.getResult());
						
						// 接口调用结果
						msg.setUpdateWqsRemarkResult(result.getResult());
						
						// 更新wqs备注时间为当前时间
						updateWaybillRemark(conn, msg);
						
						Thread.sleep(500);
					} catch (Exception e) {
						LOG.info("SmsResearchWorker update waybill remark failure, bon->" + msg.getWaybillNO());
						e.printStackTrace();
					}
				}
			}
			
			LOG.info(logPrefix + "--Handled " + loadSize + " record(s)");
			
			conn.commit();
			conn.setAutoCommit(true);
			
			return loadSize;
		} catch (Exception e) {
			LOG.error("SmsResearchWorker handle data exception ", e);

			try {
				if (conn != null) {
					conn.rollback();
				}
			} catch (SQLException e1) {
				LOG.error(e1);
			}
		}finally{
			// 关闭数据库连接
			dbManager.close(conn);
		}
		
		return -1;
	}
	
	
	private void loadRecords(Connection conn, List<SmsResearchPdaMsg> records) throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(SQL_LOAD_RECORDS.toString());
			
			rs = pstmt.executeQuery();
			
			SmsResearchPdaMsg to;
			while(rs.next()){
				to = new SmsResearchPdaMsg();
				to.setId(rs.getLong("id")); 	// id
				to.setEmpCode(rs.getString("emp_code"));		// 工号
				to.setWaybillNO(rs.getString("waybill_no"));	// 运单号
				
				String custReply = rs.getString("cust_reply");	// 客户回复
				String msgWqsTmpl = rs.getString("msg_wqs_tmpl");	// wqs备注模板
				// wqs备注
				to.setMsgWqsTmpl(MessageFormat.format(msgWqsTmpl, new Object[] {custReply}));
				
				records.add(to);
			}
		} finally{
			dbManager.close(rs);
			dbManager.close(pstmt);
		}
	}
	
	
	private void updateWaybillRemark(Connection conn, SmsResearchPdaMsg msg) throws SQLException {
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(UPDATE_WQS_TM);
			pstmt.setString(1, msg.getUpdateWqsRemarkResult());
			pstmt.setLong(2, msg.getId());
			pstmt.executeUpdate();
		} finally {
			dbManager.close(pstmt);
		}
	}
	

	@Override
	public void preprocess() {}

	
	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}

	public void setWsUrl(String wsUrl) {
		this.wsUrl = wsUrl;
	}

	/**
	 * description
	 * Nov 5, 2014
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

class SmsResearchPdaMsg{
	private Long id;
	
	private String empCode;
	
	private String msgTmpl;
	
	private String msgWqsTmpl;
	
	private String msgTmplHandle;
	
	private String waybillNO;
	
	private String updateWqsRemarkResult;

	public String getEmpCode() {
		return empCode;
	}

	public void setEmpCode(String empCode) {
		this.empCode = empCode;
	}

	public String getMsgTmpl() {
		return msgTmpl;
	}

	public void setMsgTmpl(String msgTmpl) {
		this.msgTmpl = msgTmpl;
	}

	public String getMsgTmplHandle() {
		return msgTmplHandle;
	}

	public void setMsgTmplHandle(String msgTmplHandle) {
		this.msgTmplHandle = msgTmplHandle;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getWaybillNO() {
		return waybillNO;
	}

	public void setWaybillNO(String waybillNO) {
		this.waybillNO = waybillNO;
	}

	public String getMsgWqsTmpl() {
		return msgWqsTmpl;
	}

	public void setMsgWqsTmpl(String msgWqsTmpl) {
		this.msgWqsTmpl = msgWqsTmpl;
	}

	public String getUpdateWqsRemarkResult() {
		return updateWqsRemarkResult;
	}

	public void setUpdateWqsRemarkResult(String updateWqsRemarkResult) {
		this.updateWqsRemarkResult = updateWqsRemarkResult;
	}
	
}
