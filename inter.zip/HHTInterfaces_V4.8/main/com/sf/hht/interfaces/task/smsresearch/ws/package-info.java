@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.sf-express.com/esb/service/UpdateWayBillInfo", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.sf.hht.interfaces.task.smsresearch.ws;
