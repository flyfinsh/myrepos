package com.sf.hht.interfaces.task.smssender;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.skeleton.sms.ws.ProcSMSProxy;
import com.sf.hht.interfaces.skeleton.sms.ws.SMSEX;

public class SMSSenderWork extends TaskWorker{

	private static final Logger LOG = Logger.getLogger(SMSSenderWork.class);

	// 数据库连接管理
	private DBManager dbManager;
	
	private String wsUrl;
	
	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}

	public void setWsUrl(String wsUrl) {
		this.wsUrl = wsUrl;
	}

	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("SMSSenderWork[").append(Thread.currentThread().getId()).append("]");

		LOG.info(logPrefix.toString() + " start");

		while(running){
			try {
				int handleRows = handleRecords();
				
				if(handleRows < task.getRecordSize()){
					makeWait(task.getPeriod());
				}
			} catch (Exception e) {
				e.printStackTrace();
				LOG.error("SmsResearchWorker running exception", e);
			}
		}

		LOG.info(logPrefix.toString() + " end");
	}

	private int handleRecords() {
		Map<String,SMSEX> records = new HashMap<String,SMSEX>();

		Connection conn = null;
		Statement st = null;

		try {
			conn = dbManager.getConnection();
			conn.setAutoCommit(false);

			st = conn.createStatement();
			st.execute("UPDATE HHT_LOCK T SET T.LOCK_VALUE = 1 WHERE T.LOCK_NAME = 'SMSLIST'");

			// 加载数据
			loadRecords(conn, records);
			
			int recordSize = records.size();

			ProcSMSProxy proxy = new ProcSMSProxy(wsUrl);
			PreparedStatement ps = conn.prepareStatement("DELETE FROM SMSLIST T WHERE T.JOBID = ?");
			Iterator<String> it = records.keySet().iterator();
			while (it.hasNext()) {
				String key =  it.next();
				SMSEX smsex = records.get(key);
				proxy.sendSMSEX(smsex);
				
				ps.setString(1, key);
				ps.addBatch();
			}
			ps.executeBatch();
			
			st.execute("UPDATE HHT_LOCK T SET T.LOCK_VALUE = 0 WHERE T.LOCK_NAME = 'SMSLIST'");
			
			LOG.info("SmsResearchWorker--Handled " + recordSize + " record(s)");
			
			conn.commit();
			conn.setAutoCommit(true);

			return recordSize;
		} catch (Exception e) {
			LOG.error("SMSSenderWork handle data exception ", e);

			try {
				if (conn != null) {
					conn.rollback();
				}
			} catch (SQLException e1) {
				LOG.error(e1);
			}
		}finally{
			// 关闭数据库连接
			dbManager.close(st);
			dbManager.close(conn);
		}

		return -1;
	}

	private void loadRecords(Connection conn, Map<String,SMSEX> records) throws SQLException {

		PreparedStatement ps = null;
		ResultSet rs = null;

		try {
			ps = conn.prepareStatement("SELECT JOBID,EMPID,MSG,MOBILE,RESNO,COUNT FROM SMSLIST WHERE ROWNUM < ?");
			ps.setInt(1, task.getRecordSize());
			rs = ps.executeQuery();
			while(rs.next()) {
				SMSEX bean = new SMSEX();
				String jobID = rs.getString(1);
				bean.setMsgId(jobID);
				bean.setCheckword(null);
				bean.setSP(null);
				bean.setSystemId("hht");
				bean.setMsgtype("HHTPDA");
				bean.setMsg(rs.getString(3));
				bean.setMobileno(rs.getString(4));
				bean.setResno(rs.getString(5));
				records.put(jobID, bean);
			}
		} finally{
			dbManager.close(rs);
			dbManager.close(ps);
		}
	}

	@Override
	public void preprocess() {

	}

}
