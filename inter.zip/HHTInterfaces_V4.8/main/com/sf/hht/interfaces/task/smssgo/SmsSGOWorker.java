package com.sf.hht.interfaces.task.smssgo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.task.smssgo.dto.SGOData;

public class SmsSGOWorker extends TaskWorker {
	
	private static final Logger LOG = Logger.getLogger(SmsSGOWorker.class);
	
	
	// 查询SGO数据
	private static final String SQL_SMS_SGO = "select rowid, mobileno, msg, recvdate, recvtime from recvmsg where substr(msg, 1, 9) = ? and rownum < ?";
	// 按jobid删除smsreturncode记录
	private static final String SQL_DEL_SMS_RETURN_CODE = "delete from smsreturncode where jobid = ?";
	// 插入数据到smsreturncode
	private static final String SQL_INS_SMS_RETURN_CODE = "insert into smsreturncode(jobid, recvtime, sended, returncode) values(?, to_date(?, 'yyyy-mm-dd hh24:mi:ss'), 0, 0)";
	// 按rowid删除SGO数据
	private static final String SQL_DEL_SMS_SGO = "delete from recvmsg where rowid = ?";
	
	
	// SGO信息头
	private static final String SGO_HEADER = "HHTIBMSGO";
	// 每次处理数据量
	private static final int DEFAULT_FETCH_SIZE = 100;
	// 分隔符
	private static final String SEPARATOR = "|";
	
	
	// HHT数据源
	private DBManager hhtDBManager;
	// SMS数据库
	private DBManager smsDBManager;

	public void setHhtDBManager(DBManager hhtDBManager) {
		this.hhtDBManager = hhtDBManager;
	}

	public void setSmsDBManager(DBManager smsDBManager) {
		this.smsDBManager = smsDBManager;
	}



	/**
	 * 方法入口
	 * description
	 * Mar 2, 2012
	 */
	protected void execute(){
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("SmsSGOWorker[").append(Thread.currentThread().getId()).append("]");
		
		LOG.info(logPrefix.toString() + " start");
		
		while(running){
			try{
				// 处理SGO数据
				handleRecords(logPrefix.toString());
				// 线程休眠
				makeWait(task.getPeriod());
			}catch(Exception e){
				LOG.error("SmsSGOWorker Exception Occured", e);
			}
		}
		
		LOG.info(logPrefix + " end");
		
	}
	
	/**
	 * 处理数据
	 * Mar 2, 2012
	 * @param logPrefix
	 * @return
	 */
	private void handleRecords(String logPrefix){
		Connection hhtConn = null;
		Connection smsConn = null;
		
		try{
			hhtConn = hhtDBManager.getConnection();
			smsConn = smsDBManager.getConnection();
			hhtConn.setAutoCommit(false);
			smsConn.setAutoCommit(false);
			
			// 检索SGO数据
			List<SGOData> list = querySGO(smsConn);
			
			String jobId = null;
			for(SGOData sgoData : list){
				try{
					jobId = sgoData.getJobid();
					
					// 根据jobid删除smsreturncode对应数据
					delSmsReturnCode(jobId, hhtConn);
					// 新增smsreturncode数据
					addSmsReturnCode(sgoData, hhtConn);
					
					// 根据rowid删除recvmsg对应数据
					delSmsSGO(sgoData.getRowid(), smsConn);
					
					// 提交事务
					hhtConn.commit();
					smsConn.commit();
					
					if(LOG.isDebugEnabled()){
						LOG.debug("Saved SGO data successfully! jobid--"+jobId);
					}
					
				}catch(Exception e){
					LOG.error("Saved SGO data failure! jobid--"+jobId + ", exception : ", e);
					
					// 数据回滚
					try{
						if(hhtConn != null){
							hhtConn.rollback();
						}
						if(smsConn != null){
							smsConn.rollback();
						}
					}catch(SQLException hhtSe){
						LOG.error("hht database rollback exception : "+e);
					}
				}
			}
			
			LOG.info(logPrefix + "--Handled " + list.size() + " record(s)");
			
		}catch(Exception e){
			LOG.error("Exception Occured when getting connection", e);
			e.printStackTrace();
		}finally{
			try{
				if(hhtConn != null){
					hhtConn.setAutoCommit(true);
				}
				if(smsConn != null){
					smsConn.setAutoCommit(true);
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
			// 关闭数据库连接
			hhtDBManager.close(hhtConn);
			smsDBManager.close(smsConn);
		}
	}
	
	/**
	 * 批量查询SGO数据
	 * Mar 2, 2012
	 */
	private List<SGOData> querySGO(Connection conn){
		// SGO对象集合
		List<SGOData> list = new ArrayList<SGOData>();
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try{
			pstmt = conn.prepareStatement(SQL_SMS_SGO);
			
			pstmt.setString(1, SGO_HEADER);
			// 每次检索数据量
			if(task.getRecordSize() > 0){
				pstmt.setInt(2, task.getRecordSize()+1);
			}else{
				pstmt.setInt(2, DEFAULT_FETCH_SIZE+1);
			}
			
			rs = pstmt.executeQuery();
			
			String jobId = null;
			String msg = null;
			String msgRecvtime = null;
			String rowid = null;
			
			while(rs.next()){
				rowid = rs.getString("rowid");	// 行id
				msg = rs.getString("msg");		// 消息内容
				
				try{
					if(msg != null){
						// msg 格式：HHTIBMSGO|120223166220017|2012-02-23 15:51:10
						jobId = msg.substring(msg.indexOf(SEPARATOR) + 1, msg.lastIndexOf(SEPARATOR));	// jobid
						msgRecvtime = msg.substring(msg.lastIndexOf(SEPARATOR) + 1);	// 消息接收时间
						if("".equals(jobId)){
							LOG.error("jobid is null, msg="+ msg + ", rowid="+ rowid);
							continue;
						}
					}else{
						LOG.error("msg is null, rowid="+rowid);
						continue;
					}
				}catch(IndexOutOfBoundsException e){
					LOG.error("wrong msg format, msg="+ msg + ", rowid="+ rowid + ", exception:"+ e);
					continue;
				}
				
				// 封装SGO数据
				SGOData sgoData = new SGOData();
				sgoData.setRowid(rowid);
				sgoData.setJobid(jobId);
				sgoData.setRecvtime(msgRecvtime);
				list.add(sgoData);
			}
		}catch(Exception e){
			LOG.error("SGO data query exception : "+e);
			e.printStackTrace();
		}finally{
			smsDBManager.close(rs);
			smsDBManager.close(pstmt);
		}
		return list;
	}
	
	/**
	 * 按jobid删除smsreturncode对应记录
	 * Mar 2, 2012
	 * @param jobId
	 * @param conn
	 * @throws SQLException 
	 */
	private void delSmsReturnCode(String jobId, Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		
		try{
			pstmt = conn.prepareStatement(SQL_DEL_SMS_RETURN_CODE);
			pstmt.setString(1, jobId);
			
			pstmt.executeUpdate();
			
		} finally{
			hhtDBManager.close(pstmt);
		}
	}
	
	/**
	 * 插入smsreturncode数据
	 * Mar 2, 2012
	 * @param sgoData
	 * @param conn
	 * @throws SQLException 
	 */
	private void addSmsReturnCode(SGOData sgoData, Connection conn) throws SQLException{
		PreparedStatement pstmt = null; 
			
		try{
			pstmt = conn.prepareStatement(SQL_INS_SMS_RETURN_CODE);
			pstmt.setString(1, sgoData.getJobid());
			pstmt.setString(2, sgoData.getRecvtime());
			
			pstmt.executeUpdate();
			
		}finally{
			hhtDBManager.close(pstmt);
		}
	}
	
	/**
	 * 按照rowid删除SGO对应数据
	 * Mar 3, 2012
	 * @param rowid
	 * @return
	 * @throws SQLException 
	 */
	private void delSmsSGO(String rowid, Connection conn) throws SQLException{
		
		PreparedStatement pstmt = null;
		
		try{
			pstmt = conn.prepareStatement(SQL_DEL_SMS_SGO);
			pstmt.setString(1, rowid);
			
			pstmt.executeUpdate();
			
		}finally{
			smsDBManager.close(pstmt);
		}
	}

	@Override
	public void preprocess() {}
	
}
