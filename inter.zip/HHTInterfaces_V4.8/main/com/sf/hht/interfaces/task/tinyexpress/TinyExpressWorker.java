package com.sf.hht.interfaces.task.tinyexpress;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.rpc.ServiceException;

import org.apache.log4j.Logger;

import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.task.tinyexpress.ws.ICmsQueryServiceServiceLocator;

public class TinyExpressWorker extends TaskWorker{
	private static final Logger LOG = Logger.getLogger(TinyExpressWorker.class);
	
	private static final SimpleDateFormat SDF_YMD_HMS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private static final String SQL_INSERT_TINY_EXPRESS = "insert into pd_tiny_express(id, dept_code) values(SEQ_PD_ID.NEXTVAL,?)";
	private static final String SQL_DELETE_TINY_EXPRESS = "delete from pd_tiny_express";
	
	private DBManager dbManager;
	// WebService地址
	private String wsUrl;
	// 每天同步开始时间
	private int syncHour;
	
	@Override
	public void preprocess() {
	}

	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("TinyExpressWorker[").append(Thread.currentThread().getId()).append("]");
		
		LOG.info(logPrefix.toString() + " start");
		
		boolean isComplete = false;
		
		while(running){
			try {
				if (!runTask()) {
					isComplete = false;
					makeWait(task.getPeriod());
					continue;
				}else {
					if (isComplete) {
						makeWait(task.getPeriod());
						continue;
					}
				}
				
				receive();
				isComplete = true;
			} catch (Exception e) {
				LOG.error("TinyExpressWorker sync data exception", e);
			}
		}
		
		LOG.info(logPrefix + " end");
	}

	/**
	 * 接收并且保存数据
	 * Apr 25, 2013
	 */
	private void receive(){
		Connection conn = null;
		
		String deptCodes = loadRecords();
		
		try {
			conn = dbManager.getConnection();
			conn.setAutoCommit(false);
			
			if (deptCodes != null && deptCodes.trim().length() > 0) {
				// 删除所有微小件网点
				deleteTinyExpress(conn);
				
				String[] deptCodeArr = deptCodes.split(",");
				
				// 保存所有微小件网点
				insertTinyExpress(conn, deptCodeArr);
				
				LOG.info("TinyExpressWorker save tiny express dept successfully, deptCodes->"+deptCodes);
			}else {
				LOG.info("TinyExpressWorker call webservice response null");
			}
			
			conn.commit();
		} catch (Exception e) {
			try {
				// 数据回滚
				conn.rollback();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			
			e.printStackTrace();
			LOG.error("TinyExpressWorker receive data exception ", e);
		}finally{
			try {
				if (conn != null) {
					conn.setAutoCommit(true);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			dbManager.close(conn);
		}
	}
	
	/**
	 * 通过Webservice获取所有微小件网点
	 * Apr 25, 2013
	 * @return
	 */
	private String loadRecords(){
		String deptCodes = null;
		
		try {
			LOG.info("TinyExpressWorker webservice call start time : " + SDF_YMD_HMS.format(new Date()));
			
			// 通过webservice获取所有微小件网点
			ICmsQueryServiceServiceLocator service = new ICmsQueryServiceServiceLocator();
			deptCodes = service.getICmsQueryServicePort(new URL(wsUrl)).queryTinyExpressZones();
			
			LOG.info("TinyExpressWorker webservice call end time : " + SDF_YMD_HMS.format(new Date()));
		} catch (RemoteException e) {
			e.printStackTrace();
			LOG.error("TinyExpressWorker webService call failure, RemoteException", e);
		} catch (MalformedURLException e) {
			e.printStackTrace();
			LOG.error("TinyExpressWorker webService call failure, MalformedURLException", e);
		} catch (ServiceException e) {
			e.printStackTrace();
			LOG.error("TinyExpressWorker webService call failure, ServiceException", e);
		}
		
		return deptCodes;
	}
	
	/**
	 * 微小件网点数据保存到数据库
	 * Apr 25, 2013
	 * @param conn
	 * @param deptCodes
	 * @throws SQLException
	 */
	private void insertTinyExpress(Connection conn, String[] deptCodes) throws SQLException{
		PreparedStatement pstmt = null;
		
		try{
			if (deptCodes != null && deptCodes.length > 0) {
				pstmt = conn.prepareStatement(SQL_INSERT_TINY_EXPRESS);
				
				for (String deptCode : deptCodes) {
					pstmt.setString(1, deptCode);
					pstmt.addBatch();
				}
				
				pstmt.executeBatch();
			}
		}finally{
			dbManager.close(pstmt);
		}
		
	}
	
	/**
	 * 删除所有微小件网点数据
	 * Apr 25, 2013
	 * @param conn
	 * @throws SQLException
	 */
	private void deleteTinyExpress(Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(SQL_DELETE_TINY_EXPRESS);
			pstmt.executeUpdate();
		} finally {
			dbManager.close(pstmt);
		}
	}
	
	/**
	 * 判断任务是否应该执行
	 * Apr 25, 2013
	 * @return
	 */
	private boolean runTask(){
		Calendar curDate = Calendar.getInstance();
		
		int hour = curDate.get(Calendar.HOUR_OF_DAY);
		
		if(hour == syncHour){
			return true;
		}
		
		return false;
	}
	
	/***************** get/set方法 ****************/
	public void setSyncHour(int syncHour) {
		this.syncHour = syncHour;
	}

	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}

	public void setWsUrl(String wsUrl) {
		this.wsUrl = wsUrl;
	}
}
