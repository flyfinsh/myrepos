/**
 * CustomerDto.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.task.tinyexpress.ws;

public class CustomerDto  extends com.sf.hht.interfaces.task.tinyexpress.ws.BaseEntity  implements java.io.Serializable {
    private java.util.Calendar accountAvailableDt;
    private java.util.Calendar changeZoneDt;
    private java.lang.String createdEmpCode;
    private java.util.Calendar createdTm;
    private java.lang.String custAddr;
    private java.lang.String custCode;
    private java.lang.String custName;
    private java.lang.String custPost;
    private java.lang.String custTel;
    private java.lang.String custTypeCode;
    private java.lang.String deptCode;
    private java.lang.String dunCode;
    private java.lang.String effectTimeControlLevel;
    private java.lang.Boolean groupCustFlg;
    private java.lang.String hhtTips;
    private java.lang.Integer isAvoidRecordBill;
    private java.lang.Integer isDt900Check;
    private java.lang.Integer isElectCustomer;
    private java.lang.Integer isElectSupplier;
    private java.lang.Integer isElectSupplierProj;
    private java.lang.Integer isOverStrainReturnPremium;
    private java.lang.Integer isSfbankPay;
    private java.lang.String linkName;
    private java.util.Calendar logoutDt;
    private java.lang.Integer messageTips;
    private java.lang.String modifiedEmpCode;
    private java.util.Calendar modifiedTm;
    private java.lang.String principal;
    private java.util.Calendar registerDt;
    private java.lang.Integer tidValueUpperLimit;
    private java.lang.Boolean validFlg;
    private java.lang.String vindicatorCode;
    private java.lang.String vipCode;

    public CustomerDto() {
    }

    public java.util.Calendar getAccountAvailableDt() {
        return accountAvailableDt;
    }

    public void setAccountAvailableDt(java.util.Calendar accountAvailableDt) {
        this.accountAvailableDt = accountAvailableDt;
    }

    public java.util.Calendar getChangeZoneDt() {
        return changeZoneDt;
    }

    public void setChangeZoneDt(java.util.Calendar changeZoneDt) {
        this.changeZoneDt = changeZoneDt;
    }

    public java.lang.String getCreatedEmpCode() {
        return createdEmpCode;
    }

    public void setCreatedEmpCode(java.lang.String createdEmpCode) {
        this.createdEmpCode = createdEmpCode;
    }

    public java.util.Calendar getCreatedTm() {
        return createdTm;
    }

    public void setCreatedTm(java.util.Calendar createdTm) {
        this.createdTm = createdTm;
    }

    public java.lang.String getCustAddr() {
        return custAddr;
    }

    public void setCustAddr(java.lang.String custAddr) {
        this.custAddr = custAddr;
    }

    public java.lang.String getCustCode() {
        return custCode;
    }

    public void setCustCode(java.lang.String custCode) {
        this.custCode = custCode;
    }

    public java.lang.String getCustName() {
        return custName;
    }

    public void setCustName(java.lang.String custName) {
        this.custName = custName;
    }

    public java.lang.String getCustPost() {
        return custPost;
    }

    public void setCustPost(java.lang.String custPost) {
        this.custPost = custPost;
    }

    public java.lang.String getCustTel() {
        return custTel;
    }

    public void setCustTel(java.lang.String custTel) {
        this.custTel = custTel;
    }

    public java.lang.String getCustTypeCode() {
        return custTypeCode;
    }

    public void setCustTypeCode(java.lang.String custTypeCode) {
        this.custTypeCode = custTypeCode;
    }

    public java.lang.String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(java.lang.String deptCode) {
        this.deptCode = deptCode;
    }

    public java.lang.String getDunCode() {
        return dunCode;
    }

    public void setDunCode(java.lang.String dunCode) {
        this.dunCode = dunCode;
    }

    public java.lang.String getEffectTimeControlLevel() {
        return effectTimeControlLevel;
    }

    public void setEffectTimeControlLevel(java.lang.String effectTimeControlLevel) {
        this.effectTimeControlLevel = effectTimeControlLevel;
    }

    public java.lang.Boolean getGroupCustFlg() {
        return groupCustFlg;
    }

    public void setGroupCustFlg(java.lang.Boolean groupCustFlg) {
        this.groupCustFlg = groupCustFlg;
    }

    public java.lang.String getHhtTips() {
        return hhtTips;
    }

    public void setHhtTips(java.lang.String hhtTips) {
        this.hhtTips = hhtTips;
    }

    public java.lang.Integer getIsAvoidRecordBill() {
        return isAvoidRecordBill;
    }

    public void setIsAvoidRecordBill(java.lang.Integer isAvoidRecordBill) {
        this.isAvoidRecordBill = isAvoidRecordBill;
    }

    public java.lang.Integer getIsDt900Check() {
        return isDt900Check;
    }

    public void setIsDt900Check(java.lang.Integer isDt900Check) {
        this.isDt900Check = isDt900Check;
    }

    public java.lang.Integer getIsElectCustomer() {
        return isElectCustomer;
    }

    public void setIsElectCustomer(java.lang.Integer isElectCustomer) {
        this.isElectCustomer = isElectCustomer;
    }

    public java.lang.Integer getIsElectSupplier() {
        return isElectSupplier;
    }

    public void setIsElectSupplier(java.lang.Integer isElectSupplier) {
        this.isElectSupplier = isElectSupplier;
    }

    public java.lang.Integer getIsElectSupplierProj() {
        return isElectSupplierProj;
    }

    public void setIsElectSupplierProj(java.lang.Integer isElectSupplierProj) {
        this.isElectSupplierProj = isElectSupplierProj;
    }

    public java.lang.Integer getIsOverStrainReturnPremium() {
        return isOverStrainReturnPremium;
    }

    public void setIsOverStrainReturnPremium(java.lang.Integer isOverStrainReturnPremium) {
        this.isOverStrainReturnPremium = isOverStrainReturnPremium;
    }

    public java.lang.Integer getIsSfbankPay() {
        return isSfbankPay;
    }

    public void setIsSfbankPay(java.lang.Integer isSfbankPay) {
        this.isSfbankPay = isSfbankPay;
    }

    public java.lang.String getLinkName() {
        return linkName;
    }

    public void setLinkName(java.lang.String linkName) {
        this.linkName = linkName;
    }

    public java.util.Calendar getLogoutDt() {
        return logoutDt;
    }

    public void setLogoutDt(java.util.Calendar logoutDt) {
        this.logoutDt = logoutDt;
    }

    public java.lang.Integer getMessageTips() {
        return messageTips;
    }

    public void setMessageTips(java.lang.Integer messageTips) {
        this.messageTips = messageTips;
    }

    public java.lang.String getModifiedEmpCode() {
        return modifiedEmpCode;
    }

    public void setModifiedEmpCode(java.lang.String modifiedEmpCode) {
        this.modifiedEmpCode = modifiedEmpCode;
    }

    public java.util.Calendar getModifiedTm() {
        return modifiedTm;
    }

    public void setModifiedTm(java.util.Calendar modifiedTm) {
        this.modifiedTm = modifiedTm;
    }

    public java.lang.String getPrincipal() {
        return principal;
    }

    public void setPrincipal(java.lang.String principal) {
        this.principal = principal;
    }

    public java.util.Calendar getRegisterDt() {
        return registerDt;
    }

    public void setRegisterDt(java.util.Calendar registerDt) {
        this.registerDt = registerDt;
    }

    public java.lang.Integer getTidValueUpperLimit() {
        return tidValueUpperLimit;
    }

    public void setTidValueUpperLimit(java.lang.Integer tidValueUpperLimit) {
        this.tidValueUpperLimit = tidValueUpperLimit;
    }

    public java.lang.Boolean getValidFlg() {
        return validFlg;
    }

    public void setValidFlg(java.lang.Boolean validFlg) {
        this.validFlg = validFlg;
    }

    public java.lang.String getVindicatorCode() {
        return vindicatorCode;
    }

    public void setVindicatorCode(java.lang.String vindicatorCode) {
        this.vindicatorCode = vindicatorCode;
    }

    public java.lang.String getVipCode() {
        return vipCode;
    }

    public void setVipCode(java.lang.String vipCode) {
        this.vipCode = vipCode;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CustomerDto)) return false;
        CustomerDto other = (CustomerDto) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((accountAvailableDt==null && other.getAccountAvailableDt()==null) || 
             (accountAvailableDt!=null &&
              accountAvailableDt.equals(other.getAccountAvailableDt()))) &&
            ((changeZoneDt==null && other.getChangeZoneDt()==null) || 
             (changeZoneDt!=null &&
              changeZoneDt.equals(other.getChangeZoneDt()))) &&
            ((createdEmpCode==null && other.getCreatedEmpCode()==null) || 
             (createdEmpCode!=null &&
              createdEmpCode.equals(other.getCreatedEmpCode()))) &&
            ((createdTm==null && other.getCreatedTm()==null) || 
             (createdTm!=null &&
              createdTm.equals(other.getCreatedTm()))) &&
            ((custAddr==null && other.getCustAddr()==null) || 
             (custAddr!=null &&
              custAddr.equals(other.getCustAddr()))) &&
            ((custCode==null && other.getCustCode()==null) || 
             (custCode!=null &&
              custCode.equals(other.getCustCode()))) &&
            ((custName==null && other.getCustName()==null) || 
             (custName!=null &&
              custName.equals(other.getCustName()))) &&
            ((custPost==null && other.getCustPost()==null) || 
             (custPost!=null &&
              custPost.equals(other.getCustPost()))) &&
            ((custTel==null && other.getCustTel()==null) || 
             (custTel!=null &&
              custTel.equals(other.getCustTel()))) &&
            ((custTypeCode==null && other.getCustTypeCode()==null) || 
             (custTypeCode!=null &&
              custTypeCode.equals(other.getCustTypeCode()))) &&
            ((deptCode==null && other.getDeptCode()==null) || 
             (deptCode!=null &&
              deptCode.equals(other.getDeptCode()))) &&
            ((dunCode==null && other.getDunCode()==null) || 
             (dunCode!=null &&
              dunCode.equals(other.getDunCode()))) &&
            ((effectTimeControlLevel==null && other.getEffectTimeControlLevel()==null) || 
             (effectTimeControlLevel!=null &&
              effectTimeControlLevel.equals(other.getEffectTimeControlLevel()))) &&
            ((groupCustFlg==null && other.getGroupCustFlg()==null) || 
             (groupCustFlg!=null &&
              groupCustFlg.equals(other.getGroupCustFlg()))) &&
            ((hhtTips==null && other.getHhtTips()==null) || 
             (hhtTips!=null &&
              hhtTips.equals(other.getHhtTips()))) &&
            ((isAvoidRecordBill==null && other.getIsAvoidRecordBill()==null) || 
             (isAvoidRecordBill!=null &&
              isAvoidRecordBill.equals(other.getIsAvoidRecordBill()))) &&
            ((isDt900Check==null && other.getIsDt900Check()==null) || 
             (isDt900Check!=null &&
              isDt900Check.equals(other.getIsDt900Check()))) &&
            ((isElectCustomer==null && other.getIsElectCustomer()==null) || 
             (isElectCustomer!=null &&
              isElectCustomer.equals(other.getIsElectCustomer()))) &&
            ((isElectSupplier==null && other.getIsElectSupplier()==null) || 
             (isElectSupplier!=null &&
              isElectSupplier.equals(other.getIsElectSupplier()))) &&
            ((isElectSupplierProj==null && other.getIsElectSupplierProj()==null) || 
             (isElectSupplierProj!=null &&
              isElectSupplierProj.equals(other.getIsElectSupplierProj()))) &&
            ((isOverStrainReturnPremium==null && other.getIsOverStrainReturnPremium()==null) || 
             (isOverStrainReturnPremium!=null &&
              isOverStrainReturnPremium.equals(other.getIsOverStrainReturnPremium()))) &&
            ((isSfbankPay==null && other.getIsSfbankPay()==null) || 
             (isSfbankPay!=null &&
              isSfbankPay.equals(other.getIsSfbankPay()))) &&
            ((linkName==null && other.getLinkName()==null) || 
             (linkName!=null &&
              linkName.equals(other.getLinkName()))) &&
            ((logoutDt==null && other.getLogoutDt()==null) || 
             (logoutDt!=null &&
              logoutDt.equals(other.getLogoutDt()))) &&
            ((messageTips==null && other.getMessageTips()==null) || 
             (messageTips!=null &&
              messageTips.equals(other.getMessageTips()))) &&
            ((modifiedEmpCode==null && other.getModifiedEmpCode()==null) || 
             (modifiedEmpCode!=null &&
              modifiedEmpCode.equals(other.getModifiedEmpCode()))) &&
            ((modifiedTm==null && other.getModifiedTm()==null) || 
             (modifiedTm!=null &&
              modifiedTm.equals(other.getModifiedTm()))) &&
            ((principal==null && other.getPrincipal()==null) || 
             (principal!=null &&
              principal.equals(other.getPrincipal()))) &&
            ((registerDt==null && other.getRegisterDt()==null) || 
             (registerDt!=null &&
              registerDt.equals(other.getRegisterDt()))) &&
            ((tidValueUpperLimit==null && other.getTidValueUpperLimit()==null) || 
             (tidValueUpperLimit!=null &&
              tidValueUpperLimit.equals(other.getTidValueUpperLimit()))) &&
            ((validFlg==null && other.getValidFlg()==null) || 
             (validFlg!=null &&
              validFlg.equals(other.getValidFlg()))) &&
            ((vindicatorCode==null && other.getVindicatorCode()==null) || 
             (vindicatorCode!=null &&
              vindicatorCode.equals(other.getVindicatorCode()))) &&
            ((vipCode==null && other.getVipCode()==null) || 
             (vipCode!=null &&
              vipCode.equals(other.getVipCode())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAccountAvailableDt() != null) {
            _hashCode += getAccountAvailableDt().hashCode();
        }
        if (getChangeZoneDt() != null) {
            _hashCode += getChangeZoneDt().hashCode();
        }
        if (getCreatedEmpCode() != null) {
            _hashCode += getCreatedEmpCode().hashCode();
        }
        if (getCreatedTm() != null) {
            _hashCode += getCreatedTm().hashCode();
        }
        if (getCustAddr() != null) {
            _hashCode += getCustAddr().hashCode();
        }
        if (getCustCode() != null) {
            _hashCode += getCustCode().hashCode();
        }
        if (getCustName() != null) {
            _hashCode += getCustName().hashCode();
        }
        if (getCustPost() != null) {
            _hashCode += getCustPost().hashCode();
        }
        if (getCustTel() != null) {
            _hashCode += getCustTel().hashCode();
        }
        if (getCustTypeCode() != null) {
            _hashCode += getCustTypeCode().hashCode();
        }
        if (getDeptCode() != null) {
            _hashCode += getDeptCode().hashCode();
        }
        if (getDunCode() != null) {
            _hashCode += getDunCode().hashCode();
        }
        if (getEffectTimeControlLevel() != null) {
            _hashCode += getEffectTimeControlLevel().hashCode();
        }
        if (getGroupCustFlg() != null) {
            _hashCode += getGroupCustFlg().hashCode();
        }
        if (getHhtTips() != null) {
            _hashCode += getHhtTips().hashCode();
        }
        if (getIsAvoidRecordBill() != null) {
            _hashCode += getIsAvoidRecordBill().hashCode();
        }
        if (getIsDt900Check() != null) {
            _hashCode += getIsDt900Check().hashCode();
        }
        if (getIsElectCustomer() != null) {
            _hashCode += getIsElectCustomer().hashCode();
        }
        if (getIsElectSupplier() != null) {
            _hashCode += getIsElectSupplier().hashCode();
        }
        if (getIsElectSupplierProj() != null) {
            _hashCode += getIsElectSupplierProj().hashCode();
        }
        if (getIsOverStrainReturnPremium() != null) {
            _hashCode += getIsOverStrainReturnPremium().hashCode();
        }
        if (getIsSfbankPay() != null) {
            _hashCode += getIsSfbankPay().hashCode();
        }
        if (getLinkName() != null) {
            _hashCode += getLinkName().hashCode();
        }
        if (getLogoutDt() != null) {
            _hashCode += getLogoutDt().hashCode();
        }
        if (getMessageTips() != null) {
            _hashCode += getMessageTips().hashCode();
        }
        if (getModifiedEmpCode() != null) {
            _hashCode += getModifiedEmpCode().hashCode();
        }
        if (getModifiedTm() != null) {
            _hashCode += getModifiedTm().hashCode();
        }
        if (getPrincipal() != null) {
            _hashCode += getPrincipal().hashCode();
        }
        if (getRegisterDt() != null) {
            _hashCode += getRegisterDt().hashCode();
        }
        if (getTidValueUpperLimit() != null) {
            _hashCode += getTidValueUpperLimit().hashCode();
        }
        if (getValidFlg() != null) {
            _hashCode += getValidFlg().hashCode();
        }
        if (getVindicatorCode() != null) {
            _hashCode += getVindicatorCode().hashCode();
        }
        if (getVipCode() != null) {
            _hashCode += getVipCode().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CustomerDto.class);

    static {
        org.apache.axis.description.FieldDesc field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("accountAvailableDt");
        field.setXmlName(new javax.xml.namespace.QName("", "accountAvailableDt"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("changeZoneDt");
        field.setXmlName(new javax.xml.namespace.QName("", "changeZoneDt"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("createdEmpCode");
        field.setXmlName(new javax.xml.namespace.QName("", "createdEmpCode"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("createdTm");
        field.setXmlName(new javax.xml.namespace.QName("", "createdTm"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("custAddr");
        field.setXmlName(new javax.xml.namespace.QName("", "custAddr"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("custCode");
        field.setXmlName(new javax.xml.namespace.QName("", "custCode"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("custName");
        field.setXmlName(new javax.xml.namespace.QName("", "custName"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("custPost");
        field.setXmlName(new javax.xml.namespace.QName("", "custPost"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("custTel");
        field.setXmlName(new javax.xml.namespace.QName("", "custTel"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("custTypeCode");
        field.setXmlName(new javax.xml.namespace.QName("", "custTypeCode"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("deptCode");
        field.setXmlName(new javax.xml.namespace.QName("", "deptCode"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("dunCode");
        field.setXmlName(new javax.xml.namespace.QName("", "dunCode"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("effectTimeControlLevel");
        field.setXmlName(new javax.xml.namespace.QName("", "effectTimeControlLevel"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("groupCustFlg");
        field.setXmlName(new javax.xml.namespace.QName("", "groupCustFlg"));
        field.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "boolean"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("hhtTips");
        field.setXmlName(new javax.xml.namespace.QName("", "hhtTips"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("isAvoidRecordBill");
        field.setXmlName(new javax.xml.namespace.QName("", "isAvoidRecordBill"));
        field.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "int"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("isDt900Check");
        field.setXmlName(new javax.xml.namespace.QName("", "isDt900Check"));
        field.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "int"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("isElectCustomer");
        field.setXmlName(new javax.xml.namespace.QName("", "isElectCustomer"));
        field.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "int"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("isElectSupplier");
        field.setXmlName(new javax.xml.namespace.QName("", "isElectSupplier"));
        field.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "int"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("isElectSupplierProj");
        field.setXmlName(new javax.xml.namespace.QName("", "isElectSupplierProj"));
        field.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "int"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("isOverStrainReturnPremium");
        field.setXmlName(new javax.xml.namespace.QName("", "isOverStrainReturnPremium"));
        field.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "int"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("isSfbankPay");
        field.setXmlName(new javax.xml.namespace.QName("", "isSfbankPay"));
        field.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "int"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("linkName");
        field.setXmlName(new javax.xml.namespace.QName("", "linkName"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("logoutDt");
        field.setXmlName(new javax.xml.namespace.QName("", "logoutDt"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("messageTips");
        field.setXmlName(new javax.xml.namespace.QName("", "messageTips"));
        field.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "int"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("modifiedEmpCode");
        field.setXmlName(new javax.xml.namespace.QName("", "modifiedEmpCode"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("modifiedTm");
        field.setXmlName(new javax.xml.namespace.QName("", "modifiedTm"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("principal");
        field.setXmlName(new javax.xml.namespace.QName("", "principal"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("registerDt");
        field.setXmlName(new javax.xml.namespace.QName("", "registerDt"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("tidValueUpperLimit");
        field.setXmlName(new javax.xml.namespace.QName("", "tidValueUpperLimit"));
        field.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "int"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("validFlg");
        field.setXmlName(new javax.xml.namespace.QName("", "validFlg"));
        field.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "boolean"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("vindicatorCode");
        field.setXmlName(new javax.xml.namespace.QName("", "vindicatorCode"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("vipCode");
        field.setXmlName(new javax.xml.namespace.QName("", "vipCode"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
    };

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
