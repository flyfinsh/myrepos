/**
 * ICmsQueryService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.task.tinyexpress.ws;

public interface ICmsQueryService extends java.rmi.Remote {
    public java.lang.String queryTinyExpressZones() throws java.rmi.RemoteException;
    public java.lang.String queryCustomBatchCode(java.lang.String arg0, java.lang.String arg1, java.util.Calendar arg2) throws java.rmi.RemoteException;
    public com.sf.hht.interfaces.task.tinyexpress.ws.CustomerDto queryCustomerInfo(java.lang.String arg0) throws java.rmi.RemoteException;
}
