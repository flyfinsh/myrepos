package com.sf.hht.interfaces.task.virtualaddress;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.rpc.ServiceException;

import org.apache.log4j.Logger;

import com.sf.hht.interfaces.skeleton.core.TaskWorker;
import com.sf.hht.interfaces.skeleton.resource.DBManager;
import com.sf.hht.interfaces.task.virtualaddress.ws.BusinessStoreProvideServiceLocator;
import com.sf.hht.interfaces.task.virtualaddress.ws.BusinessStoreResult;
import com.sf.hht.interfaces.task.virtualaddress.ws.Store;

public class VirtualAddressWorker extends TaskWorker {
	private static final Logger LOG = Logger.getLogger(VirtualAddressWorker.class);
	
	private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	private static final String SQL_INSER_VIRTUAL_ADDRESS = "insert into pd_virtual_address(id, code, name, store_type, linkman, address, tel, service_time, service_content, dept_code, lng, lat, remark, create_tm) values(SEQ_PD_VIRTUAL_ADDRESS_ID.nextval,?,?,?,?,?,?,?,?,?,?,?,?,sysdate)";
	private static final String SQL_DELETE_VIRTUAL_ADDRESS = "delete from pd_virtual_address";
	private static final int STATUS_SUCCESS_CODE = 1;
	
	private DBManager dbManager;
	// WebService 地址
	private String wsUrl;
	// 每天同步开始时间
	private int syncHour;
	
	@Override
	protected void execute() {
		StringBuffer logPrefix = new StringBuffer();
		logPrefix.append("VirtualAddressWorker[").append(Thread.currentThread().getId()).append("]");
		
		LOG.info(logPrefix.toString() + " start");
		
		boolean isComplete = false;
		
		while (running) {
			try{
				if (!runTask()) {
					isComplete = false;
					makeWait(task.getPeriod());
					continue;
				}else {
					if (isComplete) {
						makeWait(task.getPeriod());
						continue;
					}
				}
				
				receive();
				isComplete = true;
			}catch (Exception e) {
				LOG.error("VirtualAddressWorker sync data exception", e);
			}
		}
		
		LOG.info(logPrefix + " end");
	}

	@Override
	public void preprocess() {
	}
	
	/**
	 * 接收数据
	 * 
	 * Feb 25, 2013
	 */
	private void receive(){
		Connection conn = null;
		
		BusinessStoreResult result = loadRecords();
		
		try{
			conn = dbManager.getConnection();
			conn.setAutoCommit(false);
			
			if (result != null){ 
				if(result.getStatus() == STATUS_SUCCESS_CODE) {
					// 删除所有数据
					delteBusinessStore(conn);
					
					// 获取所有数据
					Store[] stores = result.getStores();
					
					if (stores != null) {
						for (int i = 0; i < stores.length; i++) {
							Store store = stores[i];
							// 保存数据
							insertBusinessStore(conn, store);
						}
					}
					
					LOG.error("VirtualAddressWorker WebService response successfully, status: " + result.getStatus());
				}else {
					LOG.error("VirtualAddressWorker WebService response failure, status: " + result.getStatus());
				}
			}
			
			conn.commit();
		}catch (Exception e) {
			try {
				// 数据回滚
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			
			e.printStackTrace();
			LOG.error("VirtualAddressWorker receive data exception ", e);
		}finally{
			try {
				if (conn != null) {
					conn.setAutoCommit(true);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			dbManager.close(conn);
		}
	}
	
	/**
	 * 通过WebService获取数据
	 * 
	 * Feb 25, 2013
	 * @return
	 */
	private BusinessStoreResult loadRecords(){
		BusinessStoreResult result = null;
		
		try {
			LOG.info("VirtualAddressWorker WebService call start time : " + sdf.format(new Date()));
			
			// 通过WebService获取虚拟地址营业网点数据
			BusinessStoreProvideServiceLocator locator = new BusinessStoreProvideServiceLocator();
			result = locator.getBusinessStoreProvidePort(new URL(wsUrl)).searchAll();
			
			LOG.info("VirtualAddressWorker WebService call end time : " + sdf.format(new Date()));
		} catch (RemoteException e) {
			e.printStackTrace();
			LOG.error("VirtualAddressWorker WebService call failure, RemoteException", e);
		} catch (ServiceException e) {
			e.printStackTrace();
			LOG.error("VirtualAddressWorker WebService call failure, ServiceException", e);
		} catch (MalformedURLException e) {
			LOG.error("VirtualAddressWorker WebService call failure, MalformedURLException", e);
			e.printStackTrace();
		}
		
		return result;
	}
	
	/**
	 * 保存虚拟地址营业网点数据
	 * 
	 * Feb 25, 2013
	 * @param conn
	 * @param store
	 * @throws SQLException 
	 */
	private void insertBusinessStore(Connection conn, Store store) throws SQLException{
		PreparedStatement pstmt = null;
		
		try{
			pstmt = conn.prepareStatement(SQL_INSER_VIRTUAL_ADDRESS);
			pstmt.setString(1, store.getCode());
			pstmt.setString(2, store.getName());
			pstmt.setString(3, store.getStoreType());
			pstmt.setString(4, store.getLinkman());
			pstmt.setString(5, store.getAddress());
			pstmt.setString(6, store.getTel());
			pstmt.setString(7, store.getServiceTime());
			pstmt.setString(8, store.getServiceContent());
			pstmt.setString(9, store.getDeptCode());
			pstmt.setDouble(10, store.getLng());
			pstmt.setDouble(11, store.getLat());
			pstmt.setString(12, store.getRemark());
			
			pstmt.executeUpdate();
		}finally{
			dbManager.close(pstmt);
		}
	}
	
	/**
	 * 删除所有虚拟地址营业网点数据
	 * 
	 * Feb 25, 2013
	 * @param conn
	 * @throws SQLException
	 */
	private void delteBusinessStore(Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(SQL_DELETE_VIRTUAL_ADDRESS);
			
			pstmt.executeUpdate();
		}finally{
			dbManager.close(pstmt);
		}
		
	}
	
	private boolean runTask(){
		Calendar curDate = Calendar.getInstance();
		
		int hour = curDate.get(Calendar.HOUR_OF_DAY);
		
		if(hour == syncHour){
			return true;
		}
		
		return false;
	}

	/****************** get/set **********************/
	public void setDbManager(DBManager dbManager) {
		this.dbManager = dbManager;
	}

	public void setWsUrl(String wsUrl) {
		this.wsUrl = wsUrl;
	}

	public void setSyncHour(int syncHour) {
		this.syncHour = syncHour;
	}

	public static void main(String[] args) throws RemoteException, MalformedURLException, ServiceException {
		System.out.println(sdf.format(new Date()));
		// 通过WebService获取虚拟地址营业网点数据
		BusinessStoreProvideServiceLocator locator = new BusinessStoreProvideServiceLocator();
		BusinessStoreResult bsr = locator.getBusinessStoreProvidePort(new URL("http://10.0.23.190/sfmap/ws/businessStoreProvide")).searchAll();
		System.out.println(bsr.getStatus() + " : " +bsr.getStores().length);
		System.out.println(sdf.format(new Date()));
	}
}
