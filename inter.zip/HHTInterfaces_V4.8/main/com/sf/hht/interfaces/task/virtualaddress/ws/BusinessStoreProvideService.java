/**
 * BusinessStoreProvideService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.task.virtualaddress.ws;

public interface BusinessStoreProvideService extends javax.xml.rpc.Service {
    public java.lang.String getBusinessStoreProvidePortAddress();

    public com.sf.hht.interfaces.task.virtualaddress.ws.IBusinessStoreProvide getBusinessStoreProvidePort() throws javax.xml.rpc.ServiceException;

    public com.sf.hht.interfaces.task.virtualaddress.ws.IBusinessStoreProvide getBusinessStoreProvidePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
