/**
 * IBusinessStoreProvide.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.task.virtualaddress.ws;

public interface IBusinessStoreProvide extends java.rmi.Remote {
    public com.sf.hht.interfaces.task.virtualaddress.ws.BusinessStoreResult searchByBound(java.lang.Double arg0, java.lang.Double arg1, java.lang.Double arg2) throws java.rmi.RemoteException;
    public com.sf.hht.interfaces.task.virtualaddress.ws.BusinessStoreResult searchByCode(java.lang.String arg0) throws java.rmi.RemoteException;
    public com.sf.hht.interfaces.task.virtualaddress.ws.BusinessStoreResult searchAll() throws java.rmi.RemoteException;
    public com.sf.hht.interfaces.task.virtualaddress.ws.BusinessStoreResult searchAllSFStore() throws java.rmi.RemoteException;
}
