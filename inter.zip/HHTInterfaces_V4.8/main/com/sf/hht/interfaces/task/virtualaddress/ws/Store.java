/**
 * Store.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sf.hht.interfaces.task.virtualaddress.ws;

public class Store  extends com.sf.hht.interfaces.task.virtualaddress.ws.BaseEntity  implements java.io.Serializable {
    private java.lang.String address;
    private java.lang.String deptCode;
    private double lat;
    private java.lang.String linkman;
    private double lng;
    private java.lang.String name;
    private java.lang.String remark;
    private java.lang.String serviceContent;
    private java.lang.String serviceTime;
    private java.lang.String storeType;
    private java.lang.String tel;

    public Store() {
    }

    public java.lang.String getAddress() {
        return address;
    }

    public void setAddress(java.lang.String address) {
        this.address = address;
    }

    public java.lang.String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(java.lang.String deptCode) {
        this.deptCode = deptCode;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public java.lang.String getLinkman() {
        return linkman;
    }

    public void setLinkman(java.lang.String linkman) {
        this.linkman = linkman;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    public java.lang.String getName() {
        return name;
    }

    public void setName(java.lang.String name) {
        this.name = name;
    }

    public java.lang.String getRemark() {
        return remark;
    }

    public void setRemark(java.lang.String remark) {
        this.remark = remark;
    }

    public java.lang.String getServiceContent() {
        return serviceContent;
    }

    public void setServiceContent(java.lang.String serviceContent) {
        this.serviceContent = serviceContent;
    }

    public java.lang.String getServiceTime() {
        return serviceTime;
    }

    public void setServiceTime(java.lang.String serviceTime) {
        this.serviceTime = serviceTime;
    }

    public java.lang.String getStoreType() {
        return storeType;
    }

    public void setStoreType(java.lang.String storeType) {
        this.storeType = storeType;
    }

    public java.lang.String getTel() {
        return tel;
    }

    public void setTel(java.lang.String tel) {
        this.tel = tel;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Store)) return false;
        Store other = (Store) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((address==null && other.getAddress()==null) || 
             (address!=null &&
              address.equals(other.getAddress()))) &&
            ((deptCode==null && other.getDeptCode()==null) || 
             (deptCode!=null &&
              deptCode.equals(other.getDeptCode()))) &&
            lat == other.getLat() &&
            ((linkman==null && other.getLinkman()==null) || 
             (linkman!=null &&
              linkman.equals(other.getLinkman()))) &&
            lng == other.getLng() &&
            ((name==null && other.getName()==null) || 
             (name!=null &&
              name.equals(other.getName()))) &&
            ((remark==null && other.getRemark()==null) || 
             (remark!=null &&
              remark.equals(other.getRemark()))) &&
            ((serviceContent==null && other.getServiceContent()==null) || 
             (serviceContent!=null &&
              serviceContent.equals(other.getServiceContent()))) &&
            ((serviceTime==null && other.getServiceTime()==null) || 
             (serviceTime!=null &&
              serviceTime.equals(other.getServiceTime()))) &&
            ((storeType==null && other.getStoreType()==null) || 
             (storeType!=null &&
              storeType.equals(other.getStoreType()))) &&
            ((tel==null && other.getTel()==null) || 
             (tel!=null &&
              tel.equals(other.getTel())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAddress() != null) {
            _hashCode += getAddress().hashCode();
        }
        if (getDeptCode() != null) {
            _hashCode += getDeptCode().hashCode();
        }
        _hashCode += new Double(getLat()).hashCode();
        if (getLinkman() != null) {
            _hashCode += getLinkman().hashCode();
        }
        _hashCode += new Double(getLng()).hashCode();
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getRemark() != null) {
            _hashCode += getRemark().hashCode();
        }
        if (getServiceContent() != null) {
            _hashCode += getServiceContent().hashCode();
        }
        if (getServiceTime() != null) {
            _hashCode += getServiceTime().hashCode();
        }
        if (getStoreType() != null) {
            _hashCode += getStoreType().hashCode();
        }
        if (getTel() != null) {
            _hashCode += getTel().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Store.class);

    static {
        org.apache.axis.description.FieldDesc field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("address");
        field.setXmlName(new javax.xml.namespace.QName("", "address"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("deptCode");
        field.setXmlName(new javax.xml.namespace.QName("", "deptCode"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("lat");
        field.setXmlName(new javax.xml.namespace.QName("", "lat"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("linkman");
        field.setXmlName(new javax.xml.namespace.QName("", "linkman"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("lng");
        field.setXmlName(new javax.xml.namespace.QName("", "lng"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("name");
        field.setXmlName(new javax.xml.namespace.QName("", "name"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("remark");
        field.setXmlName(new javax.xml.namespace.QName("", "remark"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("serviceContent");
        field.setXmlName(new javax.xml.namespace.QName("", "serviceContent"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("serviceTime");
        field.setXmlName(new javax.xml.namespace.QName("", "serviceTime"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("storeType");
        field.setXmlName(new javax.xml.namespace.QName("", "storeType"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
        field = new org.apache.axis.description.ElementDesc();
        field.setFieldName("tel");
        field.setXmlName(new javax.xml.namespace.QName("", "tel"));
        field.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        field.setMinOccursIs0(true);
        typeDesc.addFieldDesc(field);
    };

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
