package com.sf.hht.interfaces.task.wanted;

import java.util.List;
import javax.jws.WebService;

@WebService
public interface WantedService {
	
	/**
	 * 保存通缉消息
	 * @param wanted 通缉对象
	 * @return 成功返回"1000"，失败返回"1001"，数据不合法返回"1002"
	 */
	public String pushWantedData(List<WantedTo> wantedToList);
	
}
