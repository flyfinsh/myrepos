package com.sf.hht.interfaces.task.wanted;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.List;

import javax.jws.WebService;

import org.apache.commons.lang.StringUtils;

import com.sf.hht.interfaces.skeleton.resource.DBManager;

@WebService(endpointInterface = "com.sf.hht.interfaces.task.wanted.WantedService")
public class WantedServiceImpl implements WantedService {

	// 成功
	private static final String SUCCESS = "1000";
	// 失败
	private static final String SYSERR = "1001";
	// 数据不合法
	private static final String DATA_NOT_AVAILABLE = "1002";

	private DBManager dbManager;

	/**
	 * 保存通缉消息
	 * @param wanted 通缉对象
	 * @return 成功返回"1000"，失败返回"1001"，数据不合法返回"1002"
	 */
	@Override
	public String pushWantedData(List<WantedTo> wantedToList) {
		if (!valid(wantedToList)) {
			System.out.println("Webservice WantedService request parameter not available");
			return DATA_NOT_AVAILABLE;
		}

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {

			String authSql = "select * from hht.operationparameter t  where t.PARAMETERID = 'AUTH_WANTED'";
			String sql = "insert into hht_wanted(ID, WAYBILL_NO, WANTED_CODE, WANTED, WANTED_EXTEND, RANGE, DATA_SOURCE) values(SEQ_WANTED_ID.NEXTVAL, ?, ?, ?, ?, ?, ?)";
			String badSql = "insert into hht_wanted_bad(ID, WAYBILL_NO, WANTED_CODE, WANTED, WANTED_EXTEND, RANGE, DATA_SOURCE) values(SEQ_WANTED_BAD_ID.NEXTVAL, ?, ?, ?, ?, ?, ?)";

			conn = dbManager.getConnection();
			conn.setAutoCommit(false);	

			pstmt = conn.prepareStatement(authSql);
			ResultSet rs = pstmt.executeQuery();
			boolean b = rs.next();
			if(b) {
				String authValue = StringUtils.defaultString(rs.getString("PARAMETERVALUE"));
				pstmt.close();

				String[] authValues = authValue.split(",");
				Arrays.sort(authValues);

				for(WantedTo wantedTo : wantedToList){

					String wantedCode = wantedTo.getWantedCode();

					if(Arrays.binarySearch(authValues, wantedCode) >= 0) {
						pstmt = conn.prepareStatement(sql);
					}else{
						pstmt = conn.prepareStatement(badSql);
					}

					pstmt.setString(1, wantedTo.getWaybillNo());
					pstmt.setString(2, wantedTo.getWantedCode());
					pstmt.setString(3, wantedTo.getWanted());
					pstmt.setString(4, wantedTo.getWantedExtend());
					pstmt.setString(5, wantedTo.getRange());
					pstmt.setString(6, wantedTo.getDataSource());
					pstmt.execute();
					pstmt.close();
			}
		}else {
			throw new Exception("Webservice WantedService system error,AUTH_WANTED Parameter Not Config");
		}
		conn.commit();

		System.out.println("Webservice WantedService handle successfully");

		return SUCCESS;
	} catch (Exception e) {
		System.out.println("Webservice WantedService system error");
		e.printStackTrace();

		try {
			if(conn != null){
				conn.rollback();
			}
		} catch (Exception sqle) {
			sqle.printStackTrace();
		}

		return SYSERR;
	}finally{
		dbManager.close(pstmt);
		dbManager.close(conn);
	}
}

private boolean valid(List<WantedTo> wantedToList){

	for(WantedTo wantedTo : wantedToList){
		if (wantedTo == null) {
			return false;
		}

		String wantedCode = wantedTo.getWantedCode(); // 通缉编码
		String wanted = wantedTo.getWanted();  // 通缉内容
		String range = wantedTo.getRange();    // 升级范围（工号或网点）
		String dataSource = wantedTo.getDataSource();  // 来源系统
		if (wantedCode == null || wantedCode.trim().length() == 0) {
			return false;
		}
		if (wanted == null || wanted.trim().length() == 0) {
			return false;
		}
		if (range == null || range.trim().length() == 0) {
			return false;
		}
		if (dataSource == null || dataSource.trim().length() == 0) {
			return false;
		}
	}

	return true;
}

public void setDbManager(DBManager dbManager) {
	this.dbManager = dbManager;
}

}
