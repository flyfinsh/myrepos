package com.sf.hht.interfaces.task.wanted;

public class WantedTo {
	
	private String waybillNo;     // 运单号
	
	private String wantedCode;    // 通缉编码
	
	private String wanted;        // 通缉内容
	
	private String wantedExtend;  // 通缉内容扩展字段
	
	private String range;         // 升级范围（工号或网点）
	
	private String dataSource;    // 来源系统
	
	private String extend1;       // 扩展字段1
	
	private String extend2;       // 扩展字段2
	
	private String extend3;       // 扩展字段3
	
	private String extend4;       // 扩展字段4
	
	private String extend5;       // 扩展字段5
	
	public String getWaybillNo() {
		return waybillNo;
	}
	
	public void setWaybillNo(String waybillNo) {
		this.waybillNo = waybillNo;
	}
	
	public String getWantedCode() {
		return wantedCode;
	}
	
	public void setWantedCode(String wantedCode) {
		this.wantedCode = wantedCode;
	}
	
	public String getWanted() {
		return wanted;
	}
	
	public void setWanted(String wanted) {
		this.wanted = wanted;
	}
	
	public String getWantedExtend() {
		return wantedExtend;
	}
	
	public void setWantedExtend(String wantedExtend) {
		this.wantedExtend = wantedExtend;
	}
	
	public String getRange() {
		return range;
	}
	
	public void setRange(String range) {
		this.range = range;
	}
	
	public String getDataSource() {
		return dataSource;
	}
	
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}

	public String getExtend1() {
		return extend1;
	}

	public void setExtend1(String extend1) {
		this.extend1 = extend1;
	}

	public String getExtend2() {
		return extend2;
	}

	public void setExtend2(String extend2) {
		this.extend2 = extend2;
	}

	public String getExtend3() {
		return extend3;
	}

	public void setExtend3(String extend3) {
		this.extend3 = extend3;
	}

	public String getExtend4() {
		return extend4;
	}

	public void setExtend4(String extend4) {
		this.extend4 = extend4;
	}

	public String getExtend5() {
		return extend5;
	}

	public void setExtend5(String extend5) {
		this.extend5 = extend5;
	}
	
}
